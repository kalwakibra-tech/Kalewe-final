---
name: graphite-parchment-ui
description: Build or redesign premium dashboards, admin panels, internal tools, management apps and product websites in the Darzi "Graphite and Parchment" language - white panels on a parchment shell, one blue for pressing, one orange for noticing, one glossy graphite object per screen, Apple-style glass that floats, tight tabular numerals, and a left sidebar instead of a top nav. Use this skill whenever the user asks to design, build, restyle or "make premium / Apple-like / clean" any dashboard, CRUD app, order or inventory or CRM or clinic or school or finance tool, settings page, form flow, detail page, queue, marketing page, or mobile companion screens, and whenever they paste a DESIGN.md from this family - even if they never name the style. It tells the agent which page structure to pick, where every CTA goes, which card, color, radius and material to use, and how to adapt the look to any business context without copying the original product.
---

# Graphite and Parchment UI (agent skill)

You are building the interface for a working tool that people use all day with real money, orders, patients, stock or deadlines. The result must feel **quiet, tactile and exact**: calm surfaces, one unmistakable number, soft rounded controls, and a single glossy object that holds the thing that matters.

This skill is the **decision procedure**. Its companion `DESIGN.md` is the **token and component spec**. Load both if available. If only this file is present, the Quick Token Sheet (section 12) is enough to build correctly. When the two disagree on a value, DESIGN.md wins; on a decision, this file wins.

---

## 0. The one-paragraph model

Every screen is **paper** (flat white and parchment surfaces holding content), plus at most one **object** (a graphite glossy card holding the screen's hero number), plus **glass** only for layers that float (toast, drawer, sheet, modal, floating action bar). Blue means "press me". Orange means "look here". Red, green, amber and purple are status and money only. Navigation is a **sidebar** (drawer on mobile), never a top pill bar. The primary action is always where the user's eye already is: top-right of the page, inside the money panel, or in the floating bottom bar on mobile.

---

## 1. Workflow (follow in order)

1. **Frame the product** (section 2): subject, user, daily job, the one number.
2. **Translate the context** (section 3): map each Darzi concept to the new domain.
3. **Choose the shell** (section 4): sidebar, header band, density.
4. **Choose a structure per screen** (section 5): use the decision tree, then the archetype recipe.
5. **Assign the hero** (section 6).
6. **Place the CTAs** (section 7).
7. **Pick cards, colors, radii, materials** (sections 8 and 9).
8. **Design the states** (section 10): empty, loading, error, blocked, destructive.
9. **Derive mobile** (section 11).
10. **Build with tokens** (sections 12 and 13).
11. **Run the QA checklist and critique pass** (section 14). Fix before presenting.

Before building, write a short **design plan** (6-10 lines): product, user, the hero number, the screens and their archetypes, the signature motif, the illustration object. Review it against section 15 (anti-slop) and revise anything that is a generic default.

---

## 2. Frame the product (ask only what you cannot infer)

Answer these from the brief and any provided PRD or memory. Ask the user **at most one** question, only if the product itself is unclear.

| Question | Why it matters | Darzi example |
|---|---|---|
| What is the **entity** people manage? | Becomes the row, the entity chip, the detail page | An order |
| What is the **unfinished-business number**? | Becomes the hero (graphite card, red numeral) | Money still due |
| What is the **workflow**? (2-4 stages) | Becomes the status dots and the segment bar | Pending → Cutting slip done → Delivered |
| What is the **time pressure**? | Becomes the second summary tile and the "Today" chip | Orders due in the next 3 days |
| What is the **one repeated daily action**? | Becomes the primary CTA | New order |
| What are the **setup knobs**? | Becomes Settings | Item prices, discount type, ribbon values |
| What is the **domain object and motif**? | Becomes the illustration and the 1px texture | Hand-tag and tape-measure ticks |

If the user gives a redesign of an existing app: **keep every feature**; change structure, surface and hierarchy only (section 16).

---

## 3. Translate the context (do not copy Darzi)

Keep the **construction**, change the **content**. Use this mapping table to retarget.

| Darzi construct | Generic role | Retarget examples |
|---|---|---|
| Order | Primary entity | Appointment, invoice, student, shipment, lead, ticket, booking |
| "Due after delivery ৳5,600" (graphite card) | The hero: money or risk outstanding | Overdue invoices, unpaid fees, stock below minimum, open tickets over SLA, revenue to collect |
| "Upcoming to deliver 2 orders" (paper tile) | Time pressure / volume | Today's appointments, classes this week, shipments arriving, renewals in 30 days |
| Pending / Cutting slip done / Delivered (amber / purple / green) | 3-stage workflow | New / In care / Discharged; Draft / Sent / Paid; Picked / Packed / Shipped |
| Order chip `#531` | Entity identifier | `INV-204`, `A-18`, `SKU 4410` |
| Pay ৳5,100 pill | Inline money or commit action | Collect, Refund, Confirm, Restock |
| Measurements trays | Grouped detail data | Vitals, grades, specs, dimensions, line attributes |
| Hand-tag illustration | Domain object | Stethoscope tag, report card, parcel, key tag, invoice slip |
| Tape-measure tick strip | Signature 1px motif | Blister-pack dots (clinic), graph-paper ticks (school), pallet slats (warehouse), barcode bars (retail) |
| Ribbon values / discount type | Setup knobs | Tax rates, working hours, grade scale, price tiers |
| "Officer" black chip | Category chip (ink pill) | Plan name, department, customer type |
| Delivery queue | Fast operational queue | Check-in queue, packing queue, approvals |

**Worked mini-examples**

- *Dental clinic:* hero = "Unpaid treatments ৳/$..."; paper tile = "Today: 9 appointments, next at 10:30"; workflow = Booked (amber) → In chair (purple) → Completed (green); inline pill = "Collect"; illustration = a tooth tag in graphite and orange; motif = dotted blister strip.
- *School admin:* hero = "Fees outstanding"; paper tile = "Classes today"; workflow = Applied → Enrolled → Graduated; inline pill = "Record fee"; motif = graph-paper ticks.
- *Inventory/e-commerce admin:* hero = "Stock value at risk" or "Orders to ship today"; workflow = Picked → Packed → Shipped; inline pill = "Ship"; motif = barcode strip.
- *SaaS analytics (extended):* hero = the one KPI; paper tiles = 3 supporting KPIs; chart panel with solid ink bars and ember hatch for forecast; no money-red unless it is money.

Never reuse Darzi's words (Officer, BD number, taka, ribbon) unless the product actually is Darzi.

---

## 4. The shell: sidebar, not navbar

**Do not build a top navigation bar.** Navigation is a left sidebar on desktop and a left glass drawer on mobile.

```
┌───────────────┬────────────────────────────────────────────┐
│ (D) Brand     │ Page title                [Ghost] [Primary]│
│ Role capsule  │ Subtitle                                   │
│               │ ───────────────────────────────────────────│
│ ▣ Dashboard   │  content bands (12-col grid, 20px gutter)  │
│   Orders      │                                            │
│   Delivery    │                                            │
│   Settings    │                                            │
│     (illus.)  │                                            │
└───────────────┴────────────────────────────────────────────┘
```

| Rule | Value |
|---|---|
| Width | 264px, collapses to 72px (icons) at 834-1023px, becomes the drawer below 834px |
| Surface | Parchment `#f5f5f7`, sits directly on the page: no card, no border, no shadow |
| Top | White pill profile capsule (avatar circle in ink, name 15/600, role 13/400 gray) |
| Items | 44px pills, 20px line icon, 15/600. **Active = ink pill with white label.** Inactive = ink-80, hover white |
| Order | Primary work first (Dashboard/Orders), operational queues next, Settings last |
| Count | 3-7 items. More than 7 → group with small gray section labels, not nested menus |
| Bottom | Product illustration (about 160px) or empty space. Never a promo |
| CTAs | The primary action is not in the sidebar. It lives in the page header |
| Search / notifications | A glass top bar that is transparent at rest, only if the product needs global search. Otherwise place a search pill in the control band |
| Mobile | Round 44px glass hamburger top-left → thick glass drawer with capsule, round close button, nav pills, illustration footer |

---

## 5. Choose the structure (decision tree)

Ask in this order and stop at the first match.

```
1. Is the user creating or editing a record?              → FORM WITH LIVE SUMMARY (5.4)
2. Is it about ONE record, read mostly?                   → DETAIL PAGE (5.3)
3. Is it configuring the system (prices, rules, options)? → SETTINGS (5.5)
4. Is it one fast repeated operation on many records?     → QUEUE (5.6)
5. Is it browsing/finding/acting on many records?
      with summary numbers on top?                        → PULSE + MASTER-DETAIL (5.1 / 5.2)
      without?                                            → MASTER-DETAIL or plain TABLE PANEL
6. Is it a confirm / warn / pick-one interruption?        → OVERLAY (5.7)
7. Is it nothing-yet or loading?                          → STATE PANEL (5.8)
8. Is it a visitor-facing page?                           → MARKETING PAGE (5.9)
9. Is it analytics over time?                             → ANALYTICS DASHBOARD (5.10)
10. Is it a grid of things (catalog, gallery, projects)?  → CARD GRID (5.11)
```

Principles for choosing the structure:

- **One verb per page.** A page that browses does not also edit. Navigation between them is a click on a row or a primary button.
- **Master-detail over modal-for-everything.** If users compare or scan, keep the list visible and show the record in the aside.
- **Full page for creation.** Long forms get a full page with a sticky summary, not a modal.
- **Overlay only for interruption.** Confirmations and quick pickers, never forms longer than 3 fields.
- **Sticky aside when a number must stay visible** while the user scrolls a long list or form.

### 5.1 Pulse + Work (dashboard home or list home)

Use when the user opens the app to learn "what needs me?".

```
Page title / subtitle                              [Ghost] [+ Primary]
┌──────────────────────────────────────────────────────────────────┐
│ ┌ paper tile ───────────┐  ┌ GRAPHITE OBJECT ────────────────┐   │
│ │ label                 │  │ label                           │   │
│ │ 2 orders · next 3 days│  │ ৳5,600  2 orders                │   │
│ │ [row] [row]           │  │ [row ........ (Pay ৳5,100)]    │   │
│ └───────────────────────┘  │ [row ........ (Pay ৳500)]      │   │
│                            └─────────────────────────────────┘   │
└──────────────────────────────────────────────────────────────────┘
[All 6][Pending 2][Slip done 1][Delivered 3]  [🔍 search.....] [Sort ⌄]
┌ table panel (8 cols) ────────────────┐ ┌ aside (4 cols, sticky) ┐
│ title                      helper    │ │ selected record        │
│ rows with entity chip, inline status │ │ due, progress, [Pay]   │
└──────────────────────────────────────┘ └────────────────────────┘
```

- Left tile = volume/time. Right graphite tile = money/risk. The left tile is clickable and filters the list (blue 2px outline + removable "Filter: Upcoming ✕" chip + hint "Tap the chip to clear the filter.").
- Chips are the primary filter (with counts). Selected chip = blue ring.
- First row is selected by default so the aside is never empty.

### 5.2 Master-detail (list with sticky aside)

Use for scanning many records and acting on one.

- Table panel 8 columns, aside 4 columns (about 360px), both start at the same top edge.
- Selecting a row sets `row-selected` fill and fills the aside. Double-click or "Open" goes to the full detail page.
- The aside = entity chip + name, 3-segment status bar, dates, **Due numeral (red)**, parchment tray (progress, total, advance), full-width primary.
- Below 1024px the aside drops under the list; below 640px rows tap through to the detail page.

### 5.3 Detail page

Use to understand one record completely. Reading order: **who → what → how much → details**.

```
‹ Orders                                   (blue text back link)
┌ header card ───────────────────────────────┐ ┌ money aside ───────┐
│ [illus. square]  Order #531                 │ │ Due   (Pending chip)│
│                  F/L Tanvir Ahmed (36/600)  │ │ ৳1,200  (red, huge) │
│                  [Officer] ● Pending BD/..  │ │ ▬▬▬▭▭ 40% paid      │
│                  [✎ Edit order] [🗑]        │ │ tray: Total/Disc/Adv│
└─────────────────────────────────────────────┘ │ [  Pay ৳1,200  ]    │
┌ info tray ─────────┐ ┌ info tray ──────────┐   └─────────────────────┘
│ Customer           │ │ Order                │
└────────────────────┘ └──────────────────────┘
┌ Items table ────────────────────────────────┐
┌ Payments table (if money moved) ────────────┐
┌ Detail data: grouped trays ─────────────────┐
```

- Main column 8, money aside 4 (sticky). The back link is blue text with a chevron, above the header card.
- Status is editable inline from the header (dot + label + chevron) and saves with Undo.
- Show derived dates in green when they represent completion ("Delivered on ...").

### 5.4 Form with live summary

Use for creating or editing the primary entity.

```
New order                                              [Cancel (ghost)]
Subtitle: Officer order #532. Items, measurements and payment in one place.
┌ Items ─────────────────────────────┐ ┌ GRAPHITE SUMMARY (sticky) ┐
│ [search ⌄ 28 items][qty][+ Add item]│ │ Total amount     ৳1,050   │
│ tray of added rows (× qty, total, ✕)│ │ Discount [10% or ৳ ]      │
└─────────────────────────────────────┘ │ Advance  [ 200 ]          │
┌ Customer and dates ─────────────────┐ │ Due   ৳850 (coral, large) │
│ 3-col grid, "Filled from saved…" ✓  │ │ ▬▭▭▭ 19% paid             │
└─────────────────────────────────────┘ │ [   Save order   ]        │
┌ Measurements (two tray groups) ─────┐ │ Needs a name and one item.│
└─────────────────────────────────────┘ └───────────────────────────┘
```

- Order sections by the order people think: **what** (items) → **who/when** → **details** → money lives in the sticky summary.
- The summary recalculates live. It owns the **only** Save button.
- `Cancel` is a ghost pill in the header. Unsaved changes + Cancel opens the "Leave without saving?" overlay.
- Validation: banner + field errors that say how to fix.

### 5.5 Settings

```
Settings                           Subtitle: what these knobs affect
┌ Items & Prices (8 cols) ────────────────┐ ┌ option card ────────┐
│ add-row tray: [name][price][+ Add item] │ │ Default discount    │
│ rows: name · price · [✎][🗑]           │ │ [Percentage|Taka]   │
│ footnote: safety rule in plain words    │ └─────────────────────┘
└─────────────────────────────────────────┘ ┌ Delivery days: [− 3 +]┐
                                            ┌ Ribbon values + ticks ┐
```

- Left = the big editable list. Right = small option cards (segmented control, stepper, value chips).
- One card per setting. Each card: title (22/600), one-line description gray, then the control.
- Mark rows that need attention with the ember "check price" chip, not red.
- Footnote tells the user what editing does **not** affect.

### 5.6 Queue

Use for one fast operation (deliver, check in, ship, approve).

- Header with a small graphite tile at the right ("Waiting for delivery · 3 orders").
- A full-width search pill, then one white panel of rows.
- Each row: entity chip with status dot, name + meta, date (with an ember "Today" chip when due today), amount owed in red, **inline primary pill** (the verb).
- Footnote explaining equivalence ("Same as changing the status on the order.").
- After the action: toast with Undo; the row leaves the queue.

### 5.7 Overlay

- **Desktop modal** 400-440px, radius 28, icon circle top-left, step indicator top-right if multi-step, title, one sentence, two equal buttons.
- **Mobile sheet** thick glass, radius 38, grab handle, title, context line, rows with dot + label + check, footer caption stating the side effect.
- Destructive flow: step 1 neutral (blue Continue), step 2 red Delete with the consequence stated.
- Use Undo toasts for reversible actions (status change, delivered, archive). No dialog.

### 5.8 State panels

- **Empty:** `shell` rounded panel with the illustration, title (22/600), one sentence, one primary pill. The hero metric still shows a real zero.
- **Loading:** skeleton shaped like the real layout (same number of rows and tiles), slow shimmer.
- **Error / blocked:** banner (caution dot) + field-level messages, both saying how to fix.
- **Queue empty:** white panel, icon circle, one sentence, no button.

### 5.9 Marketing page (extended)

Marketing pages use the same materials, with the rhythm of an Apple product page.

```
[glass top bar over the hero, transparent at rest; logo left, links center, ghost+primary right]  ← only here a bar is allowed
HERO band (shell):   display headline (56-72/600, -0.04em)  · one sentence · [Primary][Ghost]
                     one graphite OBJECT or product screenshot in a rounded 28 frame with product shadow
Band 2 (white):      3 feature tiles (paper, radius 24), each: icon circle, headline, 2 lines
Band 3 (graphite):   proof / numbers in white numerals, ember used once
Band 4 (shell):      pricing or steps as panels, one highlighted with a blue ring
Footer (shell):      dense link columns, hairline top
```

- Alternate bands **shell → white → graphite → shell**; never two identical bands in a row.
- One CTA per band; the hero CTA is the only large blue pill on the page.
- Headline copy states the outcome, not the feature. No stock photography; use the product UI, the illustration object, or numbers.
- Sections are 80px apart. Max content width 1200px.

### 5.10 Analytics dashboard (extended)

```
Page title                          [range chip ⌄] [Export (ghost)]
┌ hero object (graphite) ┐ ┌ 2×2 paper stat tiles ───────┐ ┌ chart panel ┐
│ the one KPI + delta     │ │ KPI · delta chip · period   │ │ solid=actual │
└─────────────────────────┘ └──────────────────────────────┘ │ hatch=forecast│
┌ ranked list panel ───────┐ ┌ wide table panel ────────────────────────────┐
```

- One hero KPI. Supporting KPIs are neutral tiles with label, value, delta chip, period.
- Chart series order: ink first, ember second (highlight/forecast only), blue third, gray fourth; max 4. Hairline dashed horizontal grid, no chart border, always a unit and a period.

### 5.11 Card grid

- 3 columns desktop, 2 tablet, 1 phone. Each card is a white panel (radius 24): illustration/thumbnail on a shell square, name 17/600, meta 14 gray, status dot + label, thin progress bar, text link "Open ›".
- Filters above as chips; view toggle (grid/table) as a segmented control on the right.

---

## 6. Assign the hero

Every screen has exactly one hero. Choose by **importance to the user's next decision**, not by money.

| Screen | Hero | Treatment |
|---|---|---|
| Home / list | The outstanding number | Graphite object card, white numeral, small inline pills |
| Detail | The amount or state of this record | Red numeral in the aside (desktop); 80px red numeral + graphite entity card (mobile) |
| Form | The live total and the due | Sticky graphite summary with coral due |
| Queue | Count waiting | Small graphite tile, count numeral |
| Settings | None | Settings has no hero; the list is the hero by size |
| Marketing | The product object | Graphite object or product screenshot with product shadow |

Rules: one graphite object per screen; one large numeral per screen; the hero number is red (or `#fe6a6a` on graphite) while something is owed or at risk, ink when neutral, green `0` when cleared. If everything is equally important, there is no hero and all tiles are neutral.

---

## 7. Place every CTA (procedure)

For each action, decide its **scope**, then use the placement.

| Scope | Placement | Style |
|---|---|---|
| Page (create, switch view) | Header band, top-right. Ghost left of primary | Ghost + Primary pills, 44px |
| Record (edit, delete) | Directly under the record title in its header card | Primary pill with icon + round danger-tint icon button |
| Money / commit on a number | Last element inside the money aside, full width. Mobile: wide pill in the floating bar | Primary |
| Row verb (Deliver, Pay) | Trailing edge of the row | Small primary pill (32-36px) |
| Submit a form | Last element of the sticky summary, full width, with a helper caption under it | Primary |
| Cancel a form | Header band top-right, ghost | Ghost |
| Close / back | Top-left: back link (blue text + chevron) on desktop, round glass button on mobile | Text / icon |
| Destructive | After the primary, icon-only, red glyph on `negative-tint` circle; confirm in two steps; final button solid red | Round icon → red pill |
| Undo | Right end of a toast | Blue text |
| Modal pair | Two equal buttons: left quiet (tray), right action (blue or red) | Tray + Primary / Destructive |
| Empty state fix | Centered under the sentence | Primary with "+" |
| Navigation inside content | Blue text + chevron ("Open Delivery ›") | Text |

Hard rules:

1. **One primary per region.** Second action is ghost or tray.
2. The primary is **right-most** in a row of buttons and **bottom-most** in a stack.
3. Never place a destructive action first, never in blue, never as the primary.
4. Never put Cancel adjacent to Save in forms.
5. Never put a CTA in the sidebar.
6. Labels are verb + object, with the amount when money moves: "Pay ৳5,100".
7. Mobile primary lives in the **floating bottom glass bar** within thumb reach; mobile quick-create actions at the top are **action tiles**.
8. Each region's button must be reachable and visible without scrolling the region it controls (sticky aside, sticky summary, floating bar).

---

## 8. Cards, radii, materials (pick by content)

| Content | Use | Surface | Radius |
|---|---|---|---|
| Group of content (table, list, form section) | Panel | white on shell | 24 (28 mobile) |
| Subgroup | Tray | shell in white | 16 |
| One number + label | Stat tile | shell in white panel | 18 |
| The page's number | Object card | graphite gradient + sheen + rim + product shadow | 24 (28 mobile) |
| Key facts of a record | Info tray (label over value) | shell | 16 |
| Rows of a queue | List card | white, inset dividers | 24 / 28 |
| Quick actions (mobile) | Action tiles | white | 24-28 |
| Time-critical message | Dark banner | graphite | 28 |
| Floating | Glass layer | thin / regular / thick | by layer |

Controls: pill (9999). Inputs: 12. Entity chip: 12 (40px square). Sheet/drawer: 38. Concentric rule: inner = outer minus gap. **Shadows only on object, float and sheet.** Panels, trays, tiles, rows, inputs, buttons have none.

---

## 9. Color assignment (procedure)

1. Backgrounds: shell `#f5f5f7` page, white panels, shell trays inside panels.
2. Text: ink `#1d1d1f`, secondary `#6e6e73`, never pure black.
3. Everything pressable: `#0066cc`. Focus ring `#0071e3`. On graphite: `#2997ff`.
4. Attention: ember `#fa7e42` (illustration, accents), ember-text `#c2410c` on `#fdeee7` for notice chips. Use at most one or two per screen.
5. Money / status: negative `#c62828` (tint `#fceaea`, on dark `#fe6a6a`), positive `#1e7b43` (dot `#2e9e54`, tint `#e3f4e8`), caution dot `#f2a93b`, stage dot `#7a4fd2`.
6. Workflow dots: **amber → purple → green**. More stages: add neutral gray for "not started".
7. Color budget: ~70% neutrals, ~20% ink, ~7% blue, ~3% ember.
8. Brand adaptation: you may **replace blue and ember** to match a new brand only if you keep the roles (one interactive hue, one attention hue) and re-check contrast. Keep neutrals, graphite, semantic colors and tint logic.

---

## 10. States and details to design

For every screen deliver, at minimum: default, loading (skeleton), empty, error/blocked, long text (truncate with title tooltip), and for destructive flows the confirmation. Also:

- Inline status changes save immediately with Undo.
- Impossible values show an inline `negative-tint` block with a dot and a how-to-fix sentence.
- Derived/autofilled fields show a small green check and "Filled from the saved ..." helper.
- Show "Not set" in gray for missing values, never a dash alone.
- Numbers: currency first, thousands separators, tabular; dates "Oct 22" in lists and ISO "2026-10-22" in forms.
- Selected rows update the aside; the first row is selected on load.
- Toasts: past tense + object + Undo, glass pill, bottom-center, about 3.5s.

---

## 11. Mobile derivation

Derive mobile from desktop; do not shrink it.

| Desktop | Mobile |
|---|---|
| Sidebar | Round glass hamburger → thick glass drawer |
| Title + subtitle + 2 buttons | Centered small title in a thin bar; actions become three white **action tiles** |
| Summary band | 80px hero numeral (currency small, gray) + two chips; time-critical item becomes a dismissible dark banner |
| Table | List card: entity chip with status dot (corner), name/meta left, red amount + status label right |
| Aside | Full screen: red numeral, graphite entity card (hanging tag, ring progress, tick strip), then a **bottom sheet** with items |
| Inline status control | Tap row → bottom sheet picker |
| Page primary | **Floating glass bottom bar**: round delete, round edit, wide primary |
| Stacked form sections | Tab pill (4 tabs max): Items / Customer / Details / Money; editable total numeral on top; floating "Update" bar |
| Hover | Not available; every hover affordance needs a tap equivalent |

Targets 44px; content scrolls under a transparent bar that turns glass after 48px; respect safe areas.

---

## 12. Quick token sheet (use if DESIGN.md is not loaded)

```css
:root{
  --shell:#f5f5f7; --canvas:#fff; --row-selected:#f0f0f0; --hairline:#e0e0e0; --divider:#f0f0f0;
  --ink:#1d1d1f; --ink-80:#333; --ink-60:#6e6e73; --ink-48:#7a7a7a; --on-dark-60:rgba(255,255,255,.64);
  --graphite:linear-gradient(135deg,#3d3d40 0%,#1d1d1f 36%,#0a0a0b 100%); --graphite-row:rgba(255,255,255,.06);
  --sheen:linear-gradient(105deg,rgba(255,255,255,0) 34%,rgba(255,255,255,.11) 44%,rgba(255,255,255,.02) 50%,rgba(255,255,255,0) 58%);
  --primary:#0066cc; --primary-focus:#0071e3; --primary-on-dark:#2997ff;
  --ember-400:#fa7e42; --ember-500:#f0561f; --ember-text:#c2410c; --ember-wash:#fdeee7;
  --positive:#1e7b43; --positive-dot:#2e9e54; --positive-tint:#e3f4e8;
  --negative:#c62828; --negative-dot:#e5484d; --negative-tint:#fceaea; --negative-on-dark:#fe6a6a;
  --caution-dot:#f2a93b; --stage-dot:#7a4fd2;
  --glass-regular:rgba(245,245,247,.72); --glass-thick:rgba(245,245,247,.70); --glass-dark:rgba(39,39,41,.72);
  --blur-regular:blur(26px) saturate(180%); --blur-thick:blur(28px) saturate(190%);
  --r-chip:12px; --r-input:12px; --r-tray:16px; --r-tile:18px; --r-panel:24px; --r-panel-m:28px; --r-sheet:38px; --r-pill:9999px;
  --shadow-product:3px 5px 30px rgba(0,0,0,.22); --shadow-float:0 8px 32px rgba(0,0,0,.10); --shadow-sheet:0 -10px 40px rgba(0,0,0,.14);
  --rim-dark:inset 0 0 0 1px rgba(255,255,255,.12), inset 0 1px 0 rgba(255,255,255,.28);
  --sidebar:264px; --content-max:1440px; --aside:360px; --gutter:20px;
}
```

Type: SF Pro / **Inter** (`ss03`), weights **400 and 600 only**, tabular numerals on all figures.

| Token | Size / weight / tracking |
|---|---|
| numeral-lg (mobile hero) | 80 / 600 / -0.035em |
| stat-xl (desktop hero) | 40 / 600 / -0.03em |
| page-title | 36 / 600 / -0.03em |
| title-1 (entity name) | 28 / 600 / -0.02em |
| title-2 (panel/modal) | 22 / 600 / -0.02em |
| headline / body | 17 / 600 or 400 / -0.374px |
| caption | 14 / 400 / -0.224px |
| table cell / head | 13 / 400, 12 / 600 |
| label (chips) | 12 / 600 |

Spacing: 4 · 8 · 12 · 16 · 20 · 24 · 32 · 48 · 80. Gaps: panels 20, tiles 12, panel padding 24 (desktop), tray padding 16, gutter 32. Row height 64-68, hit target 44.

### Signature snippets

```css
/* graphite object card */
.object{position:relative;color:#fff;background:var(--graphite);border-radius:24px;
  box-shadow:var(--shadow-product),var(--rim-dark);overflow:hidden}
.object::before{content:"";position:absolute;inset:0;background:var(--sheen);pointer-events:none}
.object .row{background:var(--graphite-row);border-radius:18px;padding:12px 16px;display:flex;align-items:center;justify-content:space-between}

/* hero numeral with small currency */
.hero-num{font:600 40px/1.1 var(--font-display);letter-spacing:-.03em;font-variant-numeric:tabular-nums}
.hero-num .cur{font-size:.45em;font-weight:400;color:var(--ink-60);vertical-align:.8em;margin-right:.1em}

/* filter chip with selected ring */
.chip{height:40px;padding:0 16px;border-radius:9999px;background:#fff;border:1px solid var(--hairline)}
.chip[aria-pressed=true]{border:2px solid var(--primary-focus);padding:0 15px}

/* entity chip */
.entity{width:40px;height:40px;border-radius:12px;background:var(--ink);color:#fff;font:600 12px/40px var(--font-text);text-align:center}

/* status dot + label */
.status{display:inline-flex;gap:8px;align-items:center}
.status::before{content:"";width:8px;height:8px;border-radius:50%;background:var(--caution-dot)} /* swap per stage */

/* progress */
.progress{height:4px;border-radius:99px;background:var(--divider)}
.progress>i{display:block;height:100%;border-radius:inherit;background:var(--ink)}

/* glass toast */
.toast{display:flex;gap:16px;align-items:center;height:56px;padding:0 20px;border-radius:9999px;
  background:var(--glass-regular);backdrop-filter:var(--blur-regular);box-shadow:var(--shadow-float);
  border:1px solid rgba(255,255,255,.65)}
.toast button{color:var(--primary);font-weight:600}

/* tick-strip motif (retarget the repeat shape to your domain) */
.ticks{height:28px;background-image:repeating-linear-gradient(90deg,rgba(255,255,255,.28) 0 1px,transparent 1px 22px)}
```

Fallbacks (mandatory): `prefers-reduced-transparency` → opaque `--shell`; `prefers-contrast: more` → opaque + visible border; `prefers-reduced-motion` → no springs, tilt or shimmer.

---

## 13. Implementation guidance

- **Stack default:** React + Tailwind (v4 `@theme` with the tokens above) or plain HTML/CSS with custom properties. Keep tokens in one file; no inline hex, radius or shadow.
- **Build order:** tokens → shell (sidebar, page header) → primitives (button, chip, input, panel, tray, object card, status, progress, toast, modal, sheet) → pages → states → mobile.
- **Data realism:** use believable domain data (names, IDs, amounts that add up: total − discount − advance = due; percent paid is consistent). Make sample numbers cover one owed, one cleared, one just-created row.
- **Interaction truth:** make the inline status, filter chips, sort, select-row-to-fill-aside, toast Undo and the form's live total actually work in prototypes.
- **Springs, not CSS transitions,** for gestures (sheets, swipes, tilt). CSS transitions are fine for color and press scale.
- **Accessibility floor:** real buttons/inputs/labels, visible focus, dot + word status, contrast per DESIGN.md section 2.5, 44px targets.
- **Responsive:** build desktop with the sidebar first, then derive tablet (72px rail) and phone (drawer, list cards, sheet, floating bar).
- **Currency / locale:** make the currency sign a token; verify the glyph renders in your fonts.
- **Output:** the code, plus a 6-line "design plan" and a list of any decisions that deviate from this skill and why. Do not narrate the skill's name.

---

## 14. QA checklist (run before presenting; fix, then re-run)

**Structure**

1. Sidebar present (and drawer on mobile); no top navigation bar.
2. Each screen matches one archetype and has exactly one hero.
3. Page actions are top-right (ghost, then primary); record actions sit under the title; money actions inside the money panel; submit inside the sticky summary.
4. One primary per region; destructive is never primary and is confirmed in two steps.

**Surface and shape**

5. Tonal stack is at most three levels; no panel inside a panel.
6. Shadows only on object, float and sheet. No shadows on panels, tiles, rows, buttons.
7. Radii follow tokens; pills only on controls; inner radii are concentric.
8. Graphite object appears once per screen; it has sheen and rim.
9. Glass only on floating layers, with a bright top edge and fallbacks; never glass on glass.

**Color and type**

10. Blue only on pressable things; ember only for notice and illustration; red only for owed amounts, destructive and errors.
11. Status = dot + word; workflow dots consistent everywhere.
12. Weights 400 and 600 only; tabular numerals on every figure; no all caps; currency sign small and gray beside the hero numeral.
13. Contrast: small orange text uses `#c2410c`; red-on-dark uses `#fe6a6a`; no `ink-48` for live text.

**Content and states**

14. Every number has a label and context (period, progress, comparison).
15. Empty, loading, error/blocked, long text and destructive states exist.
16. Copy is plain, sentence case, states consequences, buttons are verb + object, toasts are past tense with Undo.

**Motion and access**

17. Press feedback on pointer down; Undo toast instead of "Are you sure?" for reversible actions.
18. Focus visible, targets 44px, reduced motion/transparency/contrast handled.

**Self-critique (one pass):** take a screenshot if tools allow. Ask: does anything shout? (reduce it). Is the one number unmistakable? Could I remove one more border, shadow or color? Does it look like any generic admin template? Fix, then present.

---

## 15. Anti-slop list (things that break the language)

- Top navigation pill bar as the main nav; a hamburger on desktop.
- Every card identical with the same radius and a drop shadow; shadow under every panel.
- Gradient washes behind sections, glow, neon, glassmorphism on content panels, blobs.
- Blue used for charts or decoration; orange used for buttons; purple/teal/pink as extra brand colors.
- Filled status pills in table rows; colored text alone as status.
- Uppercase tracked eyebrow above every heading; "01 / 02 / 03" numbering that is not a sequence.
- Stock illustrations of people, emoji icons, 3D blobs, a spinner instead of a skeleton.
- Weight 500/700 mixes, many font sizes, center-aligned dense data.
- Hero metrics repeated five times in equal weight; five equally loud cards.
- Confirmation dialogs for reversible actions; Cancel placed next to Save.
- Copy such as "Oops", "Seamless", "Supercharge", "Unlock the power of".
- Copying Darzi's literal domain words, colors and illustration into an unrelated product.

---

## 16. Redesign mode (restyle an ugly but working app)

1. **Inventory** every screen and feature (routes, forms, tables, buttons, states). Write them down; nothing may be removed.
2. **Classify** each screen into an archetype (section 5). Note where the current layout fights its job.
3. **Re-skin** with tokens: shell/panel/tray surfaces, pill controls, tabular numerals, status dots.
4. **Re-structure**: replace the top nav with the sidebar; move page actions top-right; give each screen one hero; add the sticky aside or summary where numbers matter.
5. **Rebuild states:** empty, loading, error, destructive.
6. **Check parity:** every original feature is reachable in the same number of taps or fewer.
7. Report: what changed by screen, what moved where (especially CTAs), and any feature that needed a new place.

---

## 17. Prompt templates the user can paste

- "Using the graphite-parchment-ui skill, design the **{screen}** for **{product}** on desktop with a sidebar, then derive mobile."
- "Redesign this app in the graphite-parchment-ui language. Keep every feature. Replace the top bar with the sidebar and tell me which archetype each screen became."
- "Build a **{marketing page}** for **{product}** using the marketing archetype: shell, white, graphite, shell bands; one object; one CTA per band."
- "Audit this screen against the QA checklist and list each violation with the token that fixes it."
- "Retarget the Darzi language to **{domain}**: give me the hero, workflow dots, illustration object and tick motif before you build."
