---
version: 1.0
name: Darzi-design-language
codename: Graphite-and-Parchment
description: A calm, premium operations-software language. White panels on a parchment shell, one ink for text, one blue for things you press, one orange for what you should notice, and one glossy graphite object per screen. Apple-grade materials (glass that floats, springs, tight type) applied to dense, money-and-status-heavy work. Extracted from the Darzi Tailor Shop Manager screens (Loop 1 and Loop 2, desktop and mobile).

fonts:
  display: "SF Pro Display, -apple-system, BlinkMacSystemFont, Inter, system-ui, sans-serif"
  text: "SF Pro Text, -apple-system, BlinkMacSystemFont, Inter, system-ui, sans-serif"
  currency-fallback: "Inter, Noto Sans Bengali, system-ui, sans-serif"   # the taka sign must render; swap for your currency

colors:
  # surfaces (light)
  shell: "#f5f5f7"            # page background, trays, neutral tiles, table header band
  canvas: "#ffffff"           # panels, list cards, inputs, chips
  row-selected: "#f0f0f0"
  hairline: "#e0e0e0"         # the only border colour
  divider: "#f0f0f0"          # row dividers inside panels
  scrim: "rgba(0,0,0,0.34)"
  # ink
  ink: "#1d1d1f"              # all primary text, active nav pill, dark chips, order chips
  ink-80: "#333333"
  ink-60: "#6e6e73"           # captions, table heads, subtitles, timestamps
  ink-48: "#7a7a7a"           # disabled and placeholder only
  on-dark: "#ffffff"
  on-dark-60: "rgba(255,255,255,0.64)"
  # graphite object (the dark glossy card)
  graphite-hi: "#3d3d40"
  graphite-mid: "#1d1d1f"
  graphite-lo: "#0a0a0b"
  graphite-row: "rgba(255,255,255,0.06)"   # nested rows inside the graphite card
  # interactive: the only pressable colour
  primary: "#0066cc"
  primary-focus: "#0071e3"
  primary-on-dark: "#2997ff"
  primary-wash: "rgba(0,102,204,0.10)"
  # ember: the only "look here" colour
  ember-400: "#fa7e42"        # measured on illustration and coin tag
  ember-500: "#f0561f"
  ember-text: "#c2410c"
  ember-wash: "#fdeee7"       # soft pill background for notice labels
  # semantic: status and money only
  positive: "#1e7b43"
  positive-dot: "#2e9e54"
  positive-tint: "#e3f4e8"
  negative: "#c62828"         # measured: due amounts, destructive buttons, errors
  negative-dot: "#e5484d"
  negative-tint: "#fceaea"    # measured
  negative-on-dark: "#fe6a6a" # measured: due amount on graphite
  caution-dot: "#f2a93b"      # measured: "pending" dot
  stage-dot: "#7a4fd2"        # measured: the one mid-workflow stage (purple). Optional, see 2.4

gradients:
  graphite: "linear-gradient(135deg, #3d3d40 0%, #1d1d1f 36%, #0a0a0b 100%)"
  ember: "linear-gradient(160deg, #ff8b4e 0%, #f0561f 100%)"
  sheen: "linear-gradient(105deg, rgba(255,255,255,0) 34%, rgba(255,255,255,0.11) 44%, rgba(255,255,255,0.02) 50%, rgba(255,255,255,0) 58%)"
  skeleton: "linear-gradient(90deg, #ececee 0%, #f6f6f8 50%, #ececee 100%)"

typography:
  numeral-xl: { size: 96px, weight: 600, leading: 1,    tracking: -0.04em,  use: "entry amount (keypad)" }
  numeral-lg: { size: 80px, weight: 600, leading: 1,    tracking: -0.035em, use: "the one hero number on a mobile screen" }
  stat-xl:    { size: 40px, weight: 600, leading: 1.1,  tracking: -0.03em,  use: "hero number inside a desktop card / aside" }
  stat-lg:    { size: 32px, weight: 600, leading: 1.1,  tracking: -0.025em }
  stat-md:    { size: 24px, weight: 600, leading: 1.1,  tracking: -0.02em }
  page-title: { size: 36px, weight: 600, leading: 1.1,  tracking: -0.03em,  use: "H1 on desktop (Orders, Settings, Delivery)" }
  title-1:    { size: 28px, weight: 600, leading: 1.14, tracking: -0.02em,  use: "entity name in a detail header / aside" }
  title-2:    { size: 22px, weight: 600, leading: 1.2,  tracking: -0.02em,  use: "modal title, panel title" }
  headline:   { size: 17px, weight: 600, leading: 1.24, tracking: -0.374px }
  body:       { size: 17px, weight: 400, leading: 1.47, tracking: -0.374px }
  caption:    { size: 14px, weight: 400, leading: 1.43, tracking: -0.224px }
  caption-strong: { size: 14px, weight: 600, leading: 1.29, tracking: -0.224px }
  label:      { size: 12px, weight: 600, leading: 1,    tracking: -0.12px }
  data-cell:  { size: 13px, weight: 400, leading: 1.38, tracking: -0.08px }
  data-strong:{ size: 13px, weight: 600, leading: 1.38, tracking: -0.08px }
  data-head:  { size: 12px, weight: 600, leading: 1.33, tracking: -0.12px }

rounded:
  chip-square: 12px     # the dark order chip / entity chip
  input: 12px
  tray: 16px
  tile: 18px
  panel: 24px           # desktop panels, modals
  panel-mobile: 28px    # mobile list cards, action tiles, object card
  sheet: 38px           # bottom sheets, drawers
  pill: 9999px          # every control

spacing: { 4: 4px, 8: 8px, 12: 12px, 16: 16px, 20: 20px, 24: 24px, 32: 32px, 48: 48px, 80: 80px }

shadows:
  product: "3px 5px 30px rgba(0,0,0,0.22)"   # graphite object card, illustrations resting on a surface
  float: "0 8px 32px rgba(0,0,0,0.10)"       # toast, popover, floating action bar, drawer
  sheet: "0 -10px 40px rgba(0,0,0,0.14)"     # bottom sheets
  rim-dark: "inset 0 0 0 1px rgba(255,255,255,0.12), inset 0 1px 0 rgba(255,255,255,0.28)"

blur: { thin: "blur(20px) saturate(180%)", regular: "blur(26px) saturate(180%)", thick: "blur(28px) saturate(190%)" }

motion:
  press: { pill: 0.95, card: 0.97, key: 0.92, duration: 100ms }
  spring-default: { damping: 1.0, response: 0.35 }
  spring-momentum: { damping: 0.8, response: 0.3 }
  toast-dismiss: 3500ms
---

# Darzi Design Language (Graphite and Parchment)

> **Hold this sentence in your head:** white panels on a parchment shell, one ink for text, one blue for the things you press, one orange for what you should notice, one glossy graphite object that holds the number that matters, and glass only where something floats.

This is the full design DNA of the Darzi screens: the tokens, the materials, the emotion, and the structure theory behind them. It is written so a designer or an AI agent can rebuild the same feeling for a different product (a clinic, a school, a warehouse, an analytics tool, a marketing site) by swapping the **context** and keeping the **construction**.

---

## 0. Provenance, scope and confidence

- **Source:** the "Loop One and Two Screens" PDF (23 pages): Orders list, New order, Order detail (open and delivered), Delivery, Settings, overlays and states, in desktop and mobile.
- **Measured** values (sampled from the screens): `#f5f5f7` shell, `#ffffff` panel, `#1d1d1f` ink, `#0066cc` blue, `#c62828` due red, `#fceaea` red tint, `#fe6a6a` red on dark, `#f2a93b` pending amber, `#7a4fd2` stage purple, `#2e9e54` delivered green, `#fa7e42` orange illustration, the graphite gradient samples `#333335` to `#0d0d0d`.
- **Estimated** values (read from layout, snapped to the nearest token): radii, paddings, type sizes, row heights.
- **Extended** parts are not drawn in the PDF and are marked **(extended)**: the permanent sidebar (the PDF uses a top pill bar on desktop and a drawer on mobile; the brief replaces the bar with a sidebar), dense data tables beyond Orders, charts, marketing pages, dark mode. They follow the same rules and the Meridian language the Darzi screens were built on.
- **The top navigation bar is intentionally not part of this spec.** Section 4.2 defines the sidebar that replaces it.

---

## 1. Design theory

### 1.1 The emotion

The product is a working tool used all day by someone handling real money and real deadlines. The feeling to produce is **calm authority**: nothing shouts, everything is placed, the one important number is unmistakable. Think of an Apple product page crossed with a banking app: quiet surfaces, tight confident type, a single glossy object, and soft rounded geometry that feels safe to touch.

Three words: **quiet, tactile, exact.**

- *Quiet:* tone separates things, not lines and shadows. Color is rationed.
- *Tactile:* controls are pills, cards are rounded and glossy where they represent a "thing", every press answers instantly.
- *Exact:* tabular numerals, concentric radii, tokens for everything, copy that states the situation.

### 1.2 The three materials

Every element is made of exactly one of three materials. Choosing the material is choosing the element's meaning.

| Material | Looks like | Means | Where |
|---|---|---|---|
| **Paper** | Flat white and parchment, no shadow, no border (or a 1px hairline) | "Content you read and act on" | Shell, panels, trays, tiles, tables, forms, list rows |
| **Object** | Graphite gradient, sheen, inner rim, soft product shadow, optional tilt | "The one thing this screen is about" | The summary card, the aside total, the entity card on mobile detail |
| **Glass** | Translucent, blurred, bright top edge, float shadow | "A layer above the content" | Toast, drawer, bottom sheet, floating action bar, modal, round floating buttons |

Paper is 90% of the screen. Object appears once. Glass appears only when something floats. If you are unsure, it is paper.

### 1.3 The ten laws

1. **Tone, not lines.** Separation comes from stepping surfaces: shell, panel, tray, tile. Borders are rare 1px hairlines. No boxes inside boxes inside boxes.
2. **One hero per screen.** One large tabular numeral or one graphite object card carries the page. Everything else is quiet. The hero is the number the user opens the app to see (Darzi: money still due).
3. **Money is red until it is zero.** The amount still owed is the most emotionally loaded number, so it gets the strongest numeral, in `negative` red, and turns green `0` when cleared. Translate this to your domain: the "unfinished business" number is the hero.
4. **Blue is for pressing, orange is for noticing.** Blue never decorates. Orange never presses. They never share a component.
5. **Concentric radii.** Inner radius equals outer radius minus the gap. Pills only on controls. Content blocks are never pills.
6. **Two weights, tight display type.** 400 and 600 only. Large type is tracked negative, body type is open. Numbers are tabular.
7. **Shadows are rationed.** Three shadow recipes exist. Panels, trays, tiles, buttons, inputs, rows never have one.
8. **Glass floats, paper sits.** Glass never carries content you read for a long time, never stacks on glass, and always has a bright top edge.
9. **Status is a dot plus a word.** A colored dot, then the label. Color is never the only signal.
10. **Reversible beats confirmed.** Prefer an Undo toast to "Are you sure?". Reserve confirmation for irreversible actions and make that confirmation two steps with a visible step indicator.

### 1.4 The signature moves (what makes it recognisably this system)

These are the details a reviewer will recognise. Keep them, retarget them to the new domain.

1. **The graphite summary card** with a diagonal sheen, a numeral in white, and nested translucent rows holding inline actions (Darzi: "Due after delivery ৳5,600" with `Pay ৳5,100` pills).
2. **The paired summary band:** a light neutral tile (count and next 3 days) beside the graphite tile (money), inside one white panel.
3. **The huge red numeral** for the amount owed, with a currency sign set smaller and gray beside it.
4. **The domain illustration on a parchment square or hung from a string** (a tailor's hand-tag with an orange coin). One illustrated object per product, drawn in graphite plus one orange.
5. **The ruler tick strip**, a row of thin vertical ticks used as a texture along the bottom of the graphite card and in settings. Every product gets one signature motif like this. Darzi's is the tape measure.
6. **The dark rounded-square entity chip** (order number "#531") that anchors every row, with a tiny status dot at its corner on mobile.
7. **Filter chips with counts** where the selected chip is a 2px blue ring, not a fill.
8. **The status as a three-segment bar** in the detail aside, and as a dot plus label in rows.
9. **A thin progress bar plus "43% paid"** under every money figure.
10. **The floating glass pill toast** with a blue "Undo".
11. **The two-step delete** with a "Step 1 of 2" indicator and a red final button.
12. **The skeleton that mimics the real layout**, and an empty state with the illustration, one sentence and one primary button.

---

## 2. Color

### 2.1 Roles

| Role | Token | Hex | Use |
|---|---|---|---|
| Shell | `shell` | `#f5f5f7` | Page background. Also trays, neutral tiles, table header band, quiet buttons. |
| Panel | `canvas` | `#ffffff` | Panels, list cards, inputs, filter chips, search. |
| Selected row | `row-selected` | `#f0f0f0` | Selected or hovered table row. |
| Hairline | `hairline` | `#e0e0e0` | The only border. 1px, only where white meets white. |
| Divider | `divider` | `#f0f0f0` | Between rows. Never above the first or below the last. |
| Ink | `ink` | `#1d1d1f` | Text, active nav pill, entity chips, dark utility buttons. Never pure black text. |
| Secondary text | `ink-60` | `#6e6e73` | Subtitles, captions, table headers, timestamps (5.1:1 on white). |
| Disabled | `ink-48` | `#7a7a7a` | Disabled and placeholder only. |
| Graphite | `graphite-*` | `#3d3d40 to #1d1d1f to #0a0a0b` | The one object card and dark banners. |
| Action blue | `primary` | `#0066cc` | Primary button, ghost button outline, links, text buttons, selected-chip ring, "Undo". |
| Focus blue | `primary-focus` | `#0071e3` | Keyboard focus ring, selected-filter ring. |
| Blue on dark | `primary-on-dark` | `#2997ff` | Links on graphite or dark banners only. |
| Ember | `ember-400/500` | `#fa7e42` / `#f0561f` | Illustration accent, attention fills, the "notice" chip. |
| Ember text | `ember-text` | `#c2410c` | Small orange text (5.2:1 on white). Use this, not `ember-500`, for words. |
| Ember wash | `ember-wash` | `#fdeee7` | Background of "Today", "check price", "Delivery Oct 27" chips. |

### 2.2 Semantic colors (status and money only, never decoration)

| State | Dot | Text | Tint | Use in Darzi |
|---|---|---|---|---|
| Negative | `#e5484d` | `#c62828` | `#fceaea` | Amount still due, destructive buttons, field errors, "2 orders" chip. |
| Positive | `#2e9e54` | `#1e7b43` | `#e3f4e8` | "40% paid", fully paid `৳0`, delivered dot, "Delivered" chip. |
| Caution | `#f2a93b` | ink (label stays ink) | none | Pending dot, inline warning banner dot. |
| Stage | `#7a4fd2` | ink | none | The middle workflow stage ("Cutting Slip – Done"). |
| Neutral | `#6e6e73` | `#6e6e73` | `#f5f5f7` | Draft, not set, archived. |

On graphite, the red numeral is `negative-on-dark` `#fe6a6a` (the `#c62828` red fails on dark).

### 2.3 The workflow dot palette

A three-stage workflow maps to three dots: **amber (waiting) → purple (in progress) → green (done)**. Use the same dot in the row status, the entity chip corner, the status sheet, and the three-segment bar. If your product has more than three stages, add neutral gray for "not started" and use at most one more hue. Never use the ember or the blue as a status.

### 2.4 Color budget

| Share | Color |
|---|---|
| ~70% | Neutral surfaces (shell, white, trays) |
| ~20% | Ink (text, active nav, entity chips, graphite object) |
| ~7% | Blue (buttons, links, selected ring) |
| ~3% | Ember (illustration, one or two notice chips) |
| tiny | Red and green only as numerals, dots and chips |

Red is allowed to be big (the due numeral) because it carries meaning; it is not a decoration.

### 2.5 Contrast contract

| Foreground | On | Ratio | Allowed |
|---|---|---|---|
| Ink `#1d1d1f` | white | 16.8:1 | All text |
| Ink-60 `#6e6e73` | white / shell | 5.1 / 4.7 | Captions, headers |
| White | primary `#0066cc` | 5.6:1 | Primary button label |
| `#c62828` | white | 5.6:1 | Due numerals, errors |
| `#c2410c` | `#fdeee7` | 4.6:1 | Notice chips |
| `#fe6a6a` | graphite | 6+:1 | Due numeral on dark |
| `#1e7b43` | `#e3f4e8` | 4.6:1 | Positive chips |

---

## 3. Typography

### 3.1 Family and rules

- **SF Pro** on Apple devices; **Inter** (variable, `font-feature-settings: "ss03"`) everywhere else. One family, two roles (display 20px and up, text below).
- **Weights 400 and 600 only.** No 500, no 700. Headings and key values are 600.
- **Tabular numerals** (`font-variant-numeric: tabular-nums`) for every money value, count, date, percentage and table figure.
- **Sentence case** everywhere. No all caps. No eyebrow above every heading.
- Currency sign is set **smaller and lighter** than the digits in hero numerals (`৳` at about 45% of the digit size, `ink-60`, raised to the cap line).
- Check that your font renders the currency glyph (the taka sign `৳` needs a Bengali-aware fallback).

### 3.2 Ladder

| Token | Size / leading | Weight | Tracking | Where |
|---|---|---|---|---|
| `numeral-lg` | 80 / 1 | 600 | -0.035em | Mobile hero number (due amount) |
| `stat-xl` | 40 / 1.1 | 600 | -0.03em | Desktop hero number inside the graphite card and aside |
| `stat-lg` | 32 / 1.1 | 600 | -0.025em | Standard stat, totals |
| `page-title` | 36 / 1.1 | 600 | -0.03em | Desktop page H1, with a 17px gray subtitle under it |
| `title-1` | 28 / 1.14 | 600 | -0.02em | Entity name in detail header and aside |
| `title-2` | 22 / 1.2 | 600 | -0.02em | Modal title, panel title |
| `headline` | 17 / 1.24 | 600 | -0.374px | Row names, card titles, buttons on mobile |
| `body` | 17 / 1.47 | 400 | -0.374px | Paragraphs, descriptions |
| `caption` | 14 / 1.43 | 400 | -0.224px | Row meta, helper text, chips |
| `label` | 12 / 1 | 600 | -0.12px | Chips, tab labels, badges |
| `data-cell` / `data-strong` / `data-head` | 13 / 13 / 12 | 400 / 600 / 600 | -0.08 to -0.12px | Desktop tables (dense tier) |

### 3.3 Hierarchy recipe for any screen

```
Page title (36/600)           Orders
Subtitle (17/400, ink-60)     Every Officer order, from first fitting to final due.
Hero number (40/600 or 80)    ৳5,600  (with currency smaller)
Panel title (22/600)          All orders
Row primary (15-17/600)       F/L Tanvir Ahmed
Row secondary (13-14/400, 60) Officer · BD/12408
Helper (12-13/400, 60)        Showing 6 of 6 · tap a row for details
```

---

## 4. Layout and spacing

### 4.1 Spacing

4px base. Structure snaps to `8 · 12 · 16 · 20 · 24 · 32`.

| Gap | Value |
|---|---|
| Page gutter (desktop) | 32px (24 on tablet, 20 on phone) |
| Between panels | 20px |
| Panel padding | 24px desktop, 8px outer + 12-16px row padding on mobile list cards |
| Tray padding | 16px (8px on a tray that holds tiles) |
| Tiles inside a tray | 12px |
| Label to value | 4px |
| Title to subtitle | 8px |
| Page title block to first panel | 24-32px |
| Comfortable row height | 64-72px (desktop table rows were about 66px) |
| Hit target | 44px minimum (36px dense, pointer fine only) |

### 4.2 The sidebar shell (replaces the top navigation bar) (extended)

The Darzi PDF uses a centered pill bar on desktop and a left drawer on mobile. The brief wants a sidebar, so the permanent desktop sidebar is **the mobile drawer promoted to a fixed column**. Same parts, same materials.

```
┌───────────────┬──────────────────────────────────────────────────┐
│ ┌───────────┐ │  Page title (36/600)                [Ghost][Primary]
│ │ (D) Darzi │ │  Subtitle (ink-60)
│ │ Role      │ │ ┌────────────────────────────────────────────┐
│ └───────────┘ │ │ Summary band (paper tile + graphite object)│
│               │ └────────────────────────────────────────────┘
│ ▣ Orders      │  [filter chips................][search][sort]
│   Delivery    │ ┌─────────────────────────────┐ ┌────────────┐
│   Settings    │ │ Main list / table panel     │ │ Detail     │
│               │ │                             │ │ aside      │
│   (illus.)    │ └─────────────────────────────┘ └────────────┘
└───────────────┴──────────────────────────────────────────────────┘
```

| Part | Spec |
|---|---|
| Width | 264px expanded, 72px icon-only (834-1023px), hidden behind the mobile drawer below 834px |
| Background | `shell`, directly on the page. No panel, no border, no shadow. |
| Profile capsule | Top. White pill, 56px high, 36px ink avatar circle with white initial, name 15/600, role 13/400 `ink-60`. This is the Darzi top-left capsule moved into the sidebar. |
| Nav item | 44px high pill, 12px 16px padding, 20px line icon, 15/600. **Active = `ink` pill, white label and icon.** Inactive = `ink-80` text on transparent, hover = white. |
| Groups | Optional section label in `caption-strong` `ink-60` between groups. |
| Bottom | The product illustration at about 160px, or nothing. Never an ad. |
| Primary action | Never in the sidebar. It lives in the page header (4.4). |
| Top bar | None required. If a bar is needed for search or notifications, use a glass bar (7.4) that is transparent at rest. |
| Mobile | The same list appears in a left **glass drawer** (sheet radius, thick glass): profile capsule and a round close button on top, nav pills below, illustration and caption at the bottom. Opened by a 44px round glass hamburger at top-left. |

**Location is ink, state is blue.** "Where am I" is the ink pill. "What did I filter" is the blue ring. "What can I press" is blue text.

### 4.3 Page anatomy

Every page is built from these horizontal bands, top to bottom. Use the ones you need.

1. **Header band:** back link (if nested), H1 + subtitle on the left, action group on the right.
2. **Summary band:** one white panel holding a neutral tile and a graphite object tile (or a stat grid).
3. **Control band:** filter chips (with counts), search pill, sort pill.
4. **Work band:** list or table panel, optionally with a detail aside.
5. **Footnote:** one caption line explaining a rule ("Changing or removing an item never changes orders that already exist.").

### 4.4 Grid and aside

- Content area max width 1440px, 12 columns, 20px gutters, centered in the space right of the sidebar.
- **Master-detail:** list 8 columns, aside 4 columns (aside about 360px). The aside is sticky.
- **Form:** sections 8 columns stacked, summary card 4 columns sticky at the top-right.
- **Settings:** list panel 8 columns, option cards 4 columns stacked.
- Panels in a row share top and bottom edges.

### 4.5 Breakpoints

| Width | Change |
|---|---|
| up to 640 | Phone layout: single column, tables become list cards, aside becomes a bottom sheet, summary becomes a hero numeral |
| 641-833 | Single column, sidebar hidden behind the drawer |
| 834-1023 | Sidebar collapsed to 72px, aside drops below the list |
| 1024-1440 | Full layout |
| 1441+ | Content locks at 1440px, margins absorb the rest |

### 4.6 Desktop to mobile transformation (the rules the Darzi screens follow)

| Desktop | Mobile |
|---|---|
| Sidebar | Round glass hamburger → left glass drawer |
| Page title + subtitle + action pair | Centered small title in a thin bar; actions become **three action tiles** (New order, Delivery, Search) |
| Summary band (neutral tile + graphite tile) | One hero numeral (80px) with two chips beneath it; the second metric becomes a dark dismissible banner when it is time-critical |
| Table with columns | List card: entity chip with status dot, name and meta left, amount and status right |
| Aside (detail) | Full screen: hero due numeral, graphite entity card, then a bottom sheet with the items |
| Inline status dropdown in a row | Tap row → bottom sheet with colored dot options |
| Primary button in header | Floating glass bottom bar: round delete, round edit, wide primary pay |
| Form sections stacked | Tabs (Items / Customer / Measure / Money) in a pill, one section at a time, big editable total on top |

---

## 5. Shape

| Token | px | Use |
|---|---|---|
| `chip-square` | 12 | Dark entity chip (about 40px square), small inputs |
| `input` | 12 | Text fields |
| `tray` | 16 | Trays inside panels (Customer / Order info trays, measurement trays) |
| `tile` | 18 | Stat tiles, nested rows inside a tile |
| `panel` | 24 | Desktop panels, modals, the aside |
| `panel-mobile` | 28 | Mobile list cards, action tiles, banners, graphite object card |
| `sheet` | 38 | Bottom sheets, drawer |
| `pill` | 9999 | Buttons, chips, search, sort, segmented controls, steppers, progress bars, toast, avatars |

**Concentric rule:** panel 24 containing a tray with 8px inset gives a tray of 16, and a tile inside that tray of 8. With a generous 20-24px panel padding, inner trays keep their own token (16) and are not concentric.

**Pill rule:** pill means "control". A content block is never a pill. Do not mix a pill and a 12px-radius rectangle inside one control group.

---

## 6. Surfaces and elevation

### 6.1 The tonal stack

```
Level 0  shell   #f5f5f7   page
Level 1  panel   #ffffff   a group of content
Level 2  tray    #f5f5f7   a subgroup inside a panel (info trays, measurement trays, the add-item form)
Level 3  tile    #ffffff   an input or row inside a tray
```

White on parchment on white. Never a fourth level. If you need one, restructure.

### 6.2 The shadow budget

| Name | Value | Where |
|---|---|---|
| `product` | `3px 5px 30px rgba(0,0,0,0.22)` | The graphite object card, an illustration resting on a surface |
| `float` | `0 8px 32px rgba(0,0,0,0.10)` | Toast, popover, floating action bar, drawer, round glass buttons |
| `sheet` | `0 -10px 40px rgba(0,0,0,0.14)` | Bottom sheets only |

**Never** a shadow on panels, trays, tiles, rows, buttons, inputs, chips, nav items.

### 6.3 The graphite object card (the signature surface)

This is the glossy dark card. It reads as polished glass over dark metal.

```css
.object-card {
  position: relative;
  color: #fff;
  background: linear-gradient(135deg, #3d3d40 0%, #1d1d1f 36%, #0a0a0b 100%);
  border-radius: 24px;                         /* 28px on mobile */
  box-shadow: 3px 5px 30px rgba(0,0,0,.22),
              inset 0 0 0 1px rgba(255,255,255,.12),
              inset 0 1px 0 rgba(255,255,255,.28);   /* the rim */
  overflow: hidden;
}
.object-card::before {                          /* the sheen */
  content: ""; position: absolute; inset: 0; pointer-events: none;
  background: linear-gradient(105deg, rgba(255,255,255,0) 34%, rgba(255,255,255,.11) 44%,
              rgba(255,255,255,.02) 50%, rgba(255,255,255,0) 58%);
}
.object-card .row {                             /* nested rows inside the card */
  background: rgba(255,255,255,.06); border-radius: 18px; padding: 12px 16px;
}
.object-card .tick-strip {                      /* the signature motif, bottom edge (mobile) */
  height: 28px; background: rgba(0,0,0,.25);
  background-image: repeating-linear-gradient(90deg, rgba(255,255,255,.28) 0 1px, transparent 1px 22px);
  mask-image: linear-gradient(transparent 0, #000 40%);
}
```

Rules: one object card per screen. It holds the hero number, a label, and at most two nested action rows. Inside it, actions are **primary pills sized small (32-36px)** or white-on-translucent. It may tilt up to 9° on Y and 7° on X with springs on pointer devices (mobile detail card), returning to rest on release. Never use it for lists, never as decoration.

### 6.4 Illustration objects

A hung tag, a stack of two cards, a spool: one or two flat-3D objects in **graphite plus one orange**, soft shadow underneath, drawn at 3/4 view with a gentle rotation (about 5-8°). Placed on a parchment square (detail header, 100-140px), in the empty state (in a `shell` rounded panel), in the drawer footer, or overlapping the object card's top-right corner so it hangs from a string. See 12.2.

---

## 7. Glass

### 7.1 Tiers

| Tier | Fill | Backdrop | Edge | Used for |
|---|---|---|---|---|
| Thin | `rgba(255,255,255,.55)` | `blur(20px) saturate(180%)` | 1px `rgba(255,255,255,.75)` | Round floating buttons (hamburger, back) |
| Regular | `rgba(245,245,247,.72)` | `blur(26px) saturate(180%)` | top `rgba(255,255,255,.65)`, bottom `rgba(0,0,0,.06)` | Toast, popover, floating action bar, scrolled top bar, modal |
| Thick | `rgba(245,245,247,.70)` | `blur(28px) saturate(190%)` | same | Bottom sheet, drawer |
| Dark | `rgba(39,39,41,.72)` | `blur(28px) saturate(180%)` | 1px `rgba(255,255,255,.12)` | Desktop toast (dark pill "Order #529 is now Delivered · Undo"), layers over dark surfaces |

### 7.2 Rules

- Bright 1px top edge on every glass layer.
- Never glass on glass; a popover over a glass bar becomes solid white.
- Color goes on a solid layer inside the glass, not on the glass (a selected tab is a solid white pill, not a tinted glass).
- Modals: dim to focus (scrim `rgba(0,0,0,.34)` and a blur of the page behind). The page behind scales to 0.93 on mobile sheets.
- Fallbacks are mandatory:

```css
@media (prefers-reduced-transparency: reduce) { .glass { background: #f5f5f7; backdrop-filter: none; } }
@media (prefers-contrast: more) { .glass { background: #f5f5f7; border-color: #333; backdrop-filter: none; } }
```

---

## 8. Structure theory (layout archetypes)

Pick the structure by what the user is trying to do. The full decision procedure with wireframes is in the companion skill. Summary:

| User intent | Archetype | Skeleton |
|---|---|---|
| "How am I doing, what needs me?" | **Pulse + Work** (dashboard / list home) | Summary band → control band → master-detail |
| "Find and act on one of many" | **Master-detail** | Table panel (8) + sticky aside (4) |
| "Understand one thing completely" | **Detail page** | Back link → header card → info trays → items table → sticky money aside |
| "Create or edit something" | **Form with live summary** | Stacked section panels (8) + sticky graphite summary (4) |
| "Configure the system" | **Settings** | List panel with add-row (8) + stacked option cards (4) |
| "Do one fast operational task" | **Queue** | Search pill + one panel of rows, each with one inline primary action |
| "Confirm or warn" | **Overlay** | Modal (desktop) or glass sheet (mobile) with icon, title, one sentence, two buttons |
| "Nothing here yet / loading" | **State panels** | Illustration + one sentence + one primary / skeleton shaped like the real layout |
| "Persuade a visitor" (extended) | **Marketing page** | Alternating bands: shell → white → graphite; one hero object; one CTA per band |

---

## 9. CTA positioning theory

The user must always know the one thing to do next and where it will be.

### 9.1 The rules

1. **One primary per region.** A region is a panel, a modal, a sheet, a page header. The primary is a blue pill. A second action in the same region is Ghost (blue outline) or Tray (parchment).
2. **Page-level actions live top-right of the header band**, ordered ghost first, primary last: `[Delivery] [+ New order]`. The primary is the right-most, which is where the eye and the cursor land when scanning right to left.
3. **Record-level actions live in the header card of that record**, directly under the title: `[Edit order] [🗑]`. Primary pill with icon plus a round icon-only danger-tinted button.
4. **Money-moving actions belong to the money.** The `Pay ৳5,100` button is the last element inside the money aside, full width, because it acts on the number above it. On mobile it becomes the wide pill in the floating bottom bar.
5. **Inline row actions are small primary pills inside the row**, aligned to the trailing edge (`Deliver`, `Pay ৳500`). They appear on every row of a queue; the row is the object, the pill is the verb.
6. **Form submit lives with the summary.** The save button is the last item in the sticky graphite summary card, full width, with one helper caption under it that says what is missing ("Needs a customer name, BD number and one item."). `Cancel` is a Ghost pill in the page header, never next to Save.
7. **Destructive actions are never primary blue and never first.** Icon-only round button with a red glyph on a `negative-tint` circle, placed after the primary. Confirming is two steps; the final button is solid `negative` red.
8. **Modals:** two equal-width buttons, side by side, 44px: left = quiet (Tray, "Cancel"), right = the action (blue, or red for destructive). Never three buttons.
9. **Mobile:** the primary lives at the bottom in a floating glass capsule (full width minus 20px sides, 22px above the safe area), because thumbs live there. Quick creation actions at the top of a home screen are **action tiles**, not buttons.
10. **Empty states** carry the one primary that fixes the emptiness, centered under the sentence.
11. **Undo** is a blue text button at the right end of the toast, never a primary pill.
12. **Links** in running text and "Open Delivery ›" style navigation are blue text with a chevron, 44px hit area.

### 9.2 Placement map

```
DESKTOP                                         MOBILE
┌ page header ─────────────────────────┐        ┌ bar ─────────────────────┐
│ Title / subtitle     [Ghost][Primary]│        │ ☰      Title             │
├──────────────────────────────────────┤        ├──────────────────────────┤
│ summary band (inline small primaries)│        │ hero numeral + chips     │
│ controls: chips · search · sort      │        │ [tile][tile][tile] ← actions
│ ┌ list ─────────────┐ ┌ aside ─────┐ │        │ banner (link ›)          │
│ │ row … [inline pill]│ │ money      │ │        │ chips (scroll)           │
│ └────────────────────┘ │ [Pay ৳]    │ │        │ list card rows           │
│                        └────────────┘ │        │                          │
└──────────────────────────────────────┘        │  [🗑][✎][  Pay ৳5,100  ] │ ← floating glass
                                                └──────────────────────────┘
```

### 9.3 Button anatomy

| Variant | Fill | Label | Radius | Height | Use |
|---|---|---|---|---|---|
| Primary | `primary` | white 17/400 (15/600 compact) | pill | 44 (36 inline, 52 mobile bar) | The one action in a region |
| Ghost | transparent, 1px `primary` | `primary` | pill | 44 | Secondary next to primary (Delivery, Cancel) |
| Tray | `shell` | ink 14/600 | pill | 44 | Quiet action inside a panel/modal (Cancel, Keep editing) |
| Destructive | `negative` | white | pill | 44 | Final delete only |
| Icon round | `shell` or glass | ink glyph (red glyph on `negative-tint` for delete) | pill | 36-44 | Edit, delete, close, back |
| Text | none | `primary` | n/a | 44 hit | Undo, "Open Delivery ›", back link "‹ Orders" |

Press: scale 0.95 (cards 0.97) in 100ms starting on pointer down. Focus: 2px `primary-focus` ring with 2px offset. Disabled: fill `divider`, label `ink-48`. No shadow on any button. Labels are verbs with the object and amount when there is one: "Pay ৳5,100", "Update order", "Save order".

---

## 10. Components

### 10.1 Cards: choose by content

| Content | Card | Surface | Radius |
|---|---|---|---|
| A group (list, table, form section, settings list) | **Panel** | white on shell | 24 / 28 |
| A subgroup inside a panel | **Tray** | shell in white | 16 |
| One number with label | **Stat tile** | shell in white panel | 18 |
| The number the page is about | **Object card** | graphite | 24 / 28 |
| Rows in a queue | **List card** | white, inset dividers | 24 / 28 |
| 3 quick actions (mobile) | **Action tiles** | white on shell | 24-28 |
| Time-critical message | **Dark banner** | graphite, dismissible | 28 |
| Floating layer | **Glass layer** | glass tier | per layer |
| Entity key facts (customer, order) | **Info tray** | shell, label above value | 16 |

Never nest a panel in a panel.

### 10.2 Summary band

One white panel (24px padding, radius 24) containing two tiles side by side with a 20px gap:

- **Left, paper tile** (`shell`, radius 18-24): label in 15/600 `ink-80`, big count numeral (stat-xl) with a gray unit ("orders · next 3 days"), then up to two nested white rows (name + meta left, date right). The whole tile is a button that applies a filter; when applied it shows a blue 2px outline and a removable chip "Filter: Upcoming ✕" with the hint "Tap the chip to clear the filter."
- **Right, graphite object tile:** label in `on-dark-60`, hero number (stat-xl, white, currency smaller) with a count unit, then up to two nested rows (`graphite-row`) each with name, meta ("#529 · ৳5,100 due") and a small blue `Pay ৳5,100` pill at the trailing edge.

Left holds **time/volume** (count, schedule), right holds **money/risk**. Swap the meaning to your domain, keep the pairing.

### 10.3 Entity chip

A dark rounded square (40px, radius 12, `ink` fill) holding the short identifier in white 12-13px/600 ("#531"). On mobile it holds a tag icon and a 14px status dot with a 2px white ring at the bottom-right corner. It always sits left of the row name. It is the visual anchor that makes rows scannable.

### 10.4 Filter chips, search, sort

- Chip: white fill, 1px hairline, pill, 44px (40 desktop), 14px text, tabular count in `ink-60` ("Pending 2"). **Selected = 2px `primary-focus` ring** (reduce padding 1px to hold size), label stays ink.
- Search: white pill, 44px, 1px `rgba(0,0,0,.08)`, 18px search glyph at left, placeholder `ink-48`, fills the remaining row width.
- Sort: white pill with label "Sort" in `ink-60`, value in ink, chevron. Right-aligned at the end of the control band.
- Mobile: chips scroll horizontally and bleed to the screen edge; search is an action tile.

### 10.5 Tables (desktop, dense tier)

| Part | Spec |
|---|---|
| Panel | White, radius 24, title (22/600) left, helper text right in 13px `ink-60` ("Showing 6 of 6 · tap a row for details") |
| Header band | `shell`, 40px, rounded 12, 12px `ink-60` 600, sentence case |
| Row | 64-68px, 13-15px, `divider` bottom; first column = entity chip + two-line name/meta |
| Inline status | Plain text with a small chevron ("Pending ⌄"), no filled pill. Changing it saves immediately and shows an Undo toast. |
| Numbers | Right-aligned, tabular. Total and Advance in ink, **Due red when owed and green `৳0` when cleared**. |
| Paid column | 4px pill progress bar (ink fill on `divider` track) with "43% paid" 11-12px `ink-60` underneath. "Fully paid" in green when complete. |
| Selected row | `row-selected` fill and radius 12; the aside updates to that row. |
| Missing value | "Not set" in `ink-48`. |
| Below 640px | Becomes list cards |

Columns that matter go first; cap visible columns at 7 to 8. Do not use filled status pills inside tables.

### 10.6 Detail aside (money aside)

Sticky white panel (radius 24, 24px padding):

1. Entity chip + name (title-1) + meta line.
2. Three-segment status bar: three 4px bars, the reached stages filled ink, the rest `divider`, with the stage names under each (12px). It shows the workflow position at a glance.
3. Two date pairs (label 13/ink-60, value 15/600).
4. **Due** label, then the red numeral (stat-xl or larger).
5. A `shell` tray with progress bar, "43% paid", then Total and Advance side by side.
6. Full-width primary `Pay ৳5,100`.

On the full detail page the aside carries a status chip in the top-right ("Pending delivery" ember-wash, "Delivered" positive-tint), the red numeral, progress, and a tray with Total / Discount / Advance / Received later rows.

### 10.7 Detail page header card

White panel, 24px radius. Left: 140px parchment square holding the tag illustration. Right: eyebrow "Order #531" (14/400 `ink-60`), name (page-title 36/600), a chip row (`Officer` ink pill, status dot + label, BD number in `ink-60`), then actions: primary "Edit order" with a pencil icon and a round delete button (36px, `negative-tint`, red glyph).

Under it: two **info trays** side by side (Customer, Order). Each tray: title 15/600, then a 2-column grid of label (12px `ink-60`) over value (15/600). Highlight a derived value in green ("Delivered on 2026-10-22").

### 10.8 Form sections

- Each section is a white panel with a title (22/600), then content. Order: Items → Customer and dates → Measurements (or the domain's detailed data).
- **Add-row control:** a search/select pill with a count ("28 items ⌄"), a quantity field, and a Tray pill "+ Add item". Added rows appear in a `shell` tray as white rows: name + "৳800 each" left, "× 1", unit price, bold line total, round ✕.
- **Fields:** white, 1px hairline, radius 12, 44px high. Label above in 13/600. Helper below in 12px (`positive` with a check for "Filled from the saved customer"). Group related fields in a 3-column grid.
- **Grouped detail data** (measurements) sits in `shell` trays (one per group), fields white inside.
- **Validation:** field border `negative-dot`, message under in `negative` with a small "!" icon that says what to do ("Add the customer name, for example F/L Tanvir Ahmed."). Form-level banner at the top of the section: `shell` rounded 16, caution dot, one sentence.
- **Dates:** show formatted, `2026-10-22`, tabular.

### 10.9 Sticky summary card (form) (graphite)

Graphite object card, sticky top-right, 24px radius, 24px padding: "Total amount" label left and the amount (stat-lg, white) right; caption "Automatic. Price × quantity, added up." Then Discount and Advance inputs (dark inputs: `rgba(255,255,255,.08)` fill, 1px `rgba(255,255,255,.12)`, radius 12, white text, placeholder `on-dark-60`). A hairline, then "Due" with the formula caption ("Total − discount − advance"), the **coral numeral** (`#fe6a6a`, ~56px), a thin white progress bar ("19% paid"), a full-width primary "Save order", and a centered helper caption under it. On mobile the same content is the top of the screen: editable total numeral, chips "Due ৳2,000" and "Unsaved changes", then tabs.

### 10.10 Settings controls

- **Add-row tray** (`shell`, radius 16) with two white inputs and a primary "+ Add item".
- **List rows:** name 15/600, price right-aligned tabular, two 36px round icon buttons (`shell`, edit / trash).
- **Attention chip:** "check price" = `ember-wash` fill, `ember-text`, 12/600, pill, 6px 10px, placed right after the price.
- **Segmented control:** `shell` pill container, 4px inset, selected = `ink` pill with white label ("Percentage | Taka").
- **Stepper:** `shell` pill with round white − and + buttons and the value centered 24/600.
- **Value chips** ("0 ✕", "3 ✕"): white pill, hairline, remove glyph; plus a Tray pill "+ Add value". A **ruler tick illustration** above them shows the values as dark pills pinned on a tick strip.
- Each option group is its own white card with title (22/600), one-line description (`ink-60`), then the control.
- A footnote under the list explains the safety rule in plain words.

### 10.11 Overlays

**Modal (desktop) and glass modal (mobile).** Width 400-440px, radius 28, `canvas` on desktop, regular glass on mobile; scrim behind.

```
┌ (●) icon circle 40px, tint bg                 Step 1 of 2 ▬▭ ┐
│ Title 22/600, max 2 lines                                    │
│ One sentence, 15/400 ink-60                                  │
│ [   Cancel (tray)   ] [   Continue (blue)   ]                │
└──────────────────────────────────────────────────────────────┘
```

- The icon circle is `negative-tint` with a red glyph for destructive, `canvas` or `shell` with ink glyph for neutral (the "৳" circle on the pay confirmation).
- Two-step delete: step 1 = blue "Continue" and the sentence "Check the order before you go on. You will be asked once more."; step 2 = title "This cannot be undone. Delete permanently?", the consequence sentence ("Later Officer orders move down by one number."), and a solid red "Delete". Show "Step 1 of 2" with two small pill segments.
- Money confirm: "Receive ৳5,100 from W/C Mahbub Alam for order #529?" / "Cash received at the shop. This clears the whole due." / [Cancel] [Received].
- Unsaved changes: ember-wash "Unsaved changes" chip, "Leave without saving?", [Keep editing] [Leave].

**Bottom sheet (mobile status picker):** thick glass, radius 38, grab handle (36×5px pill `ink-48`@40%), title 24/600, context line "F/L Tanvir Ahmed · any direction is fine", rows 56px: colored dot, label 17/600, optional helper ("Saves today as the delivered date"), a check on the selected row (white row card). Footer caption: "Saves right away. Pay records are never touched."

### 10.12 Toast

Glass pill, 56px high, `float` shadow, bottom-center (desktop dark glass, mobile light glass). Past-tense verb plus the object ("Order #529 is now Delivered"), then a blue "Undo" at the trailing end. Auto-dismiss at about 3.5s. `role="status"`.

### 10.13 Banners and chips

- **Dark banner** (mobile): graphite, radius 28, 20px padding, 44px translucent icon circle, title 17/600 white, meta 15/400 `on-dark-60`, link "Open Delivery ›" in `primary-on-dark`, a ✕ at the top-right. At most one per screen, always dismissible.
- **Delta/notice chip:** pill, 22-28px high, 12-14px/600. `negative-tint` + `negative` for risk ("2 orders"), `ember-wash` + `ember-text` for time ("2 to deliver in 3 days", "Today", "Delivery Oct 27"), `positive-tint` + `positive` for good ("40% paid", "Delivered Oct 22").
- **Status chip in an aside:** same pill, top-right of the aside ("Pending delivery").

### 10.14 Skeleton, empty, error

- **Skeleton:** mirrors the real layout (hero lines, three tiles, five rows with an avatar square, two text bars, one amount bar) in `skeleton` gradient with a slow left-to-right shimmer. No spinner.
- **Empty:** a `shell` rounded panel holding the illustration (two stacked cards: orange back, graphite front with "#1" chip and a "+" badge), then a title ("No orders yet." 22/600), one sentence ("Tap New Order to add the first one."), and the one primary pill with a "+" glyph. The hero metric shows a real zero (`৳0`, "0 orders" in green tint) rather than hiding.
- **Queue empty:** a white panel with an icon circle (`shell`) and one sentence ("Nothing waiting for delivery.").
- **Blocked save:** banner plus field-level errors (10.8).
- **Impossible number:** inline error in a `negative-tint` rounded block with a dot ("The money already received is more than the total. Please check the amounts.").

### 10.15 Progress

4px (table) to 6-8px (aside) pill track `divider`, fill `ink`. Over 100%-type problems use `negative`. A ring (mobile card) shows the same percentage in a 56px white stroke ring with the value inside. Always show the text value.

---

## 11. Data display rules

| You have | Show it as |
|---|---|
| The one number the page is about | Object card numeral (desktop) / `numeral-lg` (mobile) |
| A count plus a schedule | Paper tile with numeral and unit |
| An amount owed | Red numeral, `৳0` green when cleared, progress under it |
| Paid vs total | Pill progress + "43% paid" + Total / Advance pair |
| A workflow position | Three-segment bar (aside) and a dot (row) |
| A list of records | Table (desktop) → list card (mobile) |
| One record's facts | Info trays with label over value |
| A trend over time (extended) | Bar chart in its own panel: solid ink = actual, ember hatch = forecast, dashed hairline grid |
| A distribution (extended) | Segmented bar with dot labels |

Every figure shows label, value and context (period or comparison). Currency sign first, thousands separators, tabular.

---

## 12. Iconography, illustration, motif

### 12.1 Icons

Line icons, 1.5px stroke, round caps and joins, `currentColor`. 20px in rows and nav, 18px in buttons, 24px in tiles. Ink on light, white on graphite. Icons sit in containers (44px round glass, 36px round `shell`, 40px tint circle in modals). Decorative icons may be omitted.

### 12.2 The illustration language

- One domain object per product, rendered as a soft 3D flat object: rounded corners, graphite body with a subtle gradient, **one orange accent** (coin, ribbon, back card), a tiny highlight, a soft contact shadow.
- Use at three scales: 140px on the detail header parchment square, 200-260px in empty states and the drawer footer, and as a hanging object at the top-right of the mobile object card (with a short string line above it).
- Never stock photos, never emoji, never generic "people at laptops".

### 12.3 The signature motif

Each product gets one repeating motif derived from its domain, used as a texture strip: Darzi uses the **tape-measure tick strip** (thin 1px ticks every ~22px, every fifth taller). Use it on the bottom edge of the graphite card, in the ribbon-values card, and as a divider in empty states. For another domain pick something equally concrete: pill-blister dots (clinic), graph-paper ticks (school), pallet slats (warehouse), cable pins (IT). The motif is a quiet 1px texture, never a pattern wallpaper.

---

## 13. Motion

- Respond on pointer down. Press scale 0.95 / 0.97 / 0.92 in 100ms.
- Everything touched is a spring and can be interrupted. Defaults: damping 1.0, response 0.35; with momentum: damping 0.8, response 0.3.
- Toasts and glass layers **materialize** (blur, scale 0.92 to 1 and opacity together, 320-420ms) rather than fade.
- Sheets rise on a spring; the page behind scales to 0.93 with 44px corners on mobile.
- Status change in a row: update immediately, show Undo toast, no blocking spinner.
- Skeleton shimmer only; no page-load choreography.
- The graphite card sheen can drift slowly (one pass, 6-8s) and tilt on pointer move; nothing else loops.
- Respect `prefers-reduced-motion`: replace springs with short fades, remove tilt and shimmer.

---

## 14. Voice and copy

- Plain and specific, sentence case, no jargon, no exclamation marks, no "Oops".
- Page subtitle states what the page holds ("Every Officer order, from first fitting to final due.").
- Buttons say the verb and object ("New order", "Update order", "Pay ৳5,100", "Received").
- Helper text states the rule in one sentence ("Saves right away. Pay records are never touched.").
- Toasts are past tense with the object ("Order #528 delivered") plus Undo.
- Warnings say what is missing and how to fix it ("Add the customer name, for example F/L Tanvir Ahmed.").
- Confirmations state the consequence ("Later Officer orders move down by one number.").
- Empty states say what will appear and give the first step.
- Numbers: `৳1,200`, dates "Oct 22" in lists and "2026-10-22" in forms and detail, durations "2h 30m", percentages "43% paid".

---

## 15. Accessibility

- 44px touch targets (36px dense on pointer fine).
- Text contrast 4.5:1, UI shapes 3:1 (section 2.5). Never `ink-48` for live text.
- Real `<button>`, `<a href>`, `<input>` with labels. Icon-only controls get `aria-label`.
- Visible focus: 2px `primary-focus`, 2px offset.
- Status is dot plus text, never color alone. Due amounts are red **and** labelled "Due".
- Toasts `role="status"`. Modals trap focus and return it on close.
- Respect reduced motion, reduced transparency, increased contrast.
- Sizes in `rem`; layout survives 200% zoom.

---

## 16. Tokens (copy-paste)

```css
:root {
  /* surfaces + ink */
  --shell:#f5f5f7; --canvas:#ffffff; --row-selected:#f0f0f0; --hairline:#e0e0e0; --divider:#f0f0f0;
  --ink:#1d1d1f; --ink-80:#333333; --ink-60:#6e6e73; --ink-48:#7a7a7a; --on-dark:#ffffff; --on-dark-60:rgba(255,255,255,.64);
  /* graphite */
  --graphite: linear-gradient(135deg,#3d3d40 0%,#1d1d1f 36%,#0a0a0b 100%);
  --graphite-row: rgba(255,255,255,.06);
  --sheen: linear-gradient(105deg,rgba(255,255,255,0) 34%,rgba(255,255,255,.11) 44%,rgba(255,255,255,.02) 50%,rgba(255,255,255,0) 58%);
  /* interactive */
  --primary:#0066cc; --primary-focus:#0071e3; --primary-on-dark:#2997ff; --primary-wash:rgba(0,102,204,.10);
  /* ember */
  --ember-400:#fa7e42; --ember-500:#f0561f; --ember-text:#c2410c; --ember-wash:#fdeee7;
  /* status */
  --positive:#1e7b43; --positive-dot:#2e9e54; --positive-tint:#e3f4e8;
  --negative:#c62828; --negative-dot:#e5484d; --negative-tint:#fceaea; --negative-on-dark:#fe6a6a;
  --caution-dot:#f2a93b; --stage-dot:#7a4fd2;
  /* glass */
  --glass-thin:rgba(255,255,255,.55); --glass-regular:rgba(245,245,247,.72); --glass-thick:rgba(245,245,247,.70); --glass-dark:rgba(39,39,41,.72);
  --glass-edge-top:rgba(255,255,255,.65); --glass-edge-bottom:rgba(0,0,0,.06); --scrim:rgba(0,0,0,.34);
  --blur-thin:blur(20px) saturate(180%); --blur-regular:blur(26px) saturate(180%); --blur-thick:blur(28px) saturate(190%);
  /* shape */
  --r-chip:12px; --r-input:12px; --r-tray:16px; --r-tile:18px; --r-panel:24px; --r-panel-m:28px; --r-sheet:38px; --r-pill:9999px;
  /* space */
  --s-1:4px; --s-2:8px; --s-3:12px; --s-4:16px; --s-5:20px; --s-6:24px; --s-8:32px; --s-12:48px; --s-20:80px;
  /* shadow (the entire budget) */
  --shadow-product:3px 5px 30px rgba(0,0,0,.22);
  --shadow-float:0 8px 32px rgba(0,0,0,.10);
  --shadow-sheet:0 -10px 40px rgba(0,0,0,.14);
  --rim-dark:inset 0 0 0 1px rgba(255,255,255,.12), inset 0 1px 0 rgba(255,255,255,.28);
  /* type */
  --font-display:"SF Pro Display",-apple-system,BlinkMacSystemFont,Inter,"Noto Sans Bengali",system-ui,sans-serif;
  --font-text:"SF Pro Text",-apple-system,BlinkMacSystemFont,Inter,"Noto Sans Bengali",system-ui,sans-serif;
  /* layout */
  --sidebar:264px; --sidebar-collapsed:72px; --content-max:1440px; --aside:360px; --gutter:20px;
}
html { background:var(--shell); color:var(--ink); font:400 17px/1.47 var(--font-text); letter-spacing:-.374px; -webkit-font-smoothing:antialiased; }
.num { font-variant-numeric:tabular-nums; }
.btn { border-radius:var(--r-pill); height:44px; padding:0 22px; transition:transform 100ms ease-out; }
.btn:active { transform:scale(.95); }
.btn-primary { background:var(--primary); color:#fff; }
.btn-ghost { border:1px solid var(--primary); color:var(--primary); background:transparent; }
.btn-tray { background:var(--shell); color:var(--ink); font-weight:600; }
.btn-danger { background:var(--negative); color:#fff; }
.panel { background:var(--canvas); border-radius:var(--r-panel); padding:24px; }
.tray { background:var(--shell); border-radius:var(--r-tray); padding:16px; }
.chip { background:#fff; border:1px solid var(--hairline); border-radius:var(--r-pill); height:40px; padding:0 16px; font-size:14px; }
.chip[aria-pressed="true"] { border:2px solid var(--primary-focus); padding:0 15px; }
.glass { background:var(--glass-regular); backdrop-filter:var(--blur-regular); border:1px solid var(--glass-edge-top); border-bottom-color:var(--glass-edge-bottom); }
.dot { width:8px; height:8px; border-radius:50%; display:inline-block; }
.progress { height:4px; border-radius:99px; background:var(--divider); } .progress > i { display:block; height:100%; border-radius:inherit; background:var(--ink); }
```

---

## 17. Do and Don't

**Do**

- Stack white on parchment on white; let tone do the separating.
- Give each screen one hero: one numeral or one graphite object.
- Make the "unfinished business" number the hero and red until it is zero.
- Use blue for every pressable thing and only for pressable things.
- Keep orange tiny: illustration, one notice chip, one attention fill.
- Pair every status with a dot and a word; pair every money figure with a progress bar and a percentage.
- Put page actions top-right (ghost then primary), record actions under the title, money actions inside the money aside, submit actions inside the summary card.
- Put glass only on floating layers with a bright top edge and fallbacks.
- Prefer Undo to confirmation; use two-step confirmation with a step indicator only for permanent deletion.
- Retarget the illustration and motif to the new domain; keep the construction.

**Don't**

- Don't add a shadow to panels, trays, tiles, rows, buttons, inputs or chips.
- Don't use orange on buttons or links, or blue on non-interactive things.
- Don't use weights 500/700, all caps, or one tracking value for every size.
- Don't use filled status pills inside tables (dot plus label).
- Don't put two graphite object cards or two big numerals on one screen.
- Don't use a top navigation bar for the primary navigation (this system uses a sidebar and a mobile drawer).
- Don't nest panels in panels or go beyond three tonal levels.
- Don't use decorative gradients, stock photography, emoji as icons, or a spinner where a skeleton works.
- Don't put Cancel next to Save in the form; Cancel is a ghost in the page header.
- Don't use red as decoration; red is only for amounts owed, destructive actions and errors.

---

## 18. Screen inventory (what the Darzi screens prove)

| Screen | Archetype | Notes worth copying |
|---|---|---|
| Orders (desktop) | Pulse + master-detail | Summary band (paper + graphite), chips with counts, search + sort, table with inline status, sticky aside with money and Pay, dark toast with Undo |
| Orders (mobile) | Pulse list | 80px hero numeral, two chips, three action tiles, dark banner with link, chips, list card with status-dot avatars |
| New order (desktop) | Form with live summary | Stacked section panels, trays for grouped measurements, sticky graphite summary with coral due and Save |
| Edit order (mobile) | Tabbed form | Editable total numeral, chips for due and unsaved, tab pill (Items / Customer / Measure / Money), steppers, floating Update bar |
| Order detail (desktop) | Detail page | Header card with illustration, info trays, items table, payments table, measurements trays, sticky money aside |
| Order detail (mobile) | Detail | Red due numeral, graphite entity card with hanging tag, ring progress and tick strip, bottom sheet items, floating delete / edit / pay bar |
| Delivery | Queue | Search pill, one panel of rows, inline `Deliver` pills, "Today" ember chip, waiting count in a small graphite tile, explanation footnote |
| Settings | Settings | Add-row tray + list with round icon buttons, "check price" chip, segmented control, stepper, ribbon chips with tick strip |
| Drawer (mobile) | Navigation | Thick glass, profile capsule, ink-pill active item, illustration footer |
| Modals | Overlay | Tint icon circle, two equal buttons, two-step delete with step indicator, pay confirm, unsaved changes |
| Status sheet | Overlay | Dot rows, check on selected, helper that states the side effect |
| Empty / Loading | State | Illustration + sentence + primary; skeleton shaped like the real layout |
