# Implementation Plan: Shopify Admin (Polaris 2025) Design Transformation for Raymond

Transform Raymond into a professional, calm, utilitarian workbench strictly adhering to the **Shopify Admin (Polaris 2025 era)** design specification and tokens from `DESIGN-1_0577486b.md` and `SKILL-1_a8c34442.md`.

## 1. Operating Contract & Architecture
- **Strict presentation-only transformation**: Retain all existing business logic, validation rules, state shape, restore algorithms, numeric keypad behaviors, print previews, and military order specifications.
- **The 4-Layer Surface Hierarchy**:
  - `Layer 0 (Chrome)`: `#1A1A1A` (56px fixed top bar)
  - `Layer 1 (Rail)`: `#EBEBEB` (240px fixed left sidebar with `#FAFAFA` selected nav pills)
  - `Layer 2 (Canvas)`: `#F1F1F1` (Page background, 24px padding)
  - `Layer 3 (Cards & Tables)`: `#FFFFFF` (12px rounded cards, 1px `#E3E3E3` hairline border, subtle `0 1px 0 rgba(26,26,26,0.07)` shadow)
- **Typography & Voice**: Inter font with base `13px/20px` body, `14px/20px` card titles (weight 650), `20px/28px` page titles (weight 650). Strict sentence case throughout.
- **Color Discipline**: Color is spent only on meaning. Primary actions use the near-black `#303030` button. Status uses Polaris semantic pills (`#AFFEBF` for delivered/done, `#FEE9E8` for due/critical, `#E3E3E3` for neutral drafts/pending).

---

## 2. Phased Implementation Steps

### Phase 1: Tokens and Global Styles
- Create `/src/design/tokens.css` with the complete CSS custom properties defined in Section 10 of `DESIGN.md` (surfaces, typography scales, spacing, border radii, shadows, status fills).
- Update `/src/index.css` to import `tokens.css`, apply the Polaris body reset (`font: 450 13px/20px var(--font-sans)`, background `--surface-chrome`), and configure focus visible rings (`2px solid #005BD3`).

### Phase 2: App Shell (`AppFrame`, `TopBar`, `Sidebar`)
- Build `/src/components/polaris/TopBar.tsx`:
  - 56px height, `#1A1A1A` background.
  - Left: Raymond brand lockup with white monochrome tailor scissors mark and serif wordmark.
  - Center: 650px max-width dark search bar (`#303030`, radius 16px) with `⌘K` keycaps and search icon.
  - Right: Notifications bell with red counter badge, and BAF Outfitter store switcher avatar (28px rounded square).
- Build `/src/components/polaris/Sidebar.tsx`:
  - 240px width, `#EBEBEB` background.
  - Flat list of all 10 core destinations: Dashboard, Officer Orders, Airman Orders, Delivery, Drafts (with live count badge), Customers, Customer History, Staff Management, Staff Summary.
  - Pinned footer: Settings (gear icon) positioned 20px above the bottom.
  - Polaris icon toggle: unselected items use filled icons in `#3A3A3A`, selected items use outline icons in `#000` with the `#FAFAFA` 8px-radius pill.
  - Responsive mobile drawer support for small screens.
- Build `/src/components/polaris/GlobalSearchModal.tsx`:
  - Polaris `⌘K` search overlay with category chips (Orders, Customers, Staff) and quick jump navigation.
- Update `/src/App.tsx` to wrap pages inside `AppFrame`.

### Phase 3: Core UI Component Library
- Create reusable Polaris components in `/src/components/polaris/`:
  - `PolarisPage`: Standard header with title (20/650), optional back button, and primary/secondary action slots.
  - `PolarisCard`: White 12px-radius card with header, optional tabs, dividers, and inset sections.
  - `PolarisButton`: Primary (`#303030`), Secondary canvas (`#E3E3E3`), Secondary card (`#FFFFFF` with border).
  - `PolarisBadge`: Status pill (20px height, 8px radius) with tone mapping (`success`, `neutral`, `info`, `critical`).
  - `PolarisTabs`: 28px height pills with `#EBEBEB` active pill and hairline bottom divider.
  - `PolarisTable`: 54px rows, 37px header, hairline dividers, right-aligned numbers with `tabular-nums`.

### Phase 4: Page Restyling
- **Orders & Airman Screens**: Replace tab pills with Polaris card tabs, embed table within a unified card, use 54px row layout, and style action buttons.
- **Order Forms (Officer & Airman)**: Polaris two-column layout (main 2/3 forms, side 1/3 summary & ribbon/branch), clean form controls with 13px labels and numeric keyboards.
- **Staff Management & Month Worksheets**: Seamless month folders with distinct color chips, 10-column month table within Polaris table cards, and payslip actions.
- **Staff Summary**: Polaris KPI metric card (4-column stat block with hover highlight) and ranking list.
- **Dashboard**: Polaris metrics cards, branch split, and overdue deliveries card.
- **Settings Screen**: 11 clean Polaris section cards with annotated titles, list editors, deleted orders tab table, and data backup actions.

### Phase 5: Verification & Polish
- Ensure zero regression on all acceptance criteria (BD suggestions, numeric keypad, restore shifts, no "optional" labels).
- Validate with `lint_applet` and `compile_applet`.
- Verify mobile responsiveness and dev server execution.
