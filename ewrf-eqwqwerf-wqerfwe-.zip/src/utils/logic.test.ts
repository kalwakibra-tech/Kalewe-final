import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateDiscount,
  calculateDue,
  isNewTotalValidForReceived,
  renumberOrdersOnDelete,
  isOrderUpcoming,
  validateAirmanIvNumbers,
  calculateWorkerMonthHishab,
} from './logic.ts';
import { AirmanOrder } from '../types/index.ts';

test('calculateDiscount handles percentage and taka with default fallbacks', () => {
  // Explicit percentage
  const p1 = calculateDiscount(1000, '10%', 'taka');
  assert.equal(p1.amount, 100);
  assert.equal(p1.type, 'percentage');

  // Plain number when default is taka
  const t1 = calculateDiscount(1000, '150', 'taka');
  assert.equal(t1.amount, 150);
  assert.equal(t1.type, 'taka');

  // Plain number when default is percentage
  const p2 = calculateDiscount(1000, '15', 'percentage');
  assert.equal(p2.amount, 150);
  assert.equal(p2.type, 'percentage');
});

test('calculateDiscount with percentage default and taka default', () => {
  const dPercent = calculateDiscount(2000, '10', 'percentage');
  assert.equal(dPercent.amount, 200);

  const dTaka = calculateDiscount(2000, '100', 'taka');
  assert.equal(dTaka.amount, 100);

  const empty = calculateDiscount(2000, '', 'percentage');
  assert.equal(empty.amount, 0);
});

test('calculateDue subtracts discount, advance and subsequent payments', () => {
  const due1 = calculateDue(1050, 0, 200, []);
  assert.equal(due1, 850);

  const due2 = calculateDue(1050, 100, 200, [{ id: '1', amount: 300, date: '2026-09-15' }]);
  assert.equal(due2, 450);

  // Due never negative
  const due3 = calculateDue(500, 0, 600, []);
  assert.equal(due3, 0);
});

test('isNewTotalValidForReceived blocks edit if money received > new total', () => {
  assert.equal(isNewTotalValidForReceived(1000, 500), true);
  assert.equal(isNewTotalValidForReceived(400, 500), false);
  assert.equal(isNewTotalValidForReceived(500, 500), true);
});

test('renumberOrdersOnDelete renumbers all later orders down by one', () => {
  const orders = [
    { id: 'a', orderNumber: 1 },
    { id: 'b', orderNumber: 2 },
    { id: 'c', orderNumber: 3 },
    { id: 'd', orderNumber: 4 },
  ];

  const result = renumberOrdersOnDelete(orders, 2);
  assert.equal(result.length, 3);
  assert.deepEqual(
    result.map((o) => o.orderNumber),
    [1, 2, 3]
  );
  assert.equal(result.find((o) => o.id === 'c')?.orderNumber, 2);
  assert.equal(result.find((o) => o.id === 'd')?.orderNumber, 3);
});

test('isOrderUpcoming identifies orders within window from today forward', () => {
  const today = '2026-09-15';
  const upcomingDays = 3;

  assert.equal(isOrderUpcoming('2026-09-15', false, today, upcomingDays), true);
  assert.equal(isOrderUpcoming('2026-09-17', false, today, upcomingDays), true);
  assert.equal(isOrderUpcoming('2026-09-18', false, today, upcomingDays), true);
  // Beyond window
  assert.equal(isOrderUpcoming('2026-09-20', false, today, upcomingDays), false);
  // Past date not counted
  assert.equal(isOrderUpcoming('2026-09-14', false, today, upcomingDays), false);
  // Delivered orders not counted
  assert.equal(isOrderUpcoming('2026-09-16', true, today, upcomingDays), false);
  // No delivery date not counted
  assert.equal(isOrderUpcoming('', false, today, upcomingDays), false);
});

test('validateAirmanIvNumbers detects conflicts across different BD numbers', () => {
  const existingOrders: AirmanOrder[] = [
    {
      id: 'ord-1',
      orderNumber: 1,
      category: 'Airman',
      customerBdNumber: 'BD-1001',
      customerName: 'Rahim',
      customerPhone: '',
      orderDate: '2026-09-15',
      trade: 'Logistics',
      ribbon: '3',
      office: 'HQ',
      runningYear: '2026–2027',
      status: 'Pending',
      items: [{ id: 'i1', name: 'Battle Uniform', quantity: 1, ivNumber: 'IV-5521' }],
      shirtMeasurements: {} as any,
      pantMeasurements: {} as any,
      createdAt: '',
      updatedAt: '',
    },
  ];

  // Same BD reusing IV-5521 is allowed
  const sameBdCheck = validateAirmanIvNumbers(
    [{ ivNumber: 'IV-5521' }],
    'BD-1001',
    existingOrders
  );
  assert.equal(sameBdCheck.valid, true);

  // Different BD trying to use IV-5521 is refused
  const diffBdCheck = validateAirmanIvNumbers(
    [{ ivNumber: 'IV-5521' }],
    'BD-9999',
    existingOrders
  );
  assert.equal(diffBdCheck.valid, false);
  assert.match(diffBdCheck.error || '', /already belongs to BD BD-1001/);
});

test('calculateWorkerMonthHishab calculates work, khoroch, net payable, received, due and status', () => {
  const rows = [
    {
      id: 'r1',
      workerId: 'w1',
      date: '2026-09-10',
      serial: '1',
      bdNumber: 'BD-101',
      name: 'Customer 1',
      item: 'Half Sleeve Shirt',
      quantity: 4,
      unitPrice: 250,
      totalTaka: 1000,
      khorochDate: '2026-09-10',
      khoroch: 200,
    },
  ];

  const payments = [
    {
      id: 'p1',
      workerId: 'w1',
      forMonth: '2026-09',
      amount: 300,
      date: '2026-09-20',
      note: 'Part advance',
      createdAt: '',
    },
  ];

  const hishab = calculateWorkerMonthHishab('w1', rows as any, payments, '2026-09');
  assert.equal(hishab.totalAmount, 1000);
  assert.equal(hishab.totalKhoroch, 200);
  assert.equal(hishab.netPayable, 800);
  assert.equal(hishab.received, 300);
  assert.equal(hishab.due, 500);
  assert.equal(hishab.status, 'Partial');
});
