import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { NOTO_SANS_BENGALI_BASE64 } from './bengaliFont.ts';

/**
 * Initializes a new jsPDF document preconfigured with the offline
 * NotoSansBengali font, ensuring native rendering for English,
 * Bengali names, and the currency symbol '৳' (U+09F3).
 */
export function createPDFDoc(orientation: 'portrait' | 'landscape' = 'portrait'): jsPDF {
  const doc = new jsPDF({
    orientation,
    unit: 'pt',
    format: 'a4',
  });

  try {
    doc.addFileToVFS('NotoSansBengali-Regular.ttf', NOTO_SANS_BENGALI_BASE64);
    doc.addFont('NotoSansBengali-Regular.ttf', 'NotoSansBengali', 'normal');
    doc.setFont('NotoSansBengali');
  } catch (err) {
    console.warn('Failed to load embedded Bengali font, falling back to standard font', err);
  }

  return doc;
}

function addPDFHeader(doc: jsPDF, shopName: string, title: string, subtitle?: string): number {
  const pageWidth = doc.internal.pageSize.getWidth();

  doc.setFont('NotoSansBengali', 'normal');
  doc.setFontSize(16);
  doc.setTextColor(26, 26, 26);
  doc.text(shopName || 'Raymond Tailors & Outfitters', 40, 42);

  doc.setFontSize(12);
  doc.setTextColor(60, 60, 60);
  doc.text(title, 40, 62);

  if (subtitle) {
    doc.setFontSize(9);
    doc.setTextColor(110, 110, 110);
    doc.text(subtitle, 40, 78);
  }

  const dateStr = `Generated: ${new Date().toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  })}`;
  doc.setFontSize(9);
  doc.setTextColor(110, 110, 110);
  doc.text(dateStr, pageWidth - 40, 42, { align: 'right' });

  const lineY = subtitle ? 88 : 72;
  doc.setDrawColor(215, 215, 215);
  doc.setLineWidth(0.75);
  doc.line(40, lineY, pageWidth - 40, lineY);

  return lineY + 16;
}

function addPDFFooter(doc: jsPDF) {
  const totalPages = doc.getNumberOfPages();
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFont('NotoSansBengali', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(140, 140, 140);
    doc.text(`Page ${i} of ${totalPages}`, pageWidth - 40, pageHeight - 24, { align: 'right' });
    doc.text('Raymond Tailor Workshop Management System', 40, pageHeight - 24);
  }
}

// ---------------------------------------------------------------------------
// 1. DASHBOARD SUMMARY PDF
// ---------------------------------------------------------------------------
export interface DashboardPDFData {
  shopName: string;
  monthStr: string;
  totalActivePipeline: number;
  totalDeliveredCount: number;
  totalOutstandingDue: number;
  totalRevenueBilled: number;
  upcomingDeliveriesCount: number;
  cuttingSlipNeededCount: number;
  recentOrders: Array<{
    orderNumber: number;
    category: 'Officer' | 'Airman';
    customerName: string;
    customerBdNumber: string;
    status: string;
    totalAmount: number;
    due: number;
    orderDate: string;
  }>;
}

export function exportDashboardPDF(data: DashboardPDFData) {
  const doc = createPDFDoc('portrait');
  const startY = addPDFHeader(
    doc,
    data.shopName,
    'Workshop Dashboard & Operational Summary',
    `Period: ${data.monthStr || 'Current Month'} · Summary Snapshot`
  );

  // Key KPI Cards Table
  autoTable(doc, {
    startY,
    theme: 'grid',
    styles: { font: 'NotoSansBengali', fontSize: 10, cellPadding: 8 },
    headStyles: { fillColor: [48, 48, 48], textColor: 255, halign: 'center', fontStyle: 'bold' },
    head: [['Active Pipeline', 'Delivered Orders', 'Revenue Billed', 'Outstanding Due']],
    body: [
      [
        `${data.totalActivePipeline} Orders`,
        `${data.totalDeliveredCount} Orders`,
        `৳${data.totalRevenueBilled.toLocaleString()}`,
        `৳${data.totalOutstandingDue.toLocaleString()}`,
      ],
    ],
    columnStyles: {
      0: { halign: 'center' },
      1: { halign: 'center' },
      2: { halign: 'center', textColor: [0, 91, 211] },
      3: { halign: 'center', textColor: [142, 11, 33] },
    },
  });

  const nextY = (doc as any).lastAutoTable.finalY + 18;

  doc.setFontSize(11);
  doc.setTextColor(30, 30, 30);
  doc.text('Recent Orders Overview', 40, nextY);

  const orderRows = data.recentOrders.map((o) => [
    `#${o.orderNumber}`,
    o.category,
    o.customerName || `Customer ${o.customerBdNumber}`,
    o.customerBdNumber,
    o.status,
    o.orderDate || '—',
    `৳${(Number(o.totalAmount) || 0).toLocaleString()}`,
    `৳${(Number(o.due) || 0).toLocaleString()}`,
  ]);

  autoTable(doc, {
    startY: nextY + 8,
    theme: 'striped',
    styles: { font: 'NotoSansBengali', fontSize: 9, cellPadding: 5 },
    headStyles: { fillColor: [48, 48, 48], textColor: 255 },
    alternateRowStyles: { fillColor: [249, 250, 251] },
    head: [['Order #', 'Type', 'Customer', 'BD #', 'Status', 'Date', 'Total', 'Due']],
    body: orderRows.length > 0 ? orderRows : [['—', '—', 'No recent orders', '—', '—', '—', '—', '—']],
    columnStyles: {
      0: { fontStyle: 'bold', halign: 'center' },
      1: { halign: 'center' },
      4: { halign: 'center' },
      5: { halign: 'center' },
      6: { halign: 'right' },
      7: { halign: 'right', textColor: [142, 11, 33] },
    },
  });

  addPDFFooter(doc);
  const fileName = `Dashboard-Report-${data.monthStr || new Date().toISOString().slice(0, 7)}.pdf`;
  doc.save(fileName);
}

// ---------------------------------------------------------------------------
// 2. STAFF SUMMARY PDF
// ---------------------------------------------------------------------------
export interface StaffSummaryRow {
  name: string;
  role: string;
  phone: string;
  totalWorks: number;
  totalAmount: number;
  totalKhoroch: number;
  netPayable: number;
  received: number;
  due: number;
  status: string;
}

export function exportStaffSummaryPDF(
  shopName: string,
  month: string,
  rows: StaffSummaryRow[]
) {
  const doc = createPDFDoc('landscape');
  const startY = addPDFHeader(
    doc,
    shopName,
    'Master Staff Hishab & Tailor Payroll Summary',
    `Month: ${month} · Staff Tailor Roster (${rows.length} Workers)`
  );

  const tableBody = rows.map((r, idx) => [
    idx + 1,
    r.name,
    r.role || 'Tailor',
    r.phone || '—',
    r.totalWorks,
    `৳${r.totalAmount.toLocaleString()}`,
    `৳${r.totalKhoroch.toLocaleString()}`,
    `৳${r.netPayable.toLocaleString()}`,
    `৳${r.received.toLocaleString()}`,
    `৳${r.due.toLocaleString()}`,
    r.status,
  ]);

  // Totals calculations
  const totalWorks = rows.reduce((s, r) => s + r.totalWorks, 0);
  const totalAmount = rows.reduce((s, r) => s + r.totalAmount, 0);
  const totalKhoroch = rows.reduce((s, r) => s + r.totalKhoroch, 0);
  const totalNet = rows.reduce((s, r) => s + r.netPayable, 0);
  const totalReceived = rows.reduce((s, r) => s + r.received, 0);
  const totalDue = rows.reduce((s, r) => s + r.due, 0);

  tableBody.push([
    '',
    'Total Summary',
    '',
    '',
    totalWorks,
    `৳${totalAmount.toLocaleString()}`,
    `৳${totalKhoroch.toLocaleString()}`,
    `৳${totalNet.toLocaleString()}`,
    `৳${totalReceived.toLocaleString()}`,
    `৳${totalDue.toLocaleString()}`,
    '',
  ]);

  autoTable(doc, {
    startY,
    theme: 'striped',
    styles: { font: 'NotoSansBengali', fontSize: 8.5, cellPadding: 5 },
    headStyles: { fillColor: [48, 48, 48], textColor: 255 },
    alternateRowStyles: { fillColor: [249, 250, 251] },
    head: [
      [
        '#',
        'Tailor Name',
        'Role',
        'Phone',
        'Items',
        'Gross Work',
        'Khoroch',
        'Net Payable',
        'Paid/Advance',
        'Due Balance',
        'Status',
      ],
    ],
    body: tableBody,
    columnStyles: {
      0: { halign: 'center', cellWidth: 24 },
      1: { fontStyle: 'bold' },
      4: { halign: 'center' },
      5: { halign: 'right' },
      6: { halign: 'right' },
      7: { halign: 'right', fontStyle: 'bold' },
      8: { halign: 'right' },
      9: { halign: 'right', fontStyle: 'bold', textColor: [142, 11, 33] },
      10: { halign: 'center' },
    },
    didParseCell: (data) => {
      // Bold the bottom totals row
      if (data.row.index === tableBody.length - 1) {
        data.cell.styles.fontStyle = 'bold';
        data.cell.styles.fillColor = [240, 240, 240];
      }
    },
  });

  addPDFFooter(doc);
  const fileName = `Staff-Summary-${month}.pdf`;
  doc.save(fileName);
}

// ---------------------------------------------------------------------------
// 3. WORKER MONTH STATEMENT PDF
// ---------------------------------------------------------------------------
export interface WorkerMonthPDFData {
  shopName: string;
  workerName: string;
  workerPhone?: string;
  workerRole?: string;
  month: string;
  hishab: {
    totalAmount: number;
    totalKhoroch: number;
    netPayable: number;
    received: number;
    due: number;
    status: string;
    worksCount: number;
  };
  entries: Array<{
    date: string;
    orderNumber: number;
    category: string;
    workItem: string;
    quantity: number;
    rate: number;
    lineTotal: number;
    notes?: string;
  }>;
  payments: Array<{
    date: string;
    amount: number;
    note?: string;
  }>;
}

export function exportWorkerMonthPDF(data: WorkerMonthPDFData) {
  const doc = createPDFDoc('portrait');
  const startY = addPDFHeader(
    doc,
    data.shopName,
    `Tailor Statement — ${data.workerName}`,
    `Month: ${data.month} · Role: ${data.workerRole || 'Tailor'} · Phone: ${data.workerPhone || '—'}`
  );

  // Financial Hishab Summary Card
  autoTable(doc, {
    startY,
    theme: 'grid',
    styles: { font: 'NotoSansBengali', fontSize: 9.5, cellPadding: 6 },
    headStyles: { fillColor: [48, 48, 48], textColor: 255, halign: 'center' },
    head: [['Gross Work', 'Total Khoroch', 'Net Payable', 'Paid / Received', 'Due Balance', 'Status']],
    body: [
      [
        `৳${data.hishab.totalAmount.toLocaleString()}`,
        `৳${data.hishab.totalKhoroch.toLocaleString()}`,
        `৳${data.hishab.netPayable.toLocaleString()}`,
        `৳${data.hishab.received.toLocaleString()}`,
        `৳${data.hishab.due.toLocaleString()}`,
        data.hishab.status,
      ],
    ],
    columnStyles: {
      0: { halign: 'center' },
      1: { halign: 'center' },
      2: { halign: 'center', fontStyle: 'bold' },
      3: { halign: 'center' },
      4: { halign: 'center', fontStyle: 'bold', textColor: [142, 11, 33] },
      5: { halign: 'center', fontStyle: 'bold' },
    },
  });

  let currentY = (doc as any).lastAutoTable.finalY + 16;

  // Work Item Entries Table
  doc.setFontSize(11);
  doc.setTextColor(30, 30, 30);
  doc.text(`Work Items Completed (${data.entries.length})`, 40, currentY);

  const entryRows = data.entries.map((e, idx) => [
    idx + 1,
    e.date,
    `#${e.orderNumber}`,
    e.category,
    e.workItem,
    e.quantity,
    `৳${e.rate}`,
    `৳${e.lineTotal}`,
    e.notes || '—',
  ]);

  autoTable(doc, {
    startY: currentY + 6,
    theme: 'striped',
    styles: { font: 'NotoSansBengali', fontSize: 8.5, cellPadding: 4 },
    headStyles: { fillColor: [70, 70, 70], textColor: 255 },
    alternateRowStyles: { fillColor: [249, 250, 251] },
    head: [['#', 'Date', 'Order #', 'Type', 'Work Item', 'Qty', 'Rate', 'Total', 'Notes']],
    body: entryRows.length > 0 ? entryRows : [['—', '—', '—', '—', 'No work items recorded', '—', '—', '—', '—']],
    columnStyles: {
      0: { halign: 'center', cellWidth: 20 },
      1: { halign: 'center' },
      2: { halign: 'center', fontStyle: 'bold' },
      3: { halign: 'center' },
      5: { halign: 'center' },
      6: { halign: 'right' },
      7: { halign: 'right', fontStyle: 'bold' },
    },
  });

  currentY = (doc as any).lastAutoTable.finalY + 16;

  // Payments / Khoroch Table
  doc.setFontSize(11);
  doc.setTextColor(30, 30, 30);
  doc.text(`Payments & Advance Received (${data.payments.length})`, 40, currentY);

  const paymentRows = data.payments.map((p, idx) => [
    idx + 1,
    p.date,
    `৳${(Number(p.amount) || 0).toLocaleString()}`,
    p.note || 'Cash payment',
  ]);

  autoTable(doc, {
    startY: currentY + 6,
    theme: 'striped',
    styles: { font: 'NotoSansBengali', fontSize: 8.5, cellPadding: 4 },
    headStyles: { fillColor: [70, 70, 70], textColor: 255 },
    alternateRowStyles: { fillColor: [249, 250, 251] },
    head: [['#', 'Payment Date', 'Amount', 'Payment Note']],
    body: paymentRows.length > 0 ? paymentRows : [['—', '—', '৳0', 'No payment records for this month']],
    columnStyles: {
      0: { halign: 'center', cellWidth: 20 },
      1: { halign: 'center' },
      2: { halign: 'right', fontStyle: 'bold', textColor: [0, 91, 211] },
    },
  });

  addPDFFooter(doc);
  const cleanName = data.workerName.replace(/\s+/g, '_');
  const fileName = `Worker-Statement-${cleanName}-${data.month}.pdf`;
  doc.save(fileName);
}

// ---------------------------------------------------------------------------
// 4. WORKER PAYSLIP PDF
// ---------------------------------------------------------------------------
export interface PayslipPDFData {
  shopName: string;
  workerName: string;
  workerPhone?: string;
  workerRole?: string;
  month: string;
  hishab: {
    totalAmount: number;
    totalKhoroch: number;
    netPayable: number;
    received: number;
    due: number;
    status: string;
    worksCount: number;
  };
}

export function exportWorkerPayslipPDF(data: PayslipPDFData) {
  const doc = createPDFDoc('portrait');
  const startY = addPDFHeader(
    doc,
    data.shopName,
    'Official Monthly Tailor Payslip',
    `Month: ${data.month} · Salary & Work Hishab Voucher`
  );

  // Payslip Receipt Container
  const pageWidth = doc.internal.pageSize.getWidth();
  const boxX = 40;
  const boxWidth = pageWidth - 80;

  // Tailor Metadata Box
  autoTable(doc, {
    startY,
    theme: 'plain',
    styles: { font: 'NotoSansBengali', fontSize: 10, cellPadding: 3 },
    body: [
      ['Tailor Name:', data.workerName, 'Month:', data.month],
      ['Designation:', data.workerRole || 'Master Tailor', 'Payment Date:', new Date().toISOString().slice(0, 10)],
      ['Phone:', data.workerPhone || '—', 'Status:', data.hishab.status],
    ],
    columnStyles: {
      0: { fontStyle: 'bold', textColor: [100, 100, 100], cellWidth: 90 },
      1: { fontStyle: 'bold', textColor: [20, 20, 20] },
      2: { fontStyle: 'bold', textColor: [100, 100, 100], cellWidth: 80 },
      3: { textColor: [20, 20, 20] },
    },
  });

  const nextY = (doc as any).lastAutoTable.finalY + 12;

  // Financial Breakdown Line Items Table
  autoTable(doc, {
    startY: nextY,
    theme: 'grid',
    styles: { font: 'NotoSansBengali', fontSize: 10, cellPadding: 8 },
    headStyles: { fillColor: [48, 48, 48], textColor: 255 },
    head: [['Earnings & Deductions Item', 'Amount (৳)']],
    body: [
      [`Total Completed Work Earnings (${data.hishab.worksCount} items)`, `৳${data.hishab.totalAmount.toLocaleString()}`],
      ['Less: Workshop Deductions / Khoroch', `-৳${data.hishab.totalKhoroch.toLocaleString()}`],
      ['Net Payable Earnings', `৳${data.hishab.netPayable.toLocaleString()}`],
      ['Less: Advance / Cash Received So Far', `-৳${data.hishab.received.toLocaleString()}`],
      ['Remaining Balance Due', `৳${data.hishab.due.toLocaleString()}`],
    ],
    columnStyles: {
      0: { fontStyle: 'normal' },
      1: { halign: 'right', fontStyle: 'bold' },
    },
    didParseCell: (dataCell) => {
      if (dataCell.row.index === 2) {
        dataCell.cell.styles.fillColor = [240, 246, 255];
        dataCell.cell.styles.fontStyle = 'bold';
      }
      if (dataCell.row.index === 4) {
        dataCell.cell.styles.fillColor = [254, 233, 232];
        dataCell.cell.styles.textColor = [142, 11, 33];
        dataCell.cell.styles.fontStyle = 'bold';
      }
    },
  });

  const signY = (doc as any).lastAutoTable.finalY + 65;

  // Signatures
  doc.setDrawColor(180, 180, 180);
  doc.setLineWidth(0.75);

  doc.line(60, signY, 200, signY);
  doc.setFontSize(9);
  doc.setTextColor(80, 80, 80);
  doc.text('Tailor / Receiver Signature', 75, signY + 14);

  doc.line(pageWidth - 200, signY, pageWidth - 60, signY);
  doc.text('Authorized Workshop Signature', pageWidth - 190, signY + 14);

  addPDFFooter(doc);
  const cleanName = data.workerName.replace(/\s+/g, '_');
  const fileName = `Payslip-${cleanName}-${data.month}.pdf`;
  doc.save(fileName);
}
