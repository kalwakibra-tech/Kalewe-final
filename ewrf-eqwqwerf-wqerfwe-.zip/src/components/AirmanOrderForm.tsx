import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  AirmanOrder,
  AirmanOrderItem,
  PantMeasurements,
  ShirtMeasurements,
  AirmanItemDefinition,
} from '../types/index.ts';
import {
  INITIAL_PANT_MEASUREMENTS,
  INITIAL_SHIRT_MEASUREMENTS,
} from '../utils/starterData.ts';
import {
  formatDate,
  getBdDigits,
  getLatestMeasurementsForCustomer,
  normalizeBdNumber,
} from '../utils/logic.ts';
import {
  Plus,
  Trash2,
  X,
  AlertCircle,
  Check,
  Calendar,
  Ruler,
  Plane,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { AnimatePresence } from 'motion/react';

interface AirmanOrderFormProps {
  orderNumber?: number;
  draftId?: string;
  onNavigate: (screen: ScreenName, params?: any) => void;
}

const LOCAL_AIR_DRAFT_KEY = 'airman_order_local_autosave';

export const AirmanOrderForm: React.FC<AirmanOrderFormProps> = ({
  orderNumber,
  draftId,
  onNavigate,
}) => {
  const { state, saveAirmanOrder, saveDraft, deleteDraft, addRunningYear } = useApp();

  const isEdit = typeof orderNumber === 'number';
  const existingOrder = isEdit ? state.airmanOrders.find((o) => o.orderNumber === orderNumber) : null;
  const existingDraft = draftId ? state.drafts.find((d) => d.id === draftId) : null;

  const [items, setItems] = useState<AirmanOrderItem[]>(() => {
    if (existingOrder?.items && existingOrder.items.length > 0) return existingOrder.items;
    if (existingDraft?.airmanItems && existingDraft.airmanItems.length > 0) return existingDraft.airmanItems;
    return [];
  });

  const [selectedCatalogItem, setSelectedCatalogItem] = useState<AirmanItemDefinition | null>(() => {
    return state.settings.airmanItems[0] || null;
  });
  const [addItemQty, setAddItemQty] = useState<number>(1);

  const [shirt, setShirt] = useState<ShirtMeasurements>(INITIAL_SHIRT_MEASUREMENTS);
  const [pant, setPant] = useState<PantMeasurements>(INITIAL_PANT_MEASUREMENTS);

  const [runningYear, setRunningYear] = useState<string>(() => {
    return state.settings.runningYears[0] || '2026';
  });
  const [ivNumber, setIvNumber] = useState('');
  const [bdDigits, setBdDigits] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [orderDate, setOrderDate] = useState(formatDate());
  const [deliveryDate, setDeliveryDate] = useState('');

  const [formError, setFormError] = useState<string>('');
  const [autofilledNotice, setAutofilledNotice] = useState<string>('');
  const [cancelModalOpen, setCancelModalOpen] = useState(false);
  const [showBdDropdown, setShowBdDropdown] = useState(false);

  // Load existing
  useEffect(() => {
    if (existingOrder) {
      if (existingOrder.items?.length > 0) {
        setItems(existingOrder.items);
        const firstIv = existingOrder.items.find((i) => i.ivNumber)?.ivNumber || '';
        setIvNumber(firstIv);
      }
      setShirt(existingOrder.shirtMeasurements || INITIAL_SHIRT_MEASUREMENTS);
      setPant(existingOrder.pantMeasurements || INITIAL_PANT_MEASUREMENTS);
      setRunningYear(existingOrder.runningYear || state.settings.runningYears[0] || '2026');
      setBdDigits(getBdDigits(existingOrder.customerBdNumber || ''));
      setCustomerName(existingOrder.customerName || '');
      setPhone(existingOrder.customerPhone || '');
      setOrderDate(existingOrder.orderDate || formatDate());
      setDeliveryDate(existingOrder.deliveredDate || '');
    } else if (existingDraft) {
      if (existingDraft.airmanItems && existingDraft.airmanItems.length > 0) {
        setItems(existingDraft.airmanItems);
        const firstIv = existingDraft.airmanItems.find((i) => i.ivNumber)?.ivNumber || '';
        setIvNumber(firstIv);
      }
      setShirt(existingDraft.shirtMeasurements || INITIAL_SHIRT_MEASUREMENTS);
      setPant(existingDraft.pantMeasurements || INITIAL_PANT_MEASUREMENTS);
      setRunningYear(existingDraft.runningYear || state.settings.runningYears[0] || '2026');
      setBdDigits(getBdDigits(existingDraft.customerBdNumber || ''));
      setCustomerName(existingDraft.customerName || '');
      setPhone(existingDraft.customerPhone || '');
      setOrderDate(existingDraft.orderDate || formatDate());
      setDeliveryDate(existingDraft.deliveryDate || '');
    }
  }, [existingOrder, existingDraft]);

  const handleBdChange = (val: string) => {
    setBdDigits(val);
    const normalized = normalizeBdNumber(val);
    const matched = state.customers.find(
      (c) => c.category === 'Airman' && normalizeBdNumber(c.bdNumber) === normalized
    );
    if (matched) {
      setCustomerName(matched.name);
      if (matched.phone) setPhone(matched.phone);
      setAutofilledNotice(`Loaded customer: ${matched.name}`);

      const latest = getLatestMeasurementsForCustomer(
        matched.bdNumber,
        'Airman',
        state.officerOrders,
        state.airmanOrders
      );
      if (latest && latest.found) {
        if (latest.shirt) setShirt(latest.shirt);
        if (latest.pant) setPant(latest.pant);
      }
    } else {
      setAutofilledNotice('');
    }
  };

  const bdSuggestions = useMemo(() => {
    if (!bdDigits || bdDigits.length < 1) return [];
    const q = bdDigits.trim();
    return state.customers
      .filter((c) => c.category === 'Airman' && getBdDigits(c.bdNumber).includes(q))
      .slice(0, 5);
  }, [bdDigits, state.customers]);

  const handleAddItem = () => {
    if (!selectedCatalogItem) return;
    const newItem: AirmanOrderItem = {
      id: `air-item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      name: selectedCatalogItem.name,
      quantity: addItemQty,
      ivNumber: ivNumber.trim(),
    };
    setItems((prev) => [...prev, newItem]);
    setAddItemQty(1);
  };

  const handleRemoveItem = (idx: number) => {
    setItems((prev) => prev.filter((_, i) => i !== idx));
  };

  const totalGarmentsCount = useMemo(() => {
    return items.reduce((sum, it) => sum + (it.quantity || 1), 0);
  }, [items]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!customerName.trim()) {
      setFormError('Airman customer name is required.');
      return;
    }
    if (!bdDigits.trim()) {
      setFormError('BD number is required.');
      return;
    }
    if (items.length === 0) {
      setFormError('At least one trade garment must be selected.');
      return;
    }

    const normalizedBd = normalizeBdNumber(bdDigits);
    const payload = {
      orderNumber: isEdit ? orderNumber : undefined,
      runningYear,
      ivNumber: ivNumber.trim(),
      customerName: customerName.trim(),
      customerBdNumber: normalizedBd,
      bdNumber: normalizedBd,
      customerPhone: phone.trim(),
      phone: phone.trim(),
      orderDate,
      deliveryDate: deliveryDate || formatDate(),
      status: existingOrder ? existingOrder.status : ('Pending' as const),
      items,
      shirtMeasurements: shirt,
      pantMeasurements: pant,
      measurements: {
        ...shirt,
        ...pant,
      },
    };

    const res = saveAirmanOrder(payload as any, draftId);
    if (!res.success) {
      setFormError(res.error || 'Failed to save order.');
      return;
    }

    onNavigate('airman-orders');
  };

  const isValidToSave = customerName.trim() && bdDigits.trim() && items.length > 0;

  return (
    <PolarisPage
      title={isEdit ? `Edit Airman Order #${orderNumber}` : 'New Airman Order'}
      subtitle={
        isEdit
          ? 'Update non-commissioned airman garments, batch parameters, or measurements.'
          : 'Airman order. Trade garments, IV record, and measurements in one place.'
      }
      secondaryActions={[
        {
          label: 'Cancel',
          onClick: () => setCancelModalOpen(true),
        },
      ]}
      fullWidth
    >
      <form onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column (8 Cols): Garments, Customer & IV, Measurements */}
          <div className="lg:col-span-8 space-y-6">
            {formError && (
              <div className="p-4 rounded-[16px] bg-[#fceaea] border border-[#e5484d] text-[#c62828] text-[14px] flex items-center gap-2">
                <AlertCircle className="w-5 h-5 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            {/* Section 1: Garments */}
            <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0]">
                <div>
                  <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Airman Trade Garments</h3>
                  <p className="text-[13px] text-[#6e6e73]">Select items for this airman batch</p>
                </div>
                <span className="text-[13px] font-semibold text-[#1d1d1f] px-2.5 py-1 rounded-full bg-[#f5f5f7]">
                  {items.length} items
                </span>
              </div>

              {/* Add item control tray */}
              <div className="p-4 bg-[#f5f5f7] rounded-[18px] grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
                <div className="sm:col-span-7">
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">
                    Select Trade Garment ({state.settings.airmanItems.length} available)
                  </label>
                  <select
                    value={selectedCatalogItem?.id || ''}
                    onChange={(e) => {
                      const found = state.settings.airmanItems.find((i) => i.id === e.target.value);
                      if (found) setSelectedCatalogItem(found);
                    }}
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[14px] font-semibold text-[#1d1d1f] outline-none focus:border-[#0071e3]"
                  >
                    {state.settings.airmanItems.map((catItem) => (
                      <option key={catItem.id} value={catItem.id}>
                        {catItem.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-2">
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">Quantity</label>
                  <input
                    type="number"
                    min="1"
                    value={addItemQty}
                    onChange={(e) => setAddItemQty(Math.max(1, parseInt(e.target.value) || 1))}
                    className="w-full h-[44px] px-3 text-center rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] font-semibold text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                  />
                </div>

                <div className="sm:col-span-3 sm:self-end">
                  <button
                    type="button"
                    onClick={handleAddItem}
                    className="w-full h-[44px] rounded-full bg-white hover:bg-[#efeff2] border border-[#e0e0e0] text-[#1d1d1f] text-[14px] font-semibold cursor-pointer transition-colors active:scale-95"
                  >
                    + Add garment
                  </button>
                </div>
              </div>

              {/* Added garments */}
              <div className="space-y-2">
                {items.length === 0 ? (
                  <div className="py-6 text-center text-[14px] text-[#6e6e73]">
                    No garments added. Select an item above and tap + Add garment.
                  </div>
                ) : (
                  items.map((it, idx) => (
                    <div
                      key={it.id || idx}
                      className="p-3.5 bg-[#f5f5f7] rounded-[16px] flex items-center justify-between text-[14px]"
                    >
                      <span className="font-semibold text-[#1d1d1f]">{it.name}</span>
                      <div className="flex items-center gap-4 shrink-0">
                        <span className="text-[#6e6e73] num font-semibold">Qty: {it.quantity}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveItem(idx)}
                          className="w-8 h-8 rounded-full bg-white hover:bg-[#fceaea] hover:text-[#c62828] text-[#6e6e73] border border-[#e0e0e0] flex items-center justify-center cursor-pointer transition-colors"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Section 2: Customer, IV Number, & Schedule */}
            <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0]">
                <div>
                  <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Airman Identity & Batch</h3>
                  <p className="text-[13px] text-[#6e6e73]">Running year, IV issue voucher, and schedule</p>
                </div>
              </div>

              {autofilledNotice && (
                <div className="p-3 rounded-[14px] bg-[#e3f4e8] text-[#1e7b43] text-[13px] flex items-center gap-2">
                  <Check className="w-4 h-4" />
                  <span>{autofilledNotice}</span>
                </div>
              )}

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1">
                    Running Year *
                  </label>
                  <select
                    value={runningYear}
                    onChange={(e) => setRunningYear(e.target.value)}
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] font-semibold text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                  >
                    {(state.settings.runningYears || ['2026', '2025', '2024']).map((yr) => (
                      <option key={yr} value={yr}>
                        {yr}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1">
                    IV Number
                  </label>
                  <input
                    type="text"
                    value={ivNumber}
                    onChange={(e) => setIvNumber(e.target.value)}
                    placeholder="e.g. IV-8842"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                  />
                </div>

                <div className="relative">
                  <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1">
                    Airman BD Number *
                  </label>
                  <input
                    type="text"
                    value={bdDigits}
                    onChange={(e) => handleBdChange(e.target.value)}
                    onFocus={() => setShowBdDropdown(true)}
                    placeholder="e.g. 54321"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] font-semibold text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                  />
                  {showBdDropdown && bdSuggestions.length > 0 && (
                    <div className="absolute left-0 right-0 top-full mt-1 bg-white rounded-[16px] border border-[#e0e0e0] shadow-lg z-20 overflow-hidden divide-y divide-[#f0f0f0]">
                      {bdSuggestions.map((sug) => (
                        <div
                          key={sug.bdNumber}
                          onClick={() => {
                            setBdDigits(getBdDigits(sug.bdNumber));
                            setCustomerName(sug.name);
                            if (sug.phone) setPhone(sug.phone);
                            setShowBdDropdown(false);
                            setAutofilledNotice(`Loaded airman: ${sug.name}`);
                          }}
                          className="p-3 hover:bg-[#f5f5f7] cursor-pointer text-[13px]"
                        >
                          <div className="font-semibold text-[#1d1d1f]">{sug.name}</div>
                          <div className="text-[12px] text-[#6e6e73]">BD/{sug.bdNumber} {sug.phone ? `· ${sug.phone}` : ''}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1">
                    Airman Full Name *
                  </label>
                  <input
                    type="text"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="Airman name"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] text-[#1d1d1f] outline-none focus:border-[#0071e3]"
                  />
                </div>

                <div>
                  <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1">
                    Order Date
                  </label>
                  <input
                    type="date"
                    value={orderDate}
                    onChange={(e) => setOrderDate(e.target.value)}
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                  />
                </div>

                <div>
                  <label className="text-[13px] font-semibold text-[#1d1d1f] block mb-1">
                    Target Delivery Date
                  </label>
                  <input
                    type="date"
                    value={deliveryDate}
                    onChange={(e) => setDeliveryDate(e.target.value)}
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                  />
                </div>
              </div>
            </div>

            {/* Section 3: Measurements */}
            <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-5">
              <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Measurements</h3>

              <div className="p-5 bg-[#f5f5f7] rounded-[18px] space-y-3">
                <span className="text-[14px] font-semibold text-[#1d1d1f] block">Shirt Dimensions</span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { key: 'length', label: 'Length' },
                    { key: 'chest', label: 'Chest' },
                    { key: 'belly', label: 'Belly' },
                    { key: 'shoulder', label: 'Shoulder' },
                    { key: 'sleeve', label: 'Sleeve' },
                    { key: 'collar', label: 'Collar' },
                    { key: 'cuff', label: 'Cuff' },
                  ].map(({ key, label }) => (
                    <div key={key}>
                      <label className="text-[11px] font-semibold text-[#6e6e73] block mb-1">{label}</label>
                      <input
                        type="text"
                        value={(shirt as any)[key] || ''}
                        onChange={(e) => setShirt((prev) => ({ ...prev, [key]: e.target.value }))}
                        className="w-full h-[40px] px-3 text-center rounded-[10px] bg-white border border-[#e0e0e0] text-[15px] font-semibold text-[#1d1d1f] num outline-none"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-5 bg-[#f5f5f7] rounded-[18px] space-y-3">
                <span className="text-[14px] font-semibold text-[#1d1d1f] block">Trousers Dimensions</span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {[
                    { key: 'length', label: 'Length' },
                    { key: 'waist', label: 'Waist' },
                    { key: 'hip', label: 'Hip' },
                    { key: 'thigh', label: 'Thigh' },
                    { key: 'bottom', label: 'Bottom' },
                    { key: 'knee', label: 'Knee' },
                    { key: 'fly', label: 'Fly' },
                  ].map(({ key, label }) => (
                    <div key={key}>
                      <label className="text-[11px] font-semibold text-[#6e6e73] block mb-1">{label}</label>
                      <input
                        type="text"
                        value={(pant as any)[key] || ''}
                        onChange={(e) => setPant((prev) => ({ ...prev, [key]: e.target.value }))}
                        className="w-full h-[40px] px-3 text-center rounded-[10px] bg-white border border-[#e0e0e0] text-[15px] font-semibold text-[#1d1d1f] num outline-none"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Right Column (4 Cols): Sticky Graphite Summary Card */}
          <div className="lg:col-span-4 sticky top-6">
            <div className="object-card p-6 rounded-[24px] space-y-5 select-none">
              <div className="relative z-10 space-y-5">
                <div>
                  <span className="text-[14px] text-white/70 block">Batch Volume</span>
                  <span className="text-[32px] font-semibold text-white num leading-tight">
                    {totalGarmentsCount} garments
                  </span>
                </div>

                <div className="space-y-2 pt-2 border-t border-white/10 text-[13px]">
                  <div className="flex justify-between text-white/80">
                    <span>Running Year:</span>
                    <span className="font-semibold text-white num">{runningYear}</span>
                  </div>
                  <div className="flex justify-between text-white/80">
                    <span>IV Number:</span>
                    <span className="font-semibold text-white num">{ivNumber || 'Not set'}</span>
                  </div>
                  <div className="flex justify-between text-white/80">
                    <span>Unique Items:</span>
                    <span className="font-semibold text-white num">{items.length} types</span>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={!isValidToSave}
                  className="w-full h-[44px] rounded-full bg-[#0066cc] hover:bg-[#0071e3] disabled:opacity-50 text-white text-[15px] font-semibold cursor-pointer transition-all active:scale-95 shadow-xs flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4 stroke-[2.5]" />
                  <span>{isEdit ? 'Update airman order' : 'Save airman order'}</span>
                </button>

                <p className="text-[12px] text-white/50 text-center leading-tight">
                  Needs an airman name, BD number and at least one garment.
                </p>
              </div>
            </div>
          </div>
        </div>
      </form>

      {/* Cancel Modal */}
      <AnimatePresence>
        {cancelModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setCancelModalOpen(false)}
            />
            <div className="relative z-10 w-full max-w-sm bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Leave without saving?</h3>
              <p className="text-[14px] text-[#6e6e73] mt-2">
                Unsaved changes to this airman trade order will be lost.
              </p>
              <div className="grid grid-cols-2 gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setCancelModalOpen(false)}
                  className="h-[44px] rounded-full bg-[#f5f5f7] text-[#1d1d1f] font-semibold text-[14px]"
                >
                  Keep editing
                </button>
                <button
                  type="button"
                  onClick={() => onNavigate('airman-orders')}
                  className="h-[44px] rounded-full bg-[#c62828] text-white font-semibold text-[14px]"
                >
                  Leave
                </button>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </PolarisPage>
  );
};
