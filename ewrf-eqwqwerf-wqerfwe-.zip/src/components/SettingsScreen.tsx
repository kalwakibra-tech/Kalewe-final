import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { RulerTickStrip } from './Illustrations.tsx';
import { PWAInstallButton } from './PWAInstallButton.tsx';
import { SlipType, DiscountType } from '../types/index.ts';
import {
  Save,
  Plus,
  Trash2,
  Edit2,
  Check,
  Download,
  AlertCircle,
  Tag,
  CheckCircle2,
  Minus,
} from 'lucide-react';

export const SettingsScreen: React.FC = () => {
  const {
    state,
    updateSettings,
    addOfficerItem,
    updateOfficerItem,
    deleteOfficerItem,
    addAirmanItem,
    updateAirmanItem,
    deleteAirmanItem,
    addRunningYear,
    resetToFreshState,
  } = useApp();

  const [activeCatalogTab, setActiveCatalogTab] = useState<'officer' | 'airman'>('officer');

  // Shop Info
  const [shopName, setShopName] = useState(state.settings.invoiceShopName || 'Raymond');
  const [shopPhone, setShopPhone] = useState(state.settings.invoiceShopPhone || '01711-000000');
  const [shopAddress, setShopAddress] = useState(
    state.settings.invoiceShopAddress || 'BAF Base Tailor Market, Dhaka Cantonment'
  );

  // Stepper & Discount Knobs
  const [upcomingDays, setUpcomingDays] = useState<number>(
    state.settings.upcomingDeliveryDays || 3
  );
  const [discountType, setDiscountType] = useState<DiscountType>(
    state.settings.defaultDiscountType || 'percentage'
  );

  // New Officer Item Form
  const [newOfficerName, setNewOfficerName] = useState('');
  const [newOfficerPrice, setNewOfficerPrice] = useState('');
  const [editingOfficerId, setEditingOfficerId] = useState<string | null>(null);
  const [editOfficerName, setEditOfficerName] = useState('');
  const [editOfficerPrice, setEditOfficerPrice] = useState('');

  // New Airman Item Form
  const [newAirmanName, setNewAirmanName] = useState('');
  const [editingAirmanId, setEditingAirmanId] = useState<string | null>(null);
  const [editAirmanName, setEditAirmanName] = useState('');

  // Ribbon & Year
  const [newRibbonVal, setNewRibbonVal] = useState('');
  const [newYearVal, setNewYearVal] = useState('');

  const [savedNotice, setSavedNotice] = useState(false);

  const handleSaveGeneral = () => {
    updateSettings({
      invoiceShopName: shopName,
      invoiceShopPhone: shopPhone,
      invoiceShopAddress: shopAddress,
      upcomingDeliveryDays: upcomingDays,
      defaultDiscountType: discountType,
    });
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 3000);
  };

  const handleAddOfficerItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOfficerName.trim() || !newOfficerPrice) return;
    addOfficerItem(newOfficerName.trim(), parseFloat(newOfficerPrice) || 0, 'General', 'Shirt');
    setNewOfficerName('');
    setNewOfficerPrice('');
  };

  const handleSaveEditOfficer = (id: string) => {
    if (!editOfficerName.trim() || !editOfficerPrice) return;
    updateOfficerItem(id, editOfficerName.trim(), parseFloat(editOfficerPrice) || 0, 'General', 'Shirt');
    setEditingOfficerId(null);
  };

  const handleAddAirmanItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAirmanName.trim()) return;
    addAirmanItem(newAirmanName.trim(), 'Shirt');
    setNewAirmanName('');
  };

  const handleSaveEditAirman = (id: string) => {
    if (!editAirmanName.trim()) return;
    updateAirmanItem(id, editAirmanName.trim(), 'Shirt');
    setEditingAirmanId(null);
  };

  const handleAddRibbon = () => {
    if (!newRibbonVal.trim()) return;
    const current = state.settings.ribbonValues || [];
    if (!current.includes(newRibbonVal.trim())) {
      updateSettings({ ribbonValues: [...current, newRibbonVal.trim()] });
    }
    setNewRibbonVal('');
  };

  const handleRemoveRibbon = (val: string) => {
    const current = state.settings.ribbonValues || [];
    updateSettings({ ribbonValues: current.filter((r) => r !== val) });
  };

  const handleAddYear = () => {
    if (!newYearVal.trim()) return;
    addRunningYear(newYearVal.trim());
    setNewYearVal('');
  };

  const handleExportBackup = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(state, null, 2));
    const dl = document.createElement('a');
    dl.setAttribute('href', dataStr);
    dl.setAttribute('download', `raymond-tailors-backup-${new Date().toISOString().slice(0, 10)}.json`);
    dl.click();
  };

  return (
    <PolarisPage
      title="Settings"
      subtitle="Workshop preferences, garment prices, discount rules, and system configuration."
      primaryAction={{
        label: 'Save preferences',
        icon: <Save className="w-4 h-4" />,
        onClick: handleSaveGeneral,
      }}
      fullWidth
    >
      {savedNotice && (
        <div className="p-4 rounded-[16px] bg-[#e3f4e8] text-[#1e7b43] text-[14px] font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 shrink-0" />
          <span>Shop settings and preferences saved successfully.</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* =========================================================================
            LEFT COLUMN (8 Cols): Big Editable List (Items & Prices)
            Section 5.5 & Section 10.10
           ========================================================================= */}
        <div className="lg:col-span-8 bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-[#f0f0f0] gap-3">
            <div>
              <h2 className="text-[22px] font-semibold text-[#1d1d1f] tracking-[-0.02em]">
                Garment Catalog & Tailoring Prices
              </h2>
              <p className="text-[14px] text-[#6e6e73] mt-0.5">
                Standard tailoring catalog and default price list.
              </p>
            </div>

            {/* Catalog Switcher Chips */}
            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                aria-pressed={activeCatalogTab === 'officer'}
                onClick={() => setActiveCatalogTab('officer')}
                className={`h-9 px-4 rounded-full text-[13px] font-semibold cursor-pointer transition-all ${
                  activeCatalogTab === 'officer'
                    ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                    : 'bg-white border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
                }`}
              >
                Officer Items ({state.settings.items.length})
              </button>
              <button
                type="button"
                aria-pressed={activeCatalogTab === 'airman'}
                onClick={() => setActiveCatalogTab('airman')}
                className={`h-9 px-4 rounded-full text-[13px] font-semibold cursor-pointer transition-all ${
                  activeCatalogTab === 'airman'
                    ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                    : 'bg-white border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
                }`}
              >
                Airman Items ({state.settings.airmanItems.length})
              </button>
            </div>
          </div>

          {activeCatalogTab === 'officer' ? (
            /* Officer Catalog */
            <div className="space-y-4">
              {/* Add-Row Tray per Section 10.10 */}
              <form
                onSubmit={handleAddOfficerItem}
                className="p-4 bg-[#f5f5f7] rounded-[18px] grid grid-cols-1 sm:grid-cols-12 gap-3 items-center"
              >
                <div className="sm:col-span-6">
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">
                    Garment Name
                  </label>
                  <input
                    type="text"
                    value={newOfficerName}
                    onChange={(e) => setNewOfficerName(e.target.value)}
                    placeholder="e.g. BD Serge Pant"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[14px] text-[#1d1d1f] outline-none focus:border-[#0071e3]"
                  />
                </div>
                <div className="sm:col-span-3">
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">
                    Price (৳)
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={newOfficerPrice}
                    onChange={(e) => setNewOfficerPrice(e.target.value)}
                    placeholder="800"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] font-semibold text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                  />
                </div>
                <div className="sm:col-span-3 sm:self-end">
                  <button
                    type="submit"
                    className="w-full h-[44px] rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[14px] font-semibold cursor-pointer transition-all active:scale-95 shadow-xs flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    <span>+ Add item</span>
                  </button>
                </div>
              </form>

              {/* Items List Rows */}
              <div className="divide-y divide-[#f0f0f0]">
                {state.settings.items.map((item) => {
                  const isEditing = editingOfficerId === item.id;
                  const needsPriceCheck = !item.price || item.price <= 0;

                  return (
                    <div
                      key={item.id}
                      className="py-3 flex items-center justify-between gap-3 text-[14px]"
                    >
                      {isEditing ? (
                        <div className="flex-1 grid grid-cols-1 sm:grid-cols-12 gap-2">
                          <input
                            type="text"
                            value={editOfficerName}
                            onChange={(e) => setEditOfficerName(e.target.value)}
                            className="sm:col-span-7 h-9 px-3 rounded-[10px] bg-white border border-[#e0e0e0] text-[14px]"
                          />
                          <input
                            type="number"
                            value={editOfficerPrice}
                            onChange={(e) => setEditOfficerPrice(e.target.value)}
                            className="sm:col-span-3 h-9 px-3 rounded-[10px] bg-white border border-[#e0e0e0] text-[14px] num font-semibold"
                          />
                          <div className="sm:col-span-2 flex items-center gap-1">
                            <button
                              type="button"
                              onClick={() => handleSaveEditOfficer(item.id)}
                              className="h-9 px-3 rounded-full bg-[#0066cc] text-white text-[12px] font-semibold"
                            >
                              Save
                            </button>
                            <button
                              type="button"
                              onClick={() => setEditingOfficerId(null)}
                              className="h-9 px-2 rounded-full bg-[#f5f5f7] text-[#6e6e73] text-[12px]"
                            >
                              ✕
                            </button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center gap-2.5 min-w-0">
                            <span className="font-semibold text-[#1d1d1f] truncate">
                              {item.name}
                            </span>
                            {needsPriceCheck && (
                              <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#fdeee7] text-[#c2410c]">
                                check price
                              </span>
                            )}
                          </div>

                          <div className="flex items-center gap-4 shrink-0">
                            <span className="font-semibold text-[#1d1d1f] num min-w-[70px] text-right">
                              ৳{item.price.toLocaleString()}
                            </span>

                            {/* 36px round icon buttons per Section 10.10 */}
                            <button
                              type="button"
                              onClick={() => {
                                setEditingOfficerId(item.id);
                                setEditOfficerName(item.name);
                                setEditOfficerPrice(String(item.price));
                              }}
                              className="w-9 h-9 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f] flex items-center justify-center cursor-pointer transition-colors"
                              title="Edit item"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>

                            <button
                              type="button"
                              onClick={() => deleteOfficerItem(item.id)}
                              className="w-9 h-9 rounded-full bg-[#f5f5f7] hover:bg-[#fceaea] text-[#6e6e73] hover:text-[#c62828] flex items-center justify-center cursor-pointer transition-colors"
                              title="Delete item"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          ) : (
            /* Airman Catalog */
            <div className="space-y-4">
              <form
                onSubmit={handleAddAirmanItem}
                className="p-4 bg-[#f5f5f7] rounded-[18px] grid grid-cols-1 sm:grid-cols-12 gap-3 items-center"
              >
                <div className="sm:col-span-9">
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">
                    Airman Garment Name
                  </label>
                  <input
                    type="text"
                    value={newAirmanName}
                    onChange={(e) => setNewAirmanName(e.target.value)}
                    placeholder="e.g. Khaki Half Shirt"
                    className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[14px] text-[#1d1d1f] outline-none focus:border-[#0071e3]"
                  />
                </div>
                <div className="sm:col-span-3 sm:self-end">
                  <button
                    type="submit"
                    className="w-full h-[44px] rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[14px] font-semibold cursor-pointer transition-all active:scale-95 shadow-xs flex items-center justify-center gap-1.5"
                  >
                    <Plus className="w-4 h-4" />
                    <span>+ Add garment</span>
                  </button>
                </div>
              </form>

              <div className="divide-y divide-[#f0f0f0]">
                {state.settings.airmanItems.map((item) => {
                  const isEditing = editingAirmanId === item.id;
                  return (
                    <div
                      key={item.id}
                      className="py-3 flex items-center justify-between gap-3 text-[14px]"
                    >
                      {isEditing ? (
                        <div className="flex-1 flex items-center gap-2">
                          <input
                            type="text"
                            value={editAirmanName}
                            onChange={(e) => setEditAirmanName(e.target.value)}
                            className="flex-1 h-9 px-3 rounded-[10px] bg-white border border-[#e0e0e0] text-[14px]"
                          />
                          <button
                            type="button"
                            onClick={() => handleSaveEditAirman(item.id)}
                            className="h-9 px-3 rounded-full bg-[#0066cc] text-white text-[12px] font-semibold"
                          >
                            Save
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingAirmanId(null)}
                            className="h-9 px-2 rounded-full bg-[#f5f5f7] text-[#6e6e73] text-[12px]"
                          >
                            ✕
                          </button>
                        </div>
                      ) : (
                        <>
                          <span className="font-semibold text-[#1d1d1f] truncate">{item.name}</span>
                          <div className="flex items-center gap-3">
                            <button
                              type="button"
                              onClick={() => {
                                setEditingAirmanId(item.id);
                                setEditAirmanName(item.name);
                              }}
                              className="w-9 h-9 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f] flex items-center justify-center cursor-pointer transition-colors"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={() => deleteAirmanItem(item.id)}
                              className="w-9 h-9 rounded-full bg-[#f5f5f7] hover:bg-[#fceaea] text-[#6e6e73] hover:text-[#c62828] flex items-center justify-center cursor-pointer transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* Footnote per Section 10.10 */}
          <div className="pt-4 border-t border-[#f0f0f0] text-[13px] text-[#6e6e73]">
            Changing or removing an item never changes orders that already exist.
          </div>
        </div>

        {/* =========================================================================
            RIGHT COLUMN (4 Cols): Stacked Option Cards
            Section 5.5 & Section 10.10
           ========================================================================= */}
        <div className="lg:col-span-4 space-y-6">
          {/* Card 1: Default Discount Segmented Control */}
          <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-3 select-none">
            <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Default Discount Mode</h3>
            <p className="text-[13px] text-[#6e6e73]">
              Configure default discount calculation logic.
            </p>

            {/* Segmented control per Section 10.10 */}
            <div className="p-1 rounded-full bg-[#f5f5f7] flex items-center border border-[#e0e0e0]/70">
              <button
                type="button"
                onClick={() => setDiscountType('percentage')}
                className={`flex-1 h-9 rounded-full text-[13px] font-semibold transition-all cursor-pointer ${
                  discountType === 'percentage'
                    ? 'bg-[#1d1d1f] text-white shadow-xs'
                    : 'text-[#6e6e73] hover:text-[#1d1d1f]'
                }`}
              >
                Percentage (%)
              </button>
              <button
                type="button"
                onClick={() => setDiscountType('taka')}
                className={`flex-1 h-9 rounded-full text-[13px] font-semibold transition-all cursor-pointer ${
                  discountType === 'taka'
                    ? 'bg-[#1d1d1f] text-white shadow-xs'
                    : 'text-[#6e6e73] hover:text-[#1d1d1f]'
                }`}
              >
                Taka (৳ Flat)
              </button>
            </div>
          </div>

          {/* Card 2: Delivery Days Stepper per Section 10.10 */}
          <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-3 select-none">
            <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Upcoming Delivery Days</h3>
            <p className="text-[13px] text-[#6e6e73]">
              Horizon for alert flags and upcoming dashboard tiles.
            </p>

            <div className="h-14 px-3 rounded-full bg-[#f5f5f7] flex items-center justify-between border border-[#e0e0e0]/70">
              <button
                type="button"
                onClick={() => setUpcomingDays(Math.max(1, upcomingDays - 1))}
                className="w-10 h-10 rounded-full bg-white text-[#1d1d1f] border border-[#e0e0e0] flex items-center justify-center font-bold text-lg hover:bg-[#fafafc] active:scale-95 transition-transform"
              >
                <Minus className="w-4 h-4" />
              </button>
              <div className="text-center">
                <span className="text-[22px] font-semibold text-[#1d1d1f] num leading-none block">
                  {upcomingDays}
                </span>
                <span className="text-[11px] text-[#6e6e73]">days ahead</span>
              </div>
              <button
                type="button"
                onClick={() => setUpcomingDays(Math.min(30, upcomingDays + 1))}
                className="w-10 h-10 rounded-full bg-white text-[#1d1d1f] border border-[#e0e0e0] flex items-center justify-center font-bold text-lg hover:bg-[#fafafc] active:scale-95 transition-transform"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Card 3: Ribbon Values with Ruler Tick Strip */}
          <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-3">
            <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Ribbon Scale Values</h3>
            <p className="text-[13px] text-[#6e6e73]">
              Military uniform ribbon widths and counts.
            </p>

            {/* Signature Ruler Tick Strip Motif above chips */}
            <div className="py-1">
              <RulerTickStrip dark={true} className="h-4 opacity-50" />
            </div>

            <div className="flex flex-wrap gap-1.5 pt-1">
              {(state.settings.ribbonValues || ['1', '2', '3', '4', '5']).map((val) => (
                <span
                  key={val}
                  className="h-8 pl-3 pr-2 rounded-full bg-white border border-[#e0e0e0] text-[13px] font-semibold text-[#1d1d1f] inline-flex items-center gap-1.5"
                >
                  <span>{val}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveRibbon(val)}
                    className="w-4 h-4 text-[#6e6e73] hover:text-[#c62828] cursor-pointer"
                  >
                    ×
                  </button>
                </span>
              ))}
            </div>

            <div className="flex items-center gap-2 pt-1">
              <input
                type="text"
                value={newRibbonVal}
                onChange={(e) => setNewRibbonVal(e.target.value)}
                placeholder="Value"
                className="h-9 px-3 rounded-full bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] text-[#1d1d1f] w-24 outline-none"
              />
              <button
                type="button"
                onClick={handleAddRibbon}
                className="h-9 px-3.5 rounded-full bg-white hover:bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] font-semibold text-[#0066cc]"
              >
                + Add value
              </button>
            </div>
          </div>

          {/* Card 4: Shop Invoice Identity */}
          <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-3">
            <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Invoice Header Info</h3>
            <div className="space-y-2.5">
              <div>
                <label className="text-[11px] font-semibold text-[#6e6e73] block mb-1">Store Name</label>
                <input
                  type="text"
                  value={shopName}
                  onChange={(e) => setShopName(e.target.value)}
                  className="w-full h-9 px-3 rounded-[10px] bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] font-semibold text-[#1d1d1f]"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-[#6e6e73] block mb-1">Phone</label>
                <input
                  type="text"
                  value={shopPhone}
                  onChange={(e) => setShopPhone(e.target.value)}
                  className="w-full h-9 px-3 rounded-[10px] bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] text-[#1d1d1f]"
                />
              </div>
              <div>
                <label className="text-[11px] font-semibold text-[#6e6e73] block mb-1">Address</label>
                <input
                  type="text"
                  value={shopAddress}
                  onChange={(e) => setShopAddress(e.target.value)}
                  className="w-full h-9 px-3 rounded-[10px] bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] text-[#1d1d1f]"
                />
              </div>
            </div>
          </div>

          {/* Card 5: Backup & Offline Install */}
          <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-3">
            <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Database Backup</h3>
            <p className="text-[13px] text-[#6e6e73]">
              Download complete local JSON backup of all orders, cutting slips, customers, and staff ledgers.
            </p>
            <button
              type="button"
              onClick={handleExportBackup}
              className="w-full h-[40px] rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#1d1d1f] text-[13px] font-semibold flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              <Download className="w-4 h-4 text-[#6e6e73]" />
              <span>Export Full JSON Backup</span>
            </button>

            <div className="pt-2">
              <PWAInstallButton />
            </div>
          </div>
        </div>
      </div>
    </PolarisPage>
  );
};
