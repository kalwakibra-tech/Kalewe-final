import React, { useState } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { Draft } from '../types/index.ts';
import { FileText, Trash2, ArrowRight } from 'lucide-react';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { AnimatePresence } from 'motion/react';

interface DraftsScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const DraftsScreen: React.FC<DraftsScreenProps> = ({ onNavigate }) => {
  const { state, deleteDraft } = useApp();
  const [deleteTargetId, setDeleteTargetId] = useState<string | null>(null);

  const formatRelativeTime = (isoString: string) => {
    try {
      const diffMs = Date.now() - new Date(isoString).getTime();
      const diffMins = Math.floor(diffMs / (1000 * 60));
      const diffHours = Math.floor(diffMins / 60);
      const diffDays = Math.floor(diffHours / 24);

      if (diffMins < 1) return 'Saved just now';
      if (diffMins < 60) return `Saved ${diffMins}m ago`;
      if (diffHours < 24) return `Saved ${diffHours}h ago`;
      return `Saved ${diffDays}d ago`;
    } catch {
      return 'Saved recently';
    }
  };

  const sortedDrafts = [...state.drafts].sort((a, b) => {
    return new Date(b.lastSaved).getTime() - new Date(a.lastSaved).getTime();
  });

  const handleDeleteConfirm = () => {
    if (deleteTargetId) {
      deleteDraft(deleteTargetId);
      setDeleteTargetId(null);
    }
  };

  const handleOpenDraft = (draft: Draft) => {
    if (draft.category === 'Officer') {
      onNavigate('new-officer-order', { draftId: draft.id });
    } else {
      onNavigate('new-airman-order', { draftId: draft.id });
    }
  };

  return (
    <PolarisPage
      title="Draft Orders"
      subtitle="In-progress uniform records saved across sessions before formal submission."
      fullWidth
    >
      <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4 select-none">
        <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0]">
          <h2 className="text-[20px] font-semibold text-[#1d1d1f]">
            Pending Draft Queue
          </h2>
          <span className="text-[13px] text-[#6e6e73]">
            {sortedDrafts.length} {sortedDrafts.length === 1 ? 'draft' : 'drafts'}
          </span>
        </div>

        {sortedDrafts.length === 0 ? (
          <div className="py-12 text-center text-[#6e6e73]">
            <FileText className="w-8 h-8 text-[#e0e0e0] mx-auto mb-2" />
            <p className="text-[15px] font-semibold text-[#1d1d1f]">No saved drafts</p>
            <p className="text-[13px] mt-1">Unfinished orders will appear here automatically.</p>
          </div>
        ) : (
          <div className="divide-y divide-[#f0f0f0]">
            {sortedDrafts.map((draft) => {
              const itemCount =
                draft.category === 'Officer'
                  ? draft.officerItems?.length || 0
                  : draft.airmanItems?.length || 0;

              return (
                <div
                  key={draft.id}
                  className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-[#fafafc] rounded-[16px] px-3 transition-colors"
                >
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="entity-chip">
                      {draft.category === 'Officer' ? 'OFF' : 'AIR'}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[15px] font-semibold text-[#1d1d1f] truncate">
                          {draft.customerName || 'Unnamed draft'}
                        </span>
                        <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#f5f5f7] text-[#6e6e73]">
                          {draft.category}
                        </span>
                      </div>
                      <div className="text-[12px] text-[#6e6e73] mt-0.5 flex items-center gap-2">
                        <span>BD/{draft.customerBdNumber || 'Not set'}</span>
                        <span>· {itemCount} items</span>
                        <span>· {formatRelativeTime(draft.lastSaved)}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 self-end sm:self-auto shrink-0">
                    <button
                      onClick={() => handleOpenDraft(draft)}
                      className="h-[36px] px-4 rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[13px] font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs active:scale-95 transition-all"
                    >
                      <span>Resume</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setDeleteTargetId(draft.id)}
                      className="w-9 h-9 rounded-full bg-[#f5f5f7] hover:bg-[#fceaea] text-[#6e6e73] hover:text-[#c62828] flex items-center justify-center cursor-pointer transition-colors"
                      title="Discard draft"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Delete Draft Modal */}
      <AnimatePresence>
        {deleteTargetId && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setDeleteTargetId(null)}
            />
            <div className="relative z-10 w-full max-w-sm bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Discard this draft?</h3>
              <p className="text-[14px] text-[#6e6e73] mt-2">
                This in-progress order draft will be deleted permanently.
              </p>
              <div className="grid grid-cols-2 gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setDeleteTargetId(null)}
                  className="h-[44px] rounded-full bg-[#f5f5f7] text-[#1d1d1f] font-semibold text-[14px]"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleDeleteConfirm}
                  className="h-[44px] rounded-full bg-[#c62828] text-white font-semibold text-[14px]"
                >
                  Discard
                </button>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </PolarisPage>
  );
};
