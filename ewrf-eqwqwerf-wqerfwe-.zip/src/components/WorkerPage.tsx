import React, { useState, useEffect, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { WorkerEntryRow } from '../types/index.ts';
import { MONTH_METADATA } from '../utils/starterData.ts';
import { calculateWorkerMonthHishab, formatDate } from '../utils/logic.ts';
import { exportWorkerPayslipPDF } from '../utils/pdfGenerator.ts';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import {
  Plus,
  Save,
  Printer,
  Trash2,
  Calendar,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface WorkerPageProps {
  workerId: string;
  initialMonth?: string;
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const WorkerPage: React.FC<WorkerPageProps> = ({
  workerId,
  initialMonth,
  onNavigate,
}) => {
  const { state, saveWorkerRows, addWorkerPayment, deleteWorkerPayment } = useApp();

  const worker = useMemo(() => {
    return state.workers.find((w) => w.id === workerId);
  }, [state.workers, workerId]);

  const [selectedMonth, setSelectedMonth] = useState<string>(() => {
    if (initialMonth) return initialMonth;
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });

  // Local rows for this month
  const [rows, setRows] = useState<WorkerEntryRow[]>([]);
  const [isDirty, setIsDirty] = useState(false);
  const [saveNotice, setSaveNotice] = useState(false);

  // New advance payment input
  const [advanceAmountInput, setAdvanceAmountInput] = useState('');
  const [advanceNotesInput, setAdvanceNotesInput] = useState('');

  // Load rows when month or worker changes
  useEffect(() => {
    const existing = state.workerRows.filter(
      (r) => r.workerId === workerId && (r.date || '').slice(0, 7) === selectedMonth
    );
    if (existing.length > 0) {
      setRows(existing);
    } else {
      // Default empty rows from catalog or blank
      const starterItems: WorkerEntryRow[] = state.settings.workItems.slice(0, 5).map((wi, idx) => ({
        id: `row-${Date.now()}-${idx}`,
        workerId,
        date: `${selectedMonth}-01`,
        serial: '',
        bdNumber: '',
        name: '',
        item: wi.name,
        unitPrice: wi.rate,
        quantity: 0,
        totalTaka: 0,
        khorochDate: '',
        khoroch: 0,
        note: '',
      }));
      setRows(starterItems);
    }
    setIsDirty(false);
  }, [workerId, selectedMonth, state.workerRows, state.settings.workItems]);

  const hishab = useMemo(() => {
    return calculateWorkerMonthHishab(
      workerId,
      state.workerRows,
      state.workerPayments,
      selectedMonth
    );
  }, [workerId, selectedMonth, state.workerRows, state.workerPayments]);

  // Current advance payments for this worker in this month
  const currentAdvances = useMemo(() => {
    return state.workerPayments.filter(
      (p) => p.workerId === workerId && p.forMonth === selectedMonth
    );
  }, [state.workerPayments, workerId, selectedMonth]);

  const handleRowChange = (id: string, field: 'item' | 'unitPrice' | 'quantity', value: any) => {
    setIsDirty(true);
    setRows((prev) =>
      prev.map((r) => {
        if (r.id !== id) return r;
        const updated = { ...r, [field]: value };
        if (field === 'unitPrice' || field === 'quantity') {
          const rateNum = field === 'unitPrice' ? parseFloat(value) || 0 : r.unitPrice;
          const qtyNum = field === 'quantity' ? parseInt(value) || 0 : r.quantity;
          updated.totalTaka = rateNum * qtyNum;
        }
        return updated;
      })
    );
  };

  const handleAddRow = () => {
    setIsDirty(true);
    const newRow: WorkerEntryRow = {
      id: `row-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      workerId,
      date: `${selectedMonth}-01`,
      serial: '',
      bdNumber: '',
      name: '',
      item: 'Custom Piece Work',
      unitPrice: 100,
      quantity: 1,
      totalTaka: 100,
      khorochDate: '',
      khoroch: 0,
      note: '',
    };
    setRows((prev) => [...prev, newRow]);
  };

  const handleRemoveRow = (id: string) => {
    setIsDirty(true);
    setRows((prev) => prev.filter((r) => r.id !== id));
  };

  const handleSaveRows = () => {
    saveWorkerRows(workerId, rows);
    setIsDirty(false);
    setSaveNotice(true);
    setTimeout(() => setSaveNotice(false), 3000);
  };

  const handleAddAdvance = (e: React.FormEvent) => {
    e.preventDefault();
    const amt = parseFloat(advanceAmountInput);
    if (isNaN(amt) || amt <= 0) return;

    addWorkerPayment({
      workerId,
      forMonth: selectedMonth,
      amount: amt,
      note: advanceNotesInput.trim() || 'Mid-month cash advance',
      date: formatDate(),
    });

    setAdvanceAmountInput('');
    setAdvanceNotesInput('');
  };

  const handlePrintPayslip = () => {
    if (!worker) return;
    exportWorkerPayslipPDF({
      shopName: state.settings.invoiceShopName || 'Raymond',
      workerName: worker.name + (worker.banglaName ? ` (${worker.banglaName})` : ''),
      workerRole: 'Master Tailor',
      month: selectedMonth,
      hishab: {
        totalAmount: hishab.totalAmount,
        totalKhoroch: hishab.totalKhoroch,
        netPayable: hishab.netPayable,
        received: hishab.received,
        due: hishab.due,
        status: hishab.status,
        worksCount: hishab.worksCount,
      },
    });
  };

  if (!worker) {
    return (
      <PolarisPage title="Craftsman Not Found" backAction={() => onNavigate('staff-management')}>
        <div className="bg-white rounded-[24px] p-8 text-center text-[#6e6e73]">
          Craftsman not found.
        </div>
      </PolarisPage>
    );
  }

  return (
    <PolarisPage
      title={`${worker.name} — ${selectedMonth}`}
      subtitle={`${worker.banglaName ? `${worker.banglaName} · ` : ''}Monthly piece-rate ledger & payslip statement.`}
      backAction={() => onNavigate('staff-management')}
      secondaryActions={[
        {
          label: 'Print Payslip',
          icon: <Printer className="w-4 h-4" />,
          onClick: handlePrintPayslip,
        },
      ]}
      primaryAction={{
        label: isDirty ? 'Save changes' : 'Saved',
        icon: <Save className="w-4 h-4" />,
        onClick: handleSaveRows,
        disabled: !isDirty,
      }}
      fullWidth
    >
      {/* Save Success Alert */}
      {saveNotice && (
        <div className="p-3 bg-[#e8f5e9] text-[#1e7b43] text-[13px] font-semibold rounded-[12px] flex items-center justify-between">
          <span>Worker piece-rate units saved successfully.</span>
        </div>
      )}

      {/* Month Selector Strip */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1 select-none">
        {MONTH_METADATA.map((m) => {
          const isSelected = selectedMonth.endsWith(m.numStr);
          return (
            <button
              key={m.numStr}
              aria-pressed={isSelected}
              onClick={() => setSelectedMonth(`2026-${m.numStr}`)}
              className={`h-9 px-4 rounded-full text-[13px] font-semibold transition-all cursor-pointer whitespace-nowrap ${
                isSelected
                  ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                  : 'bg-white border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
              }`}
            >
              {m.name}
            </button>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column (8 Cols): Piece-rate table & Advances */}
        <div className="lg:col-span-8 space-y-6">
          {/* Piece-Rate Worksheet Panel */}
          <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0]">
              <div>
                <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Garment Piece-Rate Worksheet</h3>
                <p className="text-[13px] text-[#6e6e73]">Itemized tailoring units completed this month</p>
              </div>
              <button
                type="button"
                onClick={handleAddRow}
                className="h-8 px-3 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#0066cc] text-[13px] font-semibold inline-flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Add Row</span>
              </button>
            </div>

            <div className="overflow-x-auto no-scrollbar">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="h-9 bg-[#f5f5f7] rounded-[10px] text-[12px] font-semibold text-[#6e6e73]">
                    <th className="px-3 rounded-l-[10px]">Work Item</th>
                    <th className="px-3 w-28 text-right">Rate (৳)</th>
                    <th className="px-3 w-24 text-center">Qty</th>
                    <th className="px-3 w-28 text-right">Total (৳)</th>
                    <th className="px-2 w-10 text-center rounded-r-[10px]"></th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f0f0f0]">
                  {rows.map((row) => (
                    <tr key={row.id} className="h-14">
                      <td className="px-3 py-2">
                        <input
                          type="text"
                          value={row.item}
                          onChange={(e) => handleRowChange(row.id, 'item', e.target.value)}
                          className="w-full h-9 px-2.5 rounded-[8px] bg-[#f5f5f7] text-[14px] font-semibold text-[#1d1d1f] outline-none"
                        />
                      </td>
                      <td className="px-3 py-2 text-right">
                        <input
                          type="number"
                          min="0"
                          value={row.unitPrice}
                          onChange={(e) => handleRowChange(row.id, 'unitPrice', e.target.value)}
                          className="w-full h-9 px-2 text-right rounded-[8px] bg-[#f5f5f7] text-[14px] font-semibold text-[#1d1d1f] num outline-none"
                        />
                      </td>
                      <td className="px-3 py-2 text-center">
                        <input
                          type="number"
                          min="0"
                          value={row.quantity}
                          onChange={(e) => handleRowChange(row.id, 'quantity', e.target.value)}
                          className="w-full h-9 px-2 text-center rounded-[8px] bg-[#f5f5f7] text-[14px] font-semibold text-[#1d1d1f] num outline-none"
                        />
                      </td>
                      <td className="px-3 py-2 text-right font-semibold text-[#1d1d1f] text-[14px] num">
                        ৳{(row.totalTaka || 0).toLocaleString()}
                      </td>
                      <td className="px-2 py-2 text-center">
                        <button
                          type="button"
                          onClick={() => handleRemoveRow(row.id)}
                          className="w-7 h-7 rounded-full text-[#6e6e73] hover:text-[#c62828] hover:bg-[#fceaea] flex items-center justify-center mx-auto"
                        >
                          ✕
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Advance Payments Panel */}
          <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4">
            <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Monthly Advance Ledger</h3>

            <form
              onSubmit={handleAddAdvance}
              className="p-4 bg-[#f5f5f7] rounded-[18px] grid grid-cols-1 sm:grid-cols-12 gap-3 items-center"
            >
              <div className="sm:col-span-4">
                <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">Advance Amount (৳)</label>
                <input
                  type="number"
                  min="1"
                  value={advanceAmountInput}
                  onChange={(e) => setAdvanceAmountInput(e.target.value)}
                  placeholder="e.g. 2000"
                  className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[15px] font-semibold text-[#1d1d1f] num outline-none"
                />
              </div>
              <div className="sm:col-span-5">
                <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">Notes / Reason</label>
                <input
                  type="text"
                  value={advanceNotesInput}
                  onChange={(e) => setAdvanceNotesInput(e.target.value)}
                  placeholder="e.g. Weekly family allowance"
                  className="w-full h-[44px] px-3.5 rounded-[12px] bg-white border border-[#e0e0e0] text-[14px] text-[#1d1d1f] outline-none"
                />
              </div>
              <div className="sm:col-span-3 sm:self-end">
                <button
                  type="submit"
                  className="w-full h-[44px] rounded-full bg-[#1d1d1f] hover:bg-black text-white text-[14px] font-semibold cursor-pointer shadow-xs"
                >
                  Record Advance
                </button>
              </div>
            </form>

            <div className="divide-y divide-[#f0f0f0]">
              {currentAdvances.map((adv) => (
                <div key={adv.id} className="py-3 flex items-center justify-between text-[13px]">
                  <div>
                    <span className="font-semibold text-[#c62828] text-[15px] num mr-2">
                      -৳{adv.amount.toLocaleString()}
                    </span>
                    <span className="text-[#6e6e73]">{adv.note}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[#6e6e73] num">{adv.date}</span>
                    <button
                      onClick={() => deleteWorkerPayment(adv.id)}
                      className="text-[#6e6e73] hover:text-[#c62828]"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
              {currentAdvances.length === 0 && (
                <div className="py-4 text-center text-[#6e6e73] text-[13px]">
                  No cash advances drawn this month.
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right Column (4 Cols): Sticky Payroll Card */}
        <div className="lg:col-span-4 sticky top-6">
          <div className="object-card p-6 rounded-[24px] space-y-5 select-none">
            <div className="relative z-10 space-y-4">
              <span className="text-[14px] font-semibold text-white/70 block">
                Net Payable to {worker.name}
              </span>

              <div className="hero-num text-white">
                <span className="cur text-white/60">৳</span>
                {hishab.netPayable.toLocaleString()}
              </div>

              <div className="space-y-2 pt-3 border-t border-white/10 text-[13px]">
                <div className="flex justify-between text-white/80">
                  <span>Gross Tailoring Earnings:</span>
                  <span className="font-semibold text-white num">৳{hishab.totalAmount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-white/80">
                  <span>Advances Deducted:</span>
                  <span className="font-semibold text-[#fe6a6a] num">
                    -৳{(hishab.totalKhoroch + hishab.received).toLocaleString()}
                  </span>
                </div>
                <div className="flex justify-between text-white/80">
                  <span>Total Garments Tailored:</span>
                  <span className="font-semibold text-white num">{hishab.worksCount} items</span>
                </div>
              </div>

              <button
                type="button"
                onClick={handlePrintPayslip}
                className="w-full h-[44px] rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[14px] font-semibold flex items-center justify-center gap-2 cursor-pointer shadow-xs active:scale-95 transition-all"
              >
                <Printer className="w-4 h-4" />
                <span>Print Official Payslip</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </PolarisPage>
  );
};
