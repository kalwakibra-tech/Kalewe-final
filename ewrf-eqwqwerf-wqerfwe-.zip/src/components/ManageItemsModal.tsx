import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { ItemDefinition, AirmanItemDefinition, WorkItemDefinition } from '../types/index.ts';
import { STARTER_ITEMS } from '../utils/starterData.ts';
import {
  X,
  Search,
  Plus,
  Trash2,
  Check,
  Tag,
  AlertCircle,
  RotateCcw,
} from 'lucide-react';

interface ManageItemsModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'officer' | 'airman' | 'worker';
  onPriceChange?: () => void;
}

const CATEGORIES = ['Uniform', 'Shirt', 'Pant', 'Ceremonial', 'Civil', 'Meskit', 'Other'];

export const ManageItemsModal: React.FC<ManageItemsModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'officer',
  onPriceChange,
}) => {
  const {
    state,
    updateSettings,
    addOfficerItem,
    updateOfficerItem,
    deleteOfficerItem,
    addAirmanItem,
    deleteAirmanItem,
    updateWorkerItem,
  } = useApp();

  const [activeTab, setActiveTab] = useState<'officer' | 'airman' | 'worker'>(initialTab);
  const [searchQuery, setSearchQuery] = useState('');
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<string>('');

  const [newItemName, setNewItemName] = useState('');
  const [newItemPrice, setNewItemPrice] = useState<number | ''>('');
  const [newItemCategory, setNewItemCategory] = useState<string>('Uniform');
  const [formError, setFormError] = useState<string>('');
  const [priceOverrides, setPriceOverrides] = useState<Record<string, number>>({});

  const showNotice = (msg: string) => {
    setSaveSuccessNotice(msg);
    setTimeout(() => setSaveSuccessNotice(''), 3000);
  };

  const filteredOfficerItems = useMemo(() => {
    let list = state.settings.items;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter((i) => i.name.toLowerCase().includes(q) || (i.category || '').toLowerCase().includes(q));
    }
    return list;
  }, [state.settings.items, searchQuery]);

  const filteredAirmanItems = useMemo(() => {
    let list = state.settings.airmanItems;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter((i) => i.name.toLowerCase().includes(q));
    }
    return list;
  }, [state.settings.airmanItems, searchQuery]);

  const filteredWorkItems = useMemo(() => {
    let list = state.settings.workItems;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter((i) => i.name.toLowerCase().includes(q));
    }
    return list;
  }, [state.settings.workItems, searchQuery]);

  const handleAddNewOfficerItem = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    if (!newItemName.trim()) {
      setFormError('Item name is required');
      return;
    }
    const price = typeof newItemPrice === 'number' ? newItemPrice : 0;
    const res = addOfficerItem(newItemName.trim(), price, newItemCategory, 'Shirt');
    if (res.success) {
      showNotice(`Added "${newItemName}" at ৳${price}`);
      setNewItemName('');
      setNewItemPrice('');
      if (onPriceChange) onPriceChange();
    } else {
      setFormError(res.error || 'Failed to add item');
    }
  };

  const handleAddNewAirmanItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;
    const res = addAirmanItem(newItemName.trim(), 'Shirt');
    if (res.success) {
      showNotice(`Added Airman item "${newItemName}"`);
      setNewItemName('');
    }
  };

  const handlePriceBlur = (item: ItemDefinition, newPrice: number) => {
    if (newPrice !== item.price && !isNaN(newPrice)) {
      updateOfficerItem(item.id, item.name, newPrice, item.category, item.slipType);
      showNotice(`Saved ${item.name} at ৳${newPrice}`);
      if (onPriceChange) onPriceChange();
    }
  };

  const handleResetOfficerDefaults = () => {
    updateSettings({ items: STARTER_ITEMS });
    showNotice('Officer item catalog reset to defaults');
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="fixed inset-0 bg-black/35 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      <div
        className="relative z-10 w-full max-w-2xl bg-white rounded-[28px] border border-[#e0e0e0] shadow-[0_8px_32px_rgba(0,0,0,0.14)] flex flex-col max-h-[85vh] overflow-hidden select-none"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="px-6 py-4 border-b border-[#f0f0f0] flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-full bg-[#1d1d1f] text-white flex items-center justify-center">
              <Tag className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-[18px] font-semibold text-[#1d1d1f]">Catalog Items & Pricing</h3>
              <p className="text-[12px] text-[#6e6e73]">Edit standard rates across uniform lines</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f] flex items-center justify-center cursor-pointer transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Notice */}
        {saveSuccessNotice && (
          <div className="mx-6 mt-3 px-3 py-2 rounded-[12px] bg-[#e3f4e8] text-[#1e7b43] text-[13px] font-semibold flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>{saveSuccessNotice}</span>
          </div>
        )}

        {/* Tab Chips & Search */}
        <div className="px-6 py-3 border-b border-[#f0f0f0] flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-[#f5f5f7]">
          <div className="flex items-center gap-1.5">
            {(['officer', 'airman', 'worker'] as const).map((tab) => {
              const active = activeTab === tab;
              const labels = { officer: 'Officer Items', airman: 'Airman Items', worker: 'Artisan Rates' };
              return (
                <button
                  key={tab}
                  type="button"
                  aria-pressed={active}
                  onClick={() => setActiveTab(tab)}
                  className={`h-8 px-3.5 rounded-full text-[13px] font-semibold transition-all cursor-pointer ${
                    active
                      ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                      : 'bg-white border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
                  }`}
                >
                  {labels[tab]}
                </button>
              );
            })}
          </div>

          <div className="relative min-w-[200px]">
            <Search className="w-3.5 h-3.5 text-[#6e6e73] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Filter items..."
              className="w-full h-8 pl-8 pr-3 rounded-full bg-white border border-[#e0e0e0] text-[13px] outline-none"
            />
          </div>
        </div>

        {/* Body Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {activeTab === 'officer' && (
            <div className="space-y-4">
              {/* Add form */}
              <form
                onSubmit={handleAddNewOfficerItem}
                className="p-3.5 bg-[#f5f5f7] rounded-[16px] grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center"
              >
                <input
                  type="text"
                  value={newItemName}
                  onChange={(e) => setNewItemName(e.target.value)}
                  placeholder="New garment item"
                  className="sm:col-span-6 h-9 px-3 rounded-[10px] bg-white border border-[#e0e0e0] text-[13px] outline-none"
                />
                <input
                  type="number"
                  min="0"
                  value={newItemPrice}
                  onChange={(e) => setNewItemPrice(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="Price (৳)"
                  className="sm:col-span-3 h-9 px-3 rounded-[10px] bg-white border border-[#e0e0e0] text-[13px] num font-semibold outline-none"
                />
                <button
                  type="submit"
                  className="sm:col-span-3 h-9 px-3 rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[13px] font-semibold flex items-center justify-center gap-1 cursor-pointer active:scale-95"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Item</span>
                </button>
              </form>

              {/* Items List */}
              <div className="divide-y divide-[#f0f0f0] border border-[#e0e0e0] rounded-[18px] overflow-hidden">
                {filteredOfficerItems.map((item) => {
                  const currentDisplayPrice =
                    priceOverrides[item.id] !== undefined ? priceOverrides[item.id] : item.price;
                  return (
                    <div
                      key={item.id}
                      className="p-3 flex items-center justify-between gap-3 hover:bg-[#fafafc]"
                    >
                      <div className="min-w-0">
                        <span className="font-semibold text-[14px] text-[#1d1d1f] block truncate">
                          {item.name}
                        </span>
                        <span className="text-[11px] text-[#6e6e73]">{item.category || 'Uniform'}</span>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <div className="relative w-28">
                          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[12px] font-semibold text-[#6e6e73]">
                            ৳
                          </span>
                          <input
                            type="number"
                            min="0"
                            value={currentDisplayPrice}
                            onChange={(e) => {
                              const val = Number(e.target.value);
                              setPriceOverrides({ ...priceOverrides, [item.id]: val });
                            }}
                            onBlur={() => handlePriceBlur(item, currentDisplayPrice)}
                            className="w-full h-8 pl-6 pr-2 rounded-[8px] bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] font-semibold text-right num outline-none focus:border-[#0071e3]"
                          />
                        </div>

                        <button
                          type="button"
                          onClick={() => deleteOfficerItem(item.id)}
                          className="w-8 h-8 rounded-full hover:bg-[#fceaea] text-[#6e6e73] hover:text-[#c62828] flex items-center justify-center"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'airman' && (
            <div className="space-y-4">
              <form
                onSubmit={handleAddNewAirmanItem}
                className="p-3.5 bg-[#f5f5f7] rounded-[16px] flex items-center gap-2.5"
              >
                <input
                  type="text"
                  value={newItemName}
                  onChange={(e) => setNewItemName(e.target.value)}
                  placeholder="New Airman item (e.g. Battle Uniform)"
                  className="flex-1 h-9 px-3 rounded-[10px] bg-white border border-[#e0e0e0] text-[13px] outline-none"
                />
                <button
                  type="submit"
                  className="h-9 px-4 bg-[#0066cc] hover:bg-[#0071e3] text-white rounded-full text-[13px] font-semibold flex items-center gap-1 shrink-0 cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Item</span>
                </button>
              </form>

              <div className="divide-y divide-[#f0f0f0] border border-[#e0e0e0] rounded-[18px] overflow-hidden">
                {filteredAirmanItems.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 flex items-center justify-between gap-3 hover:bg-[#fafafc]"
                  >
                    <span className="font-semibold text-[14px] text-[#1d1d1f]">{item.name}</span>
                    <button
                      type="button"
                      onClick={() => deleteAirmanItem(item.id)}
                      className="w-8 h-8 rounded-full hover:bg-[#fceaea] text-[#6e6e73] hover:text-[#c62828] flex items-center justify-center"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'worker' && (
            <div className="space-y-4">
              <div className="divide-y divide-[#f0f0f0] border border-[#e0e0e0] rounded-[18px] overflow-hidden">
                {filteredWorkItems.map((item) => (
                  <div
                    key={item.id}
                    className="p-3 flex items-center justify-between gap-3 hover:bg-[#fafafc]"
                  >
                    <span className="font-semibold text-[14px] text-[#1d1d1f] truncate">
                      {item.name}
                    </span>
                    <div className="relative w-28 shrink-0">
                      <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-[12px] font-semibold text-[#6e6e73]">
                        ৳
                      </span>
                      <input
                        type="number"
                        min="0"
                        defaultValue={item.rate}
                        onBlur={(e) => {
                          const val = Number(e.target.value);
                          if (val !== item.rate && !isNaN(val)) {
                            updateWorkerItem(item.id, item.name, val);
                            showNotice(`Updated rate to ৳${val}`);
                          }
                        }}
                        className="w-full h-8 pl-6 pr-2 rounded-[8px] bg-[#f5f5f7] border border-[#e0e0e0] text-[13px] font-semibold text-right num outline-none focus:border-[#0071e3]"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-[#f0f0f0] bg-[#f5f5f7] flex items-center justify-between">
          {activeTab === 'officer' ? (
            <button
              type="button"
              onClick={handleResetOfficerDefaults}
              className="text-[12px] font-semibold text-[#6e6e73] hover:text-[#1d1d1f] flex items-center gap-1 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset Defaults</span>
            </button>
          ) : (
            <span />
          )}

          <button
            type="button"
            onClick={onClose}
            className="h-[40px] px-6 rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[14px] font-semibold cursor-pointer active:scale-95 transition-all"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
