import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { MONTH_METADATA } from '../utils/starterData.ts';
import { calculateWorkerMonthHishab } from '../utils/logic.ts';
import { exportStaffSummaryPDF } from '../utils/pdfGenerator.ts';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { RulerTickStrip } from './Illustrations.tsx';
import {
  Download,
  Search,
  ChevronRight,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface StaffSummaryScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const StaffSummaryScreen: React.FC<StaffSummaryScreenProps> = ({ onNavigate }) => {
  const { state } = useApp();

  const [selectedMonth, setSelectedMonth] = useState<string>(() => {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
  });

  const [searchQuery, setSearchQuery] = useState('');

  // Calculate summaries for all workers in the selected month
  const monthlySummaries = useMemo(() => {
    return state.workers.map((worker) => {
      const hishab = calculateWorkerMonthHishab(
        worker.id,
        state.workerRows,
        state.workerPayments,
        selectedMonth
      );
      return {
        worker,
        ...hishab,
      };
    });
  }, [state.workers, state.workerRows, state.workerPayments, selectedMonth]);

  const totals = useMemo(() => {
    return monthlySummaries.reduce(
      (acc, s) => {
        acc.totalAmount += s.totalAmount;
        acc.totalKhoroch += s.totalKhoroch;
        acc.netPayable += s.netPayable;
        acc.received += s.received;
        acc.due += s.due;
        acc.worksCount += s.worksCount;
        return acc;
      },
      { totalAmount: 0, totalKhoroch: 0, netPayable: 0, received: 0, due: 0, worksCount: 0 }
    );
  }, [monthlySummaries]);

  const filteredSummaries = useMemo(() => {
    if (!searchQuery.trim()) return monthlySummaries;
    const q = searchQuery.toLowerCase().trim();
    return monthlySummaries.filter(
      (s) =>
        s.worker.name.toLowerCase().includes(q) ||
        (s.worker.banglaName && s.worker.banglaName.toLowerCase().includes(q))
    );
  }, [monthlySummaries, searchQuery]);

  const handleExportPDF = () => {
    const rows = monthlySummaries.map((s) => ({
      name: s.worker.name + (s.worker.banglaName ? ` (${s.worker.banglaName})` : ''),
      role: 'Master Tailor',
      phone: '',
      totalWorks: s.worksCount,
      totalAmount: s.totalAmount,
      totalKhoroch: s.totalKhoroch,
      netPayable: s.netPayable,
      received: s.received,
      due: s.due,
      status: s.status,
    }));
    exportStaffSummaryPDF(state.settings.invoiceShopName || 'Raymond', selectedMonth, rows);
  };

  return (
    <PolarisPage
      title="Staff Monthly Hishab"
      subtitle="Monthly piece-rate ledger, gross artisan earnings, advances, and net payroll."
      secondaryActions={[
        {
          label: 'Export Monthly PDF',
          icon: <Download className="w-4 h-4" />,
          onClick: handleExportPDF,
        },
      ]}
      fullWidth
    >
      {/* Month Selection Bar */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1 select-none">
        {MONTH_METADATA.map((m) => {
          const isSelected = selectedMonth.endsWith(m.numStr);
          return (
            <button
              key={m.numStr}
              aria-pressed={isSelected}
              onClick={() => setSelectedMonth(`2026-${m.numStr}`)}
              className={`h-9 px-4 rounded-full text-[13px] font-semibold transition-all cursor-pointer whitespace-nowrap ${
                isSelected
                  ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                  : 'bg-white border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
              }`}
            >
              {m.name}
            </button>
          );
        })}
      </div>

      {/* Summary Band: Net Payroll Graphite Object Card + Stats */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 select-none">
        {/* Net Payroll Hero Card (5 Cols) */}
        <div className="md:col-span-5 object-card p-6 rounded-[24px] flex flex-col justify-between">
          <div className="relative z-10 space-y-4">
            <span className="text-[14px] font-semibold text-white/70 block">
              Total Net Payroll ({selectedMonth})
            </span>
            <div className="hero-num text-white">
              <span className="cur text-white/60">৳</span>
              {totals.netPayable.toLocaleString()}
            </div>
            <p className="text-[13px] text-white/60">
              Total net wage payable after deducting artisan advances and khoroch.
            </p>
          </div>
          <div className="relative z-10 pt-4">
            <RulerTickStrip dark={false} className="h-4 opacity-40" />
          </div>
        </div>

        {/* 3 Supporting Metric Tiles (7 Cols) */}
        <div className="md:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="bg-white rounded-[20px] p-5 border border-[#e0e0e0] flex flex-col justify-between">
            <span className="text-[13px] font-semibold text-[#6e6e73]">Gross Piece-Rate</span>
            <div className="my-2">
              <span className="text-[28px] font-semibold text-[#1d1d1f] num leading-none block">
                ৳{totals.totalAmount.toLocaleString()}
              </span>
              <span className="text-[12px] text-[#6e6e73] block mt-1">earned by craftsmen</span>
            </div>
          </div>

          <div className="bg-white rounded-[20px] p-5 border border-[#e0e0e0] flex flex-col justify-between">
            <span className="text-[13px] font-semibold text-[#6e6e73]">Advances Paid</span>
            <div className="my-2">
              <span className="text-[28px] font-semibold text-[#c62828] num leading-none block">
                ৳{(totals.totalKhoroch + totals.received).toLocaleString()}
              </span>
              <span className="text-[12px] text-[#6e6e73] block mt-1">drawn this month</span>
            </div>
          </div>

          <div className="bg-white rounded-[20px] p-5 border border-[#e0e0e0] flex flex-col justify-between">
            <span className="text-[13px] font-semibold text-[#6e6e73]">Units Produced</span>
            <div className="my-2">
              <span className="text-[28px] font-semibold text-[#1e7b43] num leading-none block">
                {totals.worksCount}
              </span>
              <span className="text-[12px] text-[#6e6e73] block mt-1">garments tailored</span>
            </div>
          </div>
        </div>
      </div>

      {/* Artisan Ledger Table */}
      <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-[#f0f0f0] gap-3">
          <div>
            <h3 className="text-[20px] font-semibold text-[#1d1d1f]">Artisan Breakdown</h3>
            <p className="text-[13px] text-[#6e6e73]">Per-craftsman monthly settlement</p>
          </div>

          <div className="relative min-w-[240px]">
            <Search className="w-4 h-4 text-[#6e6e73] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search craftsman..."
              className="w-full h-9 pl-9 pr-3 rounded-full bg-[#f5f5f7] text-[13px] text-[#1d1d1f] outline-none"
            />
          </div>
        </div>

        <div className="overflow-x-auto no-scrollbar">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="h-10 bg-[#f5f5f7] rounded-[12px] text-[12px] font-semibold text-[#6e6e73] select-none">
                <th className="px-3.5 rounded-l-[12px]">Craftsman</th>
                <th className="px-3 text-center">Items</th>
                <th className="px-3 text-right">Gross Work</th>
                <th className="px-3 text-right">Advance/Khoroch</th>
                <th className="px-3 text-right">Net Payable</th>
                <th className="px-3.5 text-right rounded-r-[12px]">Statement</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#f0f0f0]">
              {filteredSummaries.map((s) => (
                <tr key={s.worker.id} className="h-16 hover:bg-[#fafafc]">
                  <td className="px-3.5 py-2">
                    <span className="font-semibold text-[#1d1d1f] text-[15px] block">
                      {s.worker.name}
                    </span>
                    {s.worker.banglaName && (
                      <span className="text-[12px] text-[#6e6e73]">{s.worker.banglaName}</span>
                    )}
                  </td>
                  <td className="px-3 py-2 text-center font-semibold text-[#1d1d1f] text-[14px] num">
                    {s.worksCount}
                  </td>
                  <td className="px-3 py-2 text-right font-semibold text-[#1d1d1f] text-[14px] num">
                    ৳{s.totalAmount.toLocaleString()}
                  </td>
                  <td className="px-3 py-2 text-right font-semibold text-[#c62828] text-[14px] num">
                    ৳{(s.totalKhoroch + s.received).toLocaleString()}
                  </td>
                  <td className="px-3 py-2 text-right">
                    <span className="font-semibold text-[15px] text-[#1e7b43] num">
                      ৳{s.netPayable.toLocaleString()}
                    </span>
                  </td>
                  <td className="px-3.5 py-2 text-right">
                    <button
                      onClick={() =>
                        onNavigate('worker-page', {
                          workerId: s.worker.id,
                          month: selectedMonth,
                        })
                      }
                      className="h-8 px-3.5 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#0066cc] text-[13px] font-semibold inline-flex items-center gap-1 cursor-pointer"
                    >
                      <span>Ledger</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </PolarisPage>
  );
};
