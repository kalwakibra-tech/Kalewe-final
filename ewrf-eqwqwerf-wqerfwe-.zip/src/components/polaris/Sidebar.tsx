import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../../context/AppContext.tsx';
import { ScreenName } from '../Navbar.tsx';
import { ManageItemsModal } from '../ManageItemsModal.tsx';
import { TailorTagIllustration } from '../Illustrations.tsx';
import {
  LayoutDashboard,
  ClipboardList,
  Plane,
  Truck,
  FileText,
  Users,
  History,
  UserCheck,
  BarChart3,
  Settings,
  X,
  Tag,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

interface SidebarProps {
  currentScreen: ScreenName;
  onNavigate: (screen: ScreenName, params?: any) => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

interface NavGroup {
  groupTitle?: string;
  items: {
    id: ScreenName;
    label: string;
    icon: React.ComponentType<{ className?: string; strokeWidth?: number }>;
    badge?: number;
    activeScreenMatches?: ScreenName[];
  }[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentScreen,
  onNavigate,
  mobileMenuOpen,
  setMobileMenuOpen,
}) => {
  const { state } = useApp();
  const [collapsed, setCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem('raymond_sidebar_collapsed') === 'true';
    } catch {
      return false;
    }
  });
  const [managePricesOpen, setManagePricesOpen] = useState<boolean>(false);

  const toggleCollapsed = () => {
    setCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('raymond_sidebar_collapsed', String(next));
      } catch {}
      return next;
    });
  };

  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => {
      document.body.style.overflow = '';
    };
  }, [mobileMenuOpen]);

  const draftsCount = state.drafts.length;

  const navGroups: NavGroup[] = [
    {
      groupTitle: 'Operations',
      items: [
        {
          id: 'dashboard',
          label: 'Dashboard',
          icon: LayoutDashboard,
        },
        {
          id: 'orders',
          label: 'Officer Orders',
          icon: ClipboardList,
          activeScreenMatches: ['new-officer-order', 'edit-officer-order', 'order-details'],
        },
        {
          id: 'airman-orders',
          label: 'Airman Orders',
          icon: Plane,
          activeScreenMatches: ['new-airman-order', 'edit-airman-order'],
        },
        {
          id: 'delivery',
          label: 'Deliveries',
          icon: Truck,
        },
        {
          id: 'drafts',
          label: 'Draft Orders',
          icon: FileText,
          badge: draftsCount > 0 ? draftsCount : undefined,
        },
      ],
    },
    {
      groupTitle: 'Workshop & Staff',
      items: [
        {
          id: 'customers',
          label: 'Customers',
          icon: Users,
        },
        {
          id: 'customer-history',
          label: 'Customer History',
          icon: History,
        },
        {
          id: 'staff-management',
          label: 'Staff Management',
          icon: UserCheck,
          activeScreenMatches: ['worker-page'],
        },
        {
          id: 'staff-summary',
          label: 'Staff Hishab',
          icon: BarChart3,
          activeScreenMatches: ['worker-history'],
        },
        {
          id: 'settings',
          label: 'Settings',
          icon: Settings,
        },
      ],
    },
  ];

  const handleItemClick = (id: ScreenName) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  const isSelected = (item: NavGroup['items'][0]) => {
    if (currentScreen === item.id) return true;
    if (item.activeScreenMatches && item.activeScreenMatches.includes(currentScreen)) {
      return true;
    }
    return false;
  };

  const renderNavContent = (isMobile: boolean) => (
    <div className="flex flex-col h-full justify-between select-none">
      <div className="flex-1 overflow-y-auto no-scrollbar space-y-6 px-3 pt-3">
        {/* Profile Capsule (Top of Sidebar per Section 4.2) */}
        {(!collapsed || isMobile) ? (
          <div
            onClick={() => handleItemClick('settings')}
            className="h-[56px] px-3.5 rounded-full bg-white flex items-center justify-between border border-[#e0e0e0] cursor-pointer hover:border-[#1d1d1f] transition-all shadow-xs"
            title="Raymond Settings"
          >
            <div className="flex items-center gap-3 min-w-0">
              <div className="w-9 h-9 rounded-full bg-[#1d1d1f] text-white flex items-center justify-center font-semibold text-sm shrink-0">
                R
              </div>
              <div className="min-w-0 leading-tight">
                <div className="text-[15px] font-semibold text-[#1d1d1f] truncate">
                  Raymond
                </div>
                <div className="text-[13px] font-normal text-[#6e6e73] truncate">
                  BAF Tailor Studio
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div
            onClick={() => handleItemClick('settings')}
            className="w-12 h-12 mx-auto rounded-full bg-white border border-[#e0e0e0] flex items-center justify-center cursor-pointer hover:border-[#1d1d1f] transition-all"
            title="Raymond - BAF Tailor Studio"
          >
            <div className="w-9 h-9 rounded-full bg-[#1d1d1f] text-white flex items-center justify-center font-semibold text-sm">
              R
            </div>
          </div>
        )}

        {/* Navigation Items Grouped */}
        {navGroups.map((group, groupIdx) => (
          <div key={groupIdx} className="space-y-1.5">
            {group.groupTitle && (!collapsed || isMobile) && (
              <div className="px-3.5 text-[12px] font-semibold text-[#6e6e73] tracking-wide">
                {group.groupTitle}
              </div>
            )}
            {collapsed && !isMobile && groupIdx > 0 && (
              <div className="w-8 h-px bg-[#e0e0e0] mx-auto my-3" />
            )}

            <nav className="space-y-1">
              {group.items.map((item) => {
                const active = isSelected(item);
                const Icon = item.icon;

                return (
                  <button
                    key={item.id}
                    onClick={() => handleItemClick(item.id)}
                    aria-current={active ? 'page' : undefined}
                    title={collapsed && !isMobile ? item.label : undefined}
                    className={`w-full h-[44px] rounded-full flex items-center transition-all cursor-pointer relative ${
                      collapsed && !isMobile
                        ? 'justify-center px-0'
                        : 'justify-between px-4'
                    } ${
                      active
                        ? 'bg-[#1d1d1f] text-white font-semibold'
                        : 'text-[#333333] hover:bg-white hover:text-[#1d1d1f] font-normal'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0 overflow-hidden">
                      <Icon
                        className={`w-5 h-5 shrink-0 ${active ? 'text-white' : 'text-[#6e6e73]'}`}
                        strokeWidth={1.75}
                      />
                      {(!collapsed || isMobile) && (
                        <span className="text-[15px] truncate whitespace-nowrap">{item.label}</span>
                      )}
                    </div>

                    {/* Badge Count */}
                    {(!collapsed || isMobile) && item.badge !== undefined && item.badge > 0 && (
                      <span
                        className={`text-[12px] font-semibold px-2 py-0.5 rounded-full ${
                          active ? 'bg-white text-[#1d1d1f]' : 'bg-[#e0e0e0] text-[#1d1d1f]'
                        }`}
                      >
                        {item.badge}
                      </span>
                    )}

                    {collapsed && !isMobile && item.badge !== undefined && item.badge > 0 && (
                      <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-[#fa7e42]" />
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        ))}
      </div>

      {/* Bottom Section: Quick Item Prices + Illustration or Collapse */}
      <div className="p-3 space-y-3 shrink-0">
        {/* Quick Item Prices Shortcut */}
        <button
          type="button"
          onClick={() => {
            setManagePricesOpen(true);
            if (isMobile) setMobileMenuOpen(false);
          }}
          title={collapsed && !isMobile ? 'Item Prices' : undefined}
          className={`w-full h-[44px] rounded-full flex items-center transition-all cursor-pointer border border-[#e0e0e0] bg-white text-[#0066cc] hover:bg-[#0066cc]/10 font-semibold text-[14px] ${
            collapsed && !isMobile ? 'justify-center px-0' : 'justify-between px-4'
          }`}
        >
          <div className="flex items-center gap-2.5">
            <Tag className="w-4 h-4 text-[#0066cc]" strokeWidth={2} />
            {(!collapsed || isMobile) && <span>Item Prices</span>}
          </div>
          {(!collapsed || isMobile) && (
            <span className="text-[11px] text-[#6e6e73] font-normal">Catalog</span>
          )}
        </button>

        {/* Tailor Hand Tag Signature Illustration at Bottom (Desktop expanded) */}
        {(!collapsed || isMobile) && (
          <div className="py-2 flex items-center justify-center">
            <TailorTagIllustration size={110} withString={true} />
          </div>
        )}

        {/* Desktop Rail Collapse Toggle */}
        {!isMobile && (
          <button
            type="button"
            onClick={toggleCollapsed}
            title={collapsed ? 'Expand sidebar' : 'Collapse to rail'}
            className="w-full h-[36px] rounded-full text-[#6e6e73] hover:text-[#1d1d1f] hover:bg-white flex items-center justify-center transition-colors text-[13px] font-semibold cursor-pointer border border-transparent hover:border-[#e0e0e0]"
          >
            {collapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <div className="flex items-center gap-1.5">
                <ChevronLeft className="w-4 h-4" />
                <span>Collapse sidebar</span>
              </div>
            )}
          </button>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Permanent Sidebar: 264px, shell background (#f5f5f7), directly on page */}
      <aside
        className={`hidden md:flex flex-col shrink-0 h-full bg-[#f5f5f7] select-none transition-[width] duration-200 ease-out py-3 ${
          collapsed ? 'w-[72px]' : 'w-[264px]'
        }`}
        aria-label="Main sidebar navigation"
      >
        {renderNavContent(false)}
      </aside>

      {/* Mobile Glass Drawer: Thick glass, sheet radius 38px, round close button */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <div className="fixed inset-0 z-50 md:hidden flex">
            {/* Scrim backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setMobileMenuOpen(false)}
              aria-hidden="true"
            />

            {/* Sliding Thick Glass Drawer (radius 38px) */}
            <motion.aside
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              transition={{ type: 'spring', damping: 28, stiffness: 350 }}
              className="relative z-10 w-[290px] max-w-[85vw] h-full bg-[#f5f5f7]/95 backdrop-blur-2xl text-[#1d1d1f] flex flex-col justify-between shadow-[0_8px_32px_rgba(0,0,0,0.14)] rounded-r-[38px] border-r border-white/60 p-2"
              aria-label="Mobile navigation drawer"
            >
              <div className="flex items-center justify-between p-3 border-b border-[#e0e0e0]/60">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[#1d1d1f] text-white flex items-center justify-center font-bold text-xs">
                    R
                  </div>
                  <span className="font-semibold text-[15px] text-[#1d1d1f]">Raymond</span>
                </div>
                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="w-9 h-9 rounded-full bg-white text-[#1d1d1f] border border-[#e0e0e0] flex items-center justify-center cursor-pointer active:scale-95 transition-transform shadow-xs"
                  aria-label="Close navigation"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="flex-1 overflow-hidden min-h-0 pt-2">
                {renderNavContent(true)}
              </div>
            </motion.aside>
          </div>
        )}
      </AnimatePresence>

      {/* Global Manage Items & Prices Modal */}
      <ManageItemsModal
        isOpen={managePricesOpen}
        onClose={() => setManagePricesOpen(false)}
        initialTab="officer"
      />
    </>
  );
};
