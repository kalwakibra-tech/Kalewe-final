import React, { useState } from 'react';
import { useApp } from '../../context/AppContext.tsx';
import { ScreenName } from '../Navbar.tsx';
import { ManageItemsModal } from '../ManageItemsModal.tsx';
import {
  Scissors,
  Search,
  Bell,
  Menu,
  X,
  Tag,
} from 'lucide-react';

interface TopBarProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
  onOpenSearch: () => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  onNavigate,
  onOpenSearch,
  mobileMenuOpen,
  setMobileMenuOpen,
}) => {
  const { state } = useApp();
  const [manageModalOpen, setManageModalOpen] = useState(false);

  // Calculate urgent/attention count for notification bell
  const upcomingCount = state.officerOrders.filter((o) => {
    if (o.status === 'Delivered') return false;
    if (!o.deliveryDate) return false;
    const diff = (new Date(o.deliveryDate).getTime() - new Date().getTime()) / (1000 * 3600 * 24);
    return diff >= 0 && diff <= (state.settings.upcomingDeliveryDays || 3);
  }).length;

  const dueCount = state.officerOrders.filter(
    (o) => o.status === 'Delivered' && o.due > 0
  ).length;

  const alertCount = upcomingCount + dueCount;

  return (
    <header
      className="h-[56px] bg-[#1A1A1A] text-white flex items-center justify-between px-2.5 sm:px-4 sticky top-0 z-40 select-none print:hidden border-b border-[#2A2A2A] w-full max-w-full overflow-hidden"
      style={{ height: 'var(--topbar-h)' }}
    >
      {/* Left: Brand Lockup & Mobile Hamburger */}
      <div className="flex items-center space-x-2 sm:space-x-3 shrink-0">
        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-1.5 text-[#B5B5B5] hover:text-white rounded-lg hover:bg-[#303030] focus:outline-none focus:ring-2 focus:ring-[#005BD3] active:scale-95 transition-transform"
          aria-label="Toggle navigation menu"
        >
          {mobileMenuOpen ? <X className="w-5 h-5 text-white" /> : <Menu className="w-5 h-5" />}
        </button>

        <div
          onClick={() => onNavigate('dashboard')}
          className="flex items-center space-x-2 cursor-pointer group shrink-0"
          title="Raymond - BAF Tailor Studio"
        >
          {/* Bespoke Raymond Tailors Brand Mark */}
          <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg bg-[#2A2A2A] flex items-center justify-center text-white border border-[#404040] shadow-xs group-hover:border-white/40 group-hover:bg-[#333333] transition-all">
            <Scissors className="w-4 h-4 transform -rotate-45 text-white stroke-[2.2]" />
          </div>
          <div className="leading-tight">
            <span className="font-bold text-white text-[14px] sm:text-[15px] tracking-tight block">
              Raymond
            </span>
            <span className="hidden sm:block text-[11px] text-[#A0A0A0] font-normal tracking-tight">
              BAF Tailor Studio
            </span>
          </div>
        </div>
      </div>

      {/* Center: Global Search Bar - Responsive, fits without side scrolling */}
      <div className="flex-1 min-w-0 max-w-[580px] mx-1.5 sm:mx-4">
        <button
          onClick={onOpenSearch}
          className="w-full h-[36px] rounded-xl bg-[#2D2D2D] hover:bg-[#383838] border border-[#3E3E3E] transition-all flex items-center justify-between px-2.5 sm:px-3.5 text-[#B5B5B5] focus:outline-none focus:ring-2 focus:ring-[#005BD3] text-[13px] cursor-pointer group shadow-inner"
          aria-label="Global search (Cmd + K)"
        >
          <div className="flex items-center space-x-2 truncate min-w-0">
            <Search className="w-4 h-4 shrink-0 text-[#B5B5B5] group-hover:text-white transition-colors" />
            <span className="truncate text-xs sm:text-[13px] font-normal text-[#B5B5B5] group-hover:text-[#E0E0E0]">
              <span className="hidden md:inline">Search orders, customers, BD, tailors...</span>
              <span className="md:hidden">Search orders, BD...</span>
            </span>
          </div>
          <div className="hidden sm:flex items-center space-x-1 shrink-0 ml-1.5">
            <kbd className="min-w-[18px] h-4.5 px-1 rounded bg-[#3A3A3A] border border-[#4A4A4A] text-[#B5B5B5] text-[10px] font-medium flex items-center justify-center">
              ⌘K
            </kbd>
          </div>
        </button>
      </div>

      {/* Right: Notifications Bell & Store Switcher */}
      <div className="flex items-center space-x-1 sm:space-x-2 shrink-0">
        {/* Notifications Bell */}
        <button
          onClick={() => onNavigate('delivery')}
          className="relative p-1.5 sm:p-2 rounded-lg text-[#B5B5B5] hover:text-white hover:bg-[#303030] transition-colors focus:outline-none focus:ring-2 focus:ring-[#005BD3]"
          title={alertCount > 0 ? `${alertCount} orders requiring attention` : 'Delivery notifications'}
          aria-label="Notifications"
        >
          <Bell className="w-5 h-5" />
          {alertCount > 0 && (
            <span className="absolute top-1 right-1 min-w-[16px] h-4 px-1 rounded-full bg-[#D72C35] text-white text-[10px] font-bold flex items-center justify-center shadow-xs">
              {alertCount > 9 ? '9+' : alertCount}
            </span>
          )}
        </button>

        {/* Quick Item Prices Button */}
        <button
          onClick={() => setManageModalOpen(true)}
          className="hidden sm:inline-flex items-center space-x-1.5 h-8 px-2.5 rounded-lg bg-[#2E2E2E] hover:bg-[#383838] border border-[#404040] text-blue-400 hover:text-blue-300 transition-colors text-xs font-semibold cursor-pointer"
          title="Quick edit item prices"
        >
          <Tag className="w-3.5 h-3.5" />
          <span className="hidden md:inline">Item Prices</span>
        </button>

        {/* Store / Workspace Switcher (Bespoke Raymond Monogram) */}
        <div
          onClick={() => onNavigate('settings')}
          className="flex items-center space-x-1.5 cursor-pointer p-1 rounded-lg hover:bg-[#303030] transition-colors"
          title="Raymond Studio Settings"
        >
          <div className="w-7 h-7 rounded-lg bg-[#2E2E2E] text-white font-semibold text-[13px] flex items-center justify-center shrink-0 border border-[#444444] shadow-xs">
            R
          </div>
          <span className="hidden xl:inline-block text-[13px] font-semibold text-white">
            Raymond
          </span>
        </div>

        {/* Global Manage Items Modal */}
        <ManageItemsModal
          isOpen={manageModalOpen}
          onClose={() => setManageModalOpen(false)}
        />
      </div>
    </header>
  );
};
