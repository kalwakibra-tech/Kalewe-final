import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ScreenName } from '../Navbar.tsx';
import { Sidebar } from './Sidebar.tsx';
import { GlobalSearchModal } from './GlobalSearchModal.tsx';
import { OfflineIndicator } from '../OfflineIndicator.tsx';
import {
  Menu,
  Search,
  LayoutDashboard,
  ClipboardList,
  Plane,
  Truck,
  Plus,
  MoreHorizontal,
  FileText,
  Users,
  History,
  UserCheck,
  BarChart3,
  Settings,
  X,
  ChevronRight,
  Scissors,
} from 'lucide-react';
import { useApp } from '../../context/AppContext.tsx';

interface AppFrameProps {
  currentScreen: ScreenName;
  onNavigate: (screen: ScreenName, params?: any) => void;
  children: React.ReactNode;
}

export const AppFrame: React.FC<AppFrameProps> = ({
  currentScreen,
  onNavigate,
  children,
}) => {
  const { state } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchModalOpen, setSearchModalOpen] = useState(false);
  const [moreSheetOpen, setMoreSheetOpen] = useState(false);
  const [quickOrderSheetOpen, setQuickOrderSheetOpen] = useState(false);

  // Floating Toast state (Undo toast per Darzi spec)
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [undoCallback, setUndoCallback] = useState<(() => void) | null>(null);

  const isOfficerActive =
    currentScreen === 'orders' ||
    currentScreen === 'new-officer-order' ||
    currentScreen === 'edit-officer-order' ||
    currentScreen === 'order-details';

  const isAirmanActive =
    currentScreen === 'airman-orders' ||
    currentScreen === 'new-airman-order' ||
    currentScreen === 'edit-airman-order';

  const isDashboardActive = currentScreen === 'dashboard';
  const isDeliveryActive = currentScreen === 'delivery';

  const isMoreActive =
    currentScreen === 'customers' ||
    currentScreen === 'customer-history' ||
    currentScreen === 'drafts' ||
    currentScreen === 'staff-management' ||
    currentScreen === 'staff-summary' ||
    currentScreen === 'worker-page' ||
    currentScreen === 'worker-history' ||
    currentScreen === 'settings';

  const draftsCount = state.drafts.length;

  const handleMobileNav = (screen: ScreenName) => {
    onNavigate(screen);
    setMoreSheetOpen(false);
    setQuickOrderSheetOpen(false);
  };

  return (
    <div className="min-h-screen bg-[#f5f5f7] flex flex-col font-sans selection:bg-[#0066cc] selection:text-white pb-24 md:pb-0 overflow-x-hidden">
      {/* Mobile Thin Glass Bar (< 768px): Round glass hamburger + Brand + Search */}
      <header className="md:hidden sticky top-0 z-40 h-[56px] px-4 flex items-center justify-between bg-[#f5f5f7]/85 backdrop-blur-xl border-b border-[#e0e0e0]/70 select-none">
        <button
          onClick={() => setMobileMenuOpen(true)}
          className="w-10 h-10 rounded-full bg-white text-[#1d1d1f] border border-[#e0e0e0] flex items-center justify-center cursor-pointer shadow-xs active:scale-95 transition-transform"
          aria-label="Open menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div
          onClick={() => onNavigate('dashboard')}
          className="flex items-center gap-2 cursor-pointer"
        >
          <div className="w-7 h-7 rounded-full bg-[#1d1d1f] text-white flex items-center justify-center font-bold text-xs">
            R
          </div>
          <span className="font-semibold text-[17px] text-[#1d1d1f] tracking-tight">
            Raymond
          </span>
        </div>

        <button
          onClick={() => setSearchModalOpen(true)}
          className="w-10 h-10 rounded-full bg-white text-[#1d1d1f] border border-[#e0e0e0] flex items-center justify-center cursor-pointer shadow-xs active:scale-95 transition-transform"
          aria-label="Search"
        >
          <Search className="w-4 h-4 text-[#6e6e73]" />
        </button>
      </header>

      {/* Main Shell Layout */}
      <div className="flex-1 flex overflow-hidden min-h-0 bg-[#f5f5f7]">
        {/* Persistent Desktop Left Sidebar (264px, shell background, no topbar) */}
        <Sidebar
          currentScreen={currentScreen}
          onNavigate={onNavigate}
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
        />

        {/* Main Content Canvas on Shell */}
        <main className="flex-1 overflow-y-auto min-w-0 bg-[#f5f5f7] p-4 sm:p-6 lg:p-8">
          {children}
        </main>
      </div>

      {/* Global Search Modal (Cmd + K) */}
      <GlobalSearchModal
        isOpen={searchModalOpen}
        onClose={() => setSearchModalOpen(false)}
        onNavigate={onNavigate}
      />

      {/* Offline Status Pill */}
      <OfflineIndicator />

      {/* Floating Glass Pill Toast with "Undo" per Section 1.4 item 10 & Section 10.12 */}
      <AnimatePresence>
        {toastMessage && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 15, scale: 0.95 }}
            className="fixed bottom-6 inset-x-0 mx-auto z-50 w-fit max-w-[90vw] h-[56px] px-5 rounded-full bg-[#272729]/95 text-white backdrop-blur-2xl border border-white/15 shadow-[0_8px_32px_rgba(0,0,0,0.22)] flex items-center gap-4 select-none"
            role="status"
          >
            <span className="text-[14px] font-semibold text-white truncate">
              {toastMessage}
            </span>
            {undoCallback && (
              <button
                onClick={() => {
                  undoCallback();
                  setToastMessage(null);
                  setUndoCallback(null);
                }}
                className="text-[14px] font-semibold text-[#2997ff] hover:underline cursor-pointer shrink-0 ml-1"
              >
                Undo
              </button>
            )}
            <button
              onClick={() => setToastMessage(null)}
              className="text-[#6e6e73] hover:text-white ml-1"
            >
              <X className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Mobile Floating Bottom Glass Capsule Navigation Dock (< 768px) */}
      <div className="md:hidden fixed bottom-4 inset-x-0 z-40 px-3 flex items-center justify-center pointer-events-none safe-area-bottom">
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Main Floating Glass Capsule */}
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="h-[52px] px-2 rounded-full bg-white/85 text-[#1d1d1f] border border-[#e0e0e0] shadow-[0_8px_32px_rgba(0,0,0,0.12)] backdrop-blur-xl flex items-center gap-1"
          >
            <button
              onClick={() => handleMobileNav('dashboard')}
              className={`h-9 px-3 rounded-full flex items-center gap-1.5 transition-all text-xs cursor-pointer ${
                isDashboardActive
                  ? 'bg-[#1d1d1f] text-white font-semibold'
                  : 'text-[#6e6e73] hover:text-[#1d1d1f] font-normal'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" strokeWidth={1.75} />
              {isDashboardActive && <span className="text-[12px]">Dashboard</span>}
            </button>

            <button
              onClick={() => handleMobileNav('orders')}
              className={`h-9 px-3 rounded-full flex items-center gap-1.5 transition-all text-xs cursor-pointer ${
                isOfficerActive
                  ? 'bg-[#1d1d1f] text-white font-semibold'
                  : 'text-[#6e6e73] hover:text-[#1d1d1f] font-normal'
              }`}
            >
              <ClipboardList className="w-4 h-4" strokeWidth={1.75} />
              {isOfficerActive && <span className="text-[12px]">Officers</span>}
            </button>

            <button
              onClick={() => handleMobileNav('airman-orders')}
              className={`h-9 px-3 rounded-full flex items-center gap-1.5 transition-all text-xs cursor-pointer ${
                isAirmanActive
                  ? 'bg-[#1d1d1f] text-white font-semibold'
                  : 'text-[#6e6e73] hover:text-[#1d1d1f] font-normal'
              }`}
            >
              <Plane className="w-4 h-4" strokeWidth={1.75} />
              {isAirmanActive && <span className="text-[12px]">Airmen</span>}
            </button>

            <button
              onClick={() => handleMobileNav('delivery')}
              className={`h-9 px-3 rounded-full flex items-center gap-1.5 transition-all text-xs cursor-pointer ${
                isDeliveryActive
                  ? 'bg-[#1d1d1f] text-white font-semibold'
                  : 'text-[#6e6e73] hover:text-[#1d1d1f] font-normal'
              }`}
            >
              <Truck className="w-4 h-4" strokeWidth={1.75} />
              {isDeliveryActive && <span className="text-[12px]">Delivery</span>}
            </button>

            <button
              onClick={() => setMoreSheetOpen(true)}
              className={`h-9 px-2.5 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                isMoreActive ? 'bg-[#1d1d1f] text-white' : 'text-[#6e6e73] hover:text-[#1d1d1f]'
              }`}
              title="More"
            >
              <MoreHorizontal className="w-4 h-4" />
            </button>
          </motion.div>

          {/* Floating Action Button (+ New Order) - Primary Blue per Spec */}
          <motion.button
            whileTap={{ scale: 0.92 }}
            onClick={() => setQuickOrderSheetOpen(true)}
            className="w-[50px] h-[52px] rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white flex items-center justify-center shadow-[0_8px_24px_rgba(0,102,204,0.35)] cursor-pointer shrink-0 transition-transform"
            aria-label="Create New Order"
          >
            <Plus className="w-5 h-5 stroke-[2.4]" />
          </motion.button>
        </div>
      </div>

      {/* Quick Order Selection Sheet */}
      <AnimatePresence>
        {quickOrderSheetOpen && (
          <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setQuickOrderSheetOpen(false)}
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
            />
            <motion.div
              initial={{ y: 100, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 100, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 350 }}
              className="relative z-10 w-full max-w-sm bg-white rounded-t-[32px] sm:rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl safe-area-bottom"
            >
              <div className="w-10 h-1 bg-[#e0e0e0] rounded-full mx-auto mb-4 sm:hidden" />
              <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0] mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[#1d1d1f] text-white flex items-center justify-center">
                    <Scissors className="w-4 h-4" />
                  </div>
                  <h3 className="text-[17px] font-semibold text-[#1d1d1f]">New Uniform Order</h3>
                </div>
                <button
                  onClick={() => setQuickOrderSheetOpen(false)}
                  className="p-1.5 rounded-full text-[#6e6e73] hover:text-[#1d1d1f] hover:bg-[#f5f5f7]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2.5">
                <button
                  onClick={() => handleMobileNav('new-officer-order')}
                  className="w-full p-4 rounded-[18px] bg-white hover:bg-[#f5f5f7] border border-[#e0e0e0] text-left flex items-center justify-between transition-all cursor-pointer active:scale-98"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-[#1d1d1f] flex items-center justify-center text-white">
                      <ClipboardList className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-[15px] font-semibold text-[#1d1d1f]">Officer Order</div>
                      <div className="text-[13px] text-[#6e6e73]">Commissioned Officer uniform & cutting slip</div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#6e6e73]" />
                </button>

                <button
                  onClick={() => handleMobileNav('new-airman-order')}
                  className="w-full p-4 rounded-[18px] bg-white hover:bg-[#f5f5f7] border border-[#e0e0e0] text-left flex items-center justify-between transition-all cursor-pointer active:scale-98"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-[#f5f5f7] flex items-center justify-center text-[#1d1d1f] border border-[#e0e0e0]">
                      <Plane className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-[15px] font-semibold text-[#1d1d1f]">Airman Order</div>
                      <div className="text-[13px] text-[#6e6e73]">Non-commissioned airmen trade batch</div>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#6e6e73]" />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* "More" Mobile Glass Sheet */}
      <AnimatePresence>
        {moreSheetOpen && (
          <div className="fixed inset-0 z-50 flex items-end justify-center">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMoreSheetOpen(false)}
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
            />
            <motion.div
              initial={{ y: 200, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: 200, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 350 }}
              className="relative z-10 w-full max-w-lg bg-white rounded-t-[38px] p-5 border-t border-[#e0e0e0] shadow-[0_-10px_40px_rgba(0,0,0,0.14)] safe-area-bottom max-h-[85vh] overflow-y-auto"
            >
              <div className="w-10 h-1 bg-[#e0e0e0] rounded-full mx-auto mb-4" />

              <div className="flex items-center justify-between pb-3 border-b border-[#f0f0f0] mb-4">
                <div>
                  <h3 className="text-[17px] font-semibold text-[#1d1d1f]">Workshop Modules</h3>
                  <p className="text-[13px] text-[#6e6e73]">Raymond BAF Tailor Studio</p>
                </div>
                <button
                  onClick={() => setMoreSheetOpen(false)}
                  className="p-1.5 rounded-full text-[#6e6e73] hover:text-[#1d1d1f] hover:bg-[#f5f5f7]"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Group: Orders & Records */}
              <div className="space-y-2 mb-4">
                <span className="text-[12px] font-semibold text-[#6e6e73] px-1 block">
                  Orders & Directory
                </span>
                <div className="bg-[#f5f5f7] rounded-[18px] overflow-hidden divide-y divide-[#e0e0e0]/70">
                  <button
                    onClick={() => handleMobileNav('drafts')}
                    className="w-full p-3.5 flex items-center justify-between text-left hover:bg-white transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-white text-[#1d1d1f] flex items-center justify-center border border-[#e0e0e0]">
                        <FileText className="w-4 h-4" />
                      </div>
                      <span className="text-[14px] font-semibold text-[#1d1d1f]">Draft Orders</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {draftsCount > 0 && (
                        <span className="px-2 py-0.5 rounded-full text-[12px] font-semibold bg-[#e0e0e0] text-[#1d1d1f]">
                          {draftsCount}
                        </span>
                      )}
                      <ChevronRight className="w-4 h-4 text-[#6e6e73]" />
                    </div>
                  </button>

                  <button
                    onClick={() => handleMobileNav('customers')}
                    className="w-full p-3.5 flex items-center justify-between text-left hover:bg-white transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-white text-[#1d1d1f] flex items-center justify-center border border-[#e0e0e0]">
                        <Users className="w-4 h-4" />
                      </div>
                      <span className="text-[14px] font-semibold text-[#1d1d1f]">Customers Directory</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#6e6e73]" />
                  </button>

                  <button
                    onClick={() => handleMobileNav('customer-history')}
                    className="w-full p-3.5 flex items-center justify-between text-left hover:bg-white transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-white text-[#1d1d1f] flex items-center justify-center border border-[#e0e0e0]">
                        <History className="w-4 h-4" />
                      </div>
                      <span className="text-[14px] font-semibold text-[#1d1d1f]">Customer History</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#6e6e73]" />
                  </button>
                </div>
              </div>

              {/* Group: Staff & Production */}
              <div className="space-y-2 mb-4">
                <span className="text-[12px] font-semibold text-[#6e6e73] px-1 block">
                  Staff & Production
                </span>
                <div className="bg-[#f5f5f7] rounded-[18px] overflow-hidden divide-y divide-[#e0e0e0]/70">
                  <button
                    onClick={() => handleMobileNav('staff-management')}
                    className="w-full p-3.5 flex items-center justify-between text-left hover:bg-white transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-white text-[#1d1d1f] flex items-center justify-center border border-[#e0e0e0]">
                        <UserCheck className="w-4 h-4" />
                      </div>
                      <span className="text-[14px] font-semibold text-[#1d1d1f]">Staff Management</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#6e6e73]" />
                  </button>

                  <button
                    onClick={() => handleMobileNav('staff-summary')}
                    className="w-full p-3.5 flex items-center justify-between text-left hover:bg-white transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-white text-[#1d1d1f] flex items-center justify-center border border-[#e0e0e0]">
                        <BarChart3 className="w-4 h-4" />
                      </div>
                      <span className="text-[14px] font-semibold text-[#1d1d1f]">Staff Monthly Summary</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-[#6e6e73]" />
                  </button>
                </div>
              </div>

              {/* Group: Settings */}
              <div>
                <button
                  onClick={() => handleMobileNav('settings')}
                  className="w-full p-3.5 rounded-[18px] bg-[#f5f5f7] hover:bg-white border border-[#e0e0e0] flex items-center justify-between text-left transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-white text-[#1d1d1f] flex items-center justify-center border border-[#e0e0e0]">
                      <Settings className="w-4 h-4" />
                    </div>
                    <span className="text-[14px] font-semibold text-[#1d1d1f]">Settings & Preferences</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-[#6e6e73]" />
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};
