import React from 'react';

export interface TabItem<T extends string = string> {
  id: T;
  label: string;
  count?: number;
}

interface PolarisTabsProps<T extends string = string> {
  tabs: TabItem<T>[];
  selectedTab: T;
  onSelectTab: (tabId: T) => void;
  tools?: React.ReactNode;
  className?: string;
}

export function PolarisTabs<T extends string = string>({
  tabs,
  selectedTab,
  onSelectTab,
  tools,
  className = '',
}: PolarisTabsProps<T>) {
  return (
    <div className={`flex flex-col md:flex-row md:items-center justify-between gap-3 py-1 ${className}`}>
      {/* Filter Chips row per Graphite & Parchment spec */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1" role="tablist">
        {tabs.map((tab) => {
          const isSelected = selectedTab === tab.id;
          return (
            <button
              key={tab.id}
              role="tab"
              aria-pressed={isSelected}
              onClick={() => onSelectTab(tab.id)}
              className={`h-[40px] px-4 rounded-full text-[14px] font-semibold tracking-[-0.224px] flex items-center gap-2 transition-all whitespace-nowrap cursor-pointer select-none ${
                isSelected
                  ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                  : 'bg-white border border-[#e0e0e0] text-[#1d1d1f] hover:bg-[#fafafc]'
              }`}
            >
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span className="text-[13px] font-normal text-[#6e6e73] num tabular-nums">
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Right Tools Slot (Search Pill, Sort Pill) */}
      {tools && <div className="shrink-0 flex items-center gap-2 flex-wrap">{tools}</div>}
    </div>
  );
}
