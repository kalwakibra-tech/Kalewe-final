import React, { useState, useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import { ScreenName } from './Navbar.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { formatDate } from '../utils/logic.ts';
import { EmptyStateCardsIllustration } from './Illustrations.tsx';
import {
  Search,
  Truck,
  CheckCircle2,
  X,
  Calendar,
  AlertCircle,
  Phone,
} from 'lucide-react';

interface DeliveryScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const DeliveryScreen: React.FC<DeliveryScreenProps> = ({ onNavigate }) => {
  const { state } = useApp();

  const [activeTab, setActiveTab] = useState<'Officer' | 'Airman'>('Officer');
  const [searchQuery, setSearchQuery] = useState('');

  const todayStr = formatDate();

  // Undelivered Officer Orders
  const undeliveredOfficerOrders = useMemo(() => {
    return state.officerOrders.filter((o) => o.status !== 'Delivered');
  }, [state.officerOrders]);

  // Undelivered Airman Orders
  const undeliveredAirmanOrders = useMemo(() => {
    return state.airmanOrders.filter((o) => o.status !== 'Delivered');
  }, [state.airmanOrders]);

  const currentList = activeTab === 'Officer' ? undeliveredOfficerOrders : undeliveredAirmanOrders;

  const filteredOrders = useMemo(() => {
    if (!searchQuery.trim()) return currentList;
    const q = searchQuery.toLowerCase().trim();
    return currentList.filter((order) => {
      const name = (order.customerName || '').toLowerCase();
      const phone = (order.customerPhone || '').toLowerCase();
      const bd = (order.customerBdNumber || '').toLowerCase();
      const num = String(order.orderNumber);
      return name.includes(q) || phone.includes(q) || bd.includes(q) || num.includes(q);
    });
  }, [currentList, searchQuery]);

  const handleDeliver = (orderNumber: number) => {
    onNavigate('confirm-delivery', {
      orderNumber,
      category: activeTab,
      returnTo: 'delivery',
    });
  };

  return (
    <PolarisPage
      title="Delivery Queue"
      subtitle="Operational handoff queue for finished BAF Officer & Airman uniforms."
      fullWidth
    >
      {/* Top Banner & Queue Status Tile */}
      <div className="bg-white rounded-[24px] p-6 border border-[#e0e0e0] flex flex-col md:flex-row md:items-center justify-between gap-4 select-none">
        <div>
          <span className="text-[12px] font-semibold text-[#6e6e73] uppercase tracking-wider block mb-1">
            Active Handoff Desk
          </span>
          <h2 className="text-[22px] font-semibold text-[#1d1d1f]">
            Pending Customer Delivery
          </h2>
          <p className="text-[14px] text-[#6e6e73] mt-0.5">
            Collect final payment, record receiver verification, and complete the order.
          </p>
        </div>

        {/* Small Graphite Count Tile per Section 5.6 */}
        <div className="object-card px-6 py-4 rounded-[18px] shrink-0 self-start md:self-auto min-w-[220px]">
          <div className="relative z-10 flex items-center justify-between gap-4">
            <div>
              <span className="text-[12px] text-white/70 block">Waiting for delivery</span>
              <span className="text-[28px] font-semibold text-white num leading-tight">
                {currentList.length} orders
              </span>
            </div>
            <div className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white">
              <Truck className="w-5 h-5" />
            </div>
          </div>
        </div>
      </div>

      {/* Control Band: Tab Chips + Search Pill */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 select-none">
        <div className="flex items-center gap-2">
          <button
            aria-pressed={activeTab === 'Officer'}
            onClick={() => setActiveTab('Officer')}
            className={`h-[40px] px-5 rounded-full text-[14px] font-semibold transition-all cursor-pointer ${
              activeTab === 'Officer'
                ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                : 'bg-white border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
            }`}
          >
            Officer Orders ({undeliveredOfficerOrders.length})
          </button>
          <button
            aria-pressed={activeTab === 'Airman'}
            onClick={() => setActiveTab('Airman')}
            className={`h-[40px] px-5 rounded-full text-[14px] font-semibold transition-all cursor-pointer ${
              activeTab === 'Airman'
                ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                : 'bg-white border border-[#e0e0e0] text-[#6e6e73] hover:text-[#1d1d1f]'
            }`}
          >
            Airman Orders ({undeliveredAirmanOrders.length})
          </button>
        </div>

        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-[#6e6e73] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by name, BD, or phone..."
            className="w-full h-[40px] pl-10 pr-8 rounded-full bg-white border border-[#e0e0e0] text-[14px] text-[#1d1d1f] placeholder-[#7a7a7a] outline-none focus:border-[#0071e3]"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6e6e73] hover:text-[#1d1d1f]"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Queue Rows Panel */}
      <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-4">
        {filteredOrders.length === 0 ? (
          <div className="py-12 text-center text-[#6e6e73] flex flex-col items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-[#f5f5f7] flex items-center justify-center text-[#1d1d1f] mb-3">
              <CheckCircle2 className="w-6 h-6 text-[#1e7b43]" />
            </div>
            <h3 className="text-[20px] font-semibold text-[#1d1d1f]">
              Nothing waiting for delivery
            </h3>
            <p className="text-[14px] mt-1">
              All active {activeTab} uniform orders have been completed and delivered.
            </p>
          </div>
        ) : (
          <div className="divide-y divide-[#f0f0f0]">
            {filteredOrders.map((order) => {
              const bd = order.customerBdNumber;
              const phone = order.customerPhone;
              const isOfficer = activeTab === 'Officer';
              const due = isOfficer ? (order as any).due : 0;
              const deliveryDate = 'deliveryDate' in order ? (order as any).deliveryDate : undefined;
              const isToday = deliveryDate === todayStr;

              return (
                <div
                  key={order.id}
                  className="py-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-[#fafafc] rounded-[16px] px-3 transition-colors"
                >
                  {/* Left: Entity Chip + Customer Name + Meta */}
                  <div className="flex items-center gap-3.5 min-w-0">
                    <div className="entity-chip">
                      #{order.orderNumber}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-[16px] font-semibold text-[#1d1d1f] truncate">
                          {order.customerName}
                        </span>
                        {isToday && (
                          <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[#fdeee7] text-[#c2410c]">
                            Today
                          </span>
                        )}
                      </div>
                      <div className="text-[13px] text-[#6e6e73] flex items-center gap-3 mt-0.5">
                        <span>{bd}</span>
                        {phone && <span>· {phone}</span>}
                        {deliveryDate && <span>· Due {deliveryDate}</span>}
                      </div>
                    </div>
                  </div>

                  {/* Right: Due Amount + Inline Deliver Pill */}
                  <div className="flex items-center gap-4 shrink-0 sm:self-center self-end">
                    {isOfficer && (
                      <div className="text-right">
                        <span className="text-[11px] text-[#6e6e73] block">Amount Due</span>
                        <span
                          className={`text-[16px] font-semibold num ${
                            due > 0 ? 'text-[#c62828]' : 'text-[#1e7b43]'
                          }`}
                        >
                          ৳{due.toLocaleString()}
                        </span>
                      </div>
                    )}

                    <button
                      onClick={() => handleDeliver(order.orderNumber)}
                      className="h-[40px] px-5 rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[14px] font-semibold flex items-center gap-2 cursor-pointer shadow-xs active:scale-95 transition-all"
                    >
                      <Truck className="w-4 h-4" />
                      <span>Deliver</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Footnote per Section 5.6 */}
        <div className="pt-4 border-t border-[#f0f0f0] text-center sm:text-left text-[13px] text-[#6e6e73]">
          Delivering an order updates its status and records completion with full audit hishab.
        </div>
      </div>
    </PolarisPage>
  );
};
