import React, { useMemo } from 'react';
import { useApp } from '../context/AppContext.tsx';
import {
  calculateWorkerMonthHishab,
  formatDate,
  getItemSlipType,
  formatShirtMeasurementsSlip,
  formatPantMeasurementsSlip,
} from '../utils/logic.ts';
import { Printer, ArrowLeft, Scissors, FileText } from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface PrintPreviewScreenProps {
  type: 'slip' | 'invoice' | 'worker-statement';
  orderNumber?: number;
  category?: 'Officer' | 'Airman';
  workerId?: string;
  month?: string;
  itemIndex?: number;
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const PrintPreviewScreen: React.FC<PrintPreviewScreenProps> = ({
  type,
  orderNumber,
  category = 'Officer',
  workerId,
  month,
  itemIndex,
  onNavigate,
}) => {
  const { state } = useApp();

  const isOfficer = category === 'Officer';
  const officerOrder = isOfficer ? state.officerOrders.find((o) => o.orderNumber === orderNumber) : null;
  const airmanOrder = !isOfficer ? state.airmanOrders.find((o) => o.orderNumber === orderNumber) : null;
  const order = isOfficer ? officerOrder : airmanOrder;

  const worker = workerId ? state.workers.find((w) => w.id === workerId) : null;

  const handlePrint = () => {
    window.print();
  };

  const paperSize =
    type === 'invoice'
      ? state.settings.invoicePaperSize
      : state.settings.cuttingSlipPaperSize;

  const slipCards = useMemo(() => {
    if (!order) return [];
    const itemsToProcess =
      itemIndex !== undefined && order.items[itemIndex]
        ? [{ item: order.items[itemIndex], originalIndex: itemIndex }]
        : order.items.map((item, idx) => ({ item, originalIndex: idx }));

    const cards: Array<{
      key: string;
      headerTitle: string;
      ribbonText: string;
      branchText?: string;
      itemNameText: string;
      measurementsText: string;
      notesText?: string;
      partName: 'Shirt' | 'Pant';
      dateText: string;
    }> = [];

    const customerDisplay = isOfficer
      ? officerOrder?.customerName || `Officer ${order.customerBdNumber}`
      : airmanOrder?.customerName || `Airman ${order.customerBdNumber}`;

    const headerTitle = `#${order.orderNumber} ~ ${customerDisplay} ~ ${order.customerBdNumber}`;
    const ribbonText = order.ribbon ? `R - ${order.ribbon}` : '';
    const branchText = isOfficer && officerOrder?.branch ? officerOrder.branch : undefined;
    const dateText = isOfficer
      ? `Delivery: ${officerOrder?.deliveryDate || '—'}`
      : `Order: ${order.orderDate}`;

    itemsToProcess.forEach(({ item, originalIndex }) => {
      const catalogItem = isOfficer
        ? state.settings.items.find((i) => i.name.toLowerCase() === item.name.toLowerCase())
        : state.settings.airmanItems.find((i) => i.name.toLowerCase() === item.name.toLowerCase());
      const explicitType = (item as any).slipType || catalogItem?.slipType;
      const resolvedType = getItemSlipType(item.name, explicitType);

      const qty = item.quantity || 1;
      const qtySuffix = qty > 1 ? ` (Qty ${qty})` : '';
      const ivSuffix = !isOfficer && (item as any).ivNumber ? ` ~ IV: ${(item as any).ivNumber}` : '';

      const shirtNotes = [
        order.shirtMeasurements?.handWrittenNotes,
        order.shirtMeasurements?.extraNotes,
      ]
        .filter(Boolean)
        .join(' | ');

      const pantNotes = [
        order.pantMeasurements?.handWrittenNotes,
        order.pantMeasurements?.extraNotes,
      ]
        .filter(Boolean)
        .join(' | ');

      if (resolvedType === 'Shirt') {
        cards.push({
          key: `item-${originalIndex}-shirt`,
          headerTitle,
          ribbonText,
          branchText,
          itemNameText: `Item: ${item.name}${qtySuffix}${ivSuffix}`,
          measurementsText: formatShirtMeasurementsSlip(order.shirtMeasurements),
          notesText: shirtNotes || undefined,
          partName: 'Shirt',
          dateText,
        });
      } else if (resolvedType === 'Pant') {
        cards.push({
          key: `item-${originalIndex}-pant`,
          headerTitle,
          ribbonText,
          branchText,
          itemNameText: `Item: ${item.name}${qtySuffix}${ivSuffix}`,
          measurementsText: formatPantMeasurementsSlip(order.pantMeasurements),
          notesText: pantNotes || undefined,
          partName: 'Pant',
          dateText,
        });
      } else {
        // 'Shirt + Pant' -> two separate slips (Shirt first, Pant second)
        cards.push({
          key: `item-${originalIndex}-set-shirt`,
          headerTitle,
          ribbonText,
          branchText,
          itemNameText: `Item: ${item.name} (Shirt)${qtySuffix}${ivSuffix}`,
          measurementsText: formatShirtMeasurementsSlip(order.shirtMeasurements),
          notesText: shirtNotes || undefined,
          partName: 'Shirt',
          dateText,
        });
        cards.push({
          key: `item-${originalIndex}-set-pant`,
          headerTitle,
          ribbonText,
          branchText,
          itemNameText: `Item: ${item.name} (Pant)${qtySuffix}${ivSuffix}`,
          measurementsText: formatPantMeasurementsSlip(order.pantMeasurements),
          notesText: pantNotes || undefined,
          partName: 'Pant',
          dateText,
        });
      }
    });

    return cards;
  }, [order, isOfficer, officerOrder, airmanOrder, itemIndex, state.settings.items, state.settings.airmanItems]);

  return (
    <div className="min-h-screen bg-[#f5f5f7] py-6 print:py-0 print:bg-white font-sans">
      {/* Top Controls Toolbar (Hidden in print) */}
      <div className="max-w-4xl mx-auto px-4 mb-6 print:hidden flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-[24px] border border-[#e0e0e0] shadow-[0_8px_32px_rgba(0,0,0,0.06)]">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate(order ? 'order-details' : 'staff-management', { orderNumber, category, workerId })}
            className="h-10 px-4 rounded-full border border-[#e0e0e0] bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[13px] font-semibold text-[#1d1d1f] flex items-center gap-1.5 cursor-pointer transition-colors active:scale-95"
          >
            <ArrowLeft className="w-4 h-4 stroke-[2]" />
            <span>Back</span>
          </button>
          <span className="text-[15px] font-semibold text-[#1d1d1f]">
            {type === 'slip'
              ? `Cutting ${itemIndex !== undefined ? 'Slip' : 'Slips'} — #${orderNumber} (${category})`
              : type === 'invoice'
              ? `Invoice — #${orderNumber}`
              : `Worker Statement — ${worker?.name} (${month})`}
          </span>
          <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-[#f5f5f7] text-[#6e6e73] font-semibold num">
            {paperSize}
          </span>
        </div>

        <div className="flex items-center gap-2.5">
          {type === 'slip' && isOfficer && (
            <button
              onClick={() => onNavigate('print-invoice', { orderNumber, category: 'Officer' })}
              className="h-10 px-4 rounded-full text-[13px] font-semibold text-[#0066cc] hover:bg-[#0066cc]/10 flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Switch to Invoice</span>
            </button>
          )}

          {type === 'invoice' && (
            <button
              onClick={() => onNavigate('print-slip', { orderNumber, category: 'Officer' })}
              className="h-10 px-4 rounded-full text-[13px] font-semibold text-[#0066cc] hover:bg-[#0066cc]/10 flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Scissors className="w-3.5 h-3.5" />
              <span>Switch to Cutting Slip</span>
            </button>
          )}

          <button
            onClick={handlePrint}
            className="h-10 px-6 bg-[#0066cc] hover:bg-[#0071e3] text-white rounded-full text-[13px] font-semibold flex items-center gap-2 shadow-xs cursor-pointer active:scale-95 transition-all"
          >
            <Printer className="w-4 h-4" />
            <span>Print Document</span>
          </button>
        </div>
      </div>

      {/* Printable Sheet Area */}
      <div
        className={`mx-auto bg-white border border-gray-300 shadow-lg print:border-0 print:shadow-none print:m-0 print:p-0 ${
          paperSize === 'A5' ? 'max-w-[148mm] min-h-[210mm] p-6' : 'max-w-[210mm] min-h-[297mm] p-8'
        }`}
      >
        {/* ================= TYPE: CUTTING SLIP ================= */}
        {type === 'slip' && order && (
          <div className="text-black font-sans space-y-3">
            {/* Top header bar */}
            <div className="pb-2 border-b border-gray-300 flex items-center justify-between print:pb-1">
              <div>
                <span className="text-[14px] font-extrabold uppercase tracking-wider">
                  {state.settings.invoiceShopName || 'BAF Tailor & Outfitters'}
                </span>
                <span className="ml-2 text-[11px] font-semibold text-gray-600 print:text-black">
                  — {category} Cutting {itemIndex !== undefined ? 'Slip' : 'Slips'} ({slipCards.length} {slipCards.length === 1 ? 'slip' : 'slips'})
                </span>
              </div>
              <span className="text-[10px] text-gray-500 print:text-black font-mono">
                Order #{order.orderNumber}
              </span>
            </div>

            {slipCards.length === 0 ? (
              <div className="p-8 text-center text-gray-500 italic">
                No cutting slips found for this item selection.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 print:grid-cols-2 print:gap-3">
                {slipCards.map((card) => (
                  <div
                    key={card.key}
                    className="border-2 border-black p-3.5 rounded-lg bg-white text-black flex flex-col justify-between"
                    style={{ breakInside: 'avoid', pageBreakInside: 'avoid' }}
                  >
                    <div>
                      {/* Top Header: #546 ~ S/L ERFAN ~ 10133 */}
                      <div className="flex items-start justify-between border-b-2 border-black pb-1.5 mb-2 gap-2">
                        <div className="font-extrabold text-[13px] tracking-tight leading-snug">
                          {card.headerTitle}
                        </div>
                        <div className="text-right shrink-0 text-[11px] font-bold">
                          {card.ribbonText && <div>{card.ribbonText}</div>}
                          {card.branchText && (
                            <div className="text-[10px] uppercase font-bold text-gray-800">
                              {card.branchText}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Item Line: Item: [Name] (Qty N) [~ IV: ...] */}
                      <div className="font-bold text-[12px] mb-1.5 text-gray-900">
                        {card.itemNameText}
                      </div>

                      {/* Thin divider */}
                      <div className="border-b border-black mb-2" />

                      {/* Measurement line: joined by ~ */}
                      <div className="text-[11px] font-medium leading-relaxed tracking-tight text-black">
                        {card.measurementsText}
                      </div>

                      {/* Notes line in bold */}
                      {card.notesText && (
                        <div className="mt-2 pt-1.5 border-t border-dashed border-gray-400 text-[11px] font-bold text-black">
                          <span className="uppercase text-[10px] tracking-wide underline mr-1">
                            Notes:
                          </span>
                          {card.notesText}
                        </div>
                      )}
                    </div>

                    {/* Bottom Line: Part name on left, date on right */}
                    <div className="mt-3 pt-1.5 border-t border-black flex items-center justify-between text-[10px] font-extrabold uppercase tracking-wider">
                      <span className="px-1.5 py-0.5 rounded bg-black text-white">
                        {card.partName}
                      </span>
                      <span className="text-gray-800">{card.dateText}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ================= TYPE: INVOICE ================= */}
        {type === 'invoice' && officerOrder && (
          <div className="text-black font-sans space-y-4 text-xs">
            {/* Header */}
            <div className="border-b-2 border-black pb-3 flex items-center justify-between">
              <div className="flex items-center space-x-3">
                {state.settings.invoiceLogo && (
                  <img
                    src={state.settings.invoiceLogo}
                    alt="Shop Logo"
                    className="w-12 h-12 object-contain"
                  />
                )}
                <div>
                  <h1 className="text-xl font-extrabold uppercase">
                    {state.settings.invoiceShopName || 'BAF Tailor & Outfitters'}
                  </h1>
                  <span className="text-sm font-bold tracking-widest uppercase">Invoice</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-base font-extrabold">#{officerOrder.orderNumber}</div>
                <div className="text-[11px]">Date: {officerOrder.orderDate}</div>
                {officerOrder.deliveryDate && (
                  <div className="text-[11px] font-semibold">Delivery: {officerOrder.deliveryDate}</div>
                )}
              </div>
            </div>

            {/* Customer Details */}
            <div className="border-b border-black pb-3 grid grid-cols-2 gap-2 text-xs">
              <div>
                <span className="font-bold">Customer Name: </span>
                <span className="font-extrabold text-sm">{officerOrder.customerName}</span>
              </div>
              <div>
                <span className="font-bold">BD Number: </span>
                <span className="font-bold">{officerOrder.customerBdNumber}</span>
              </div>
              {officerOrder.customerPhone && (
                <div>
                  <span className="font-bold">Phone: </span>
                  <span>{officerOrder.customerPhone}</span>
                </div>
              )}
            </div>

            {/* Items Table */}
            <div>
              <table className="w-full text-left border border-black text-xs">
                <thead>
                  <tr className="border-b border-black bg-gray-100">
                    <th className="p-1.5 border-r border-black w-8 text-center">#</th>
                    <th className="p-1.5 border-r border-black">Item</th>
                    <th className="p-1.5 border-r border-black w-14 text-center">Qty</th>
                    <th className="p-1.5 border-r border-black w-20 text-right">Price</th>
                    <th className="p-1.5 w-24 text-right">Line Total</th>
                  </tr>
                </thead>
                <tbody>
                  {officerOrder.items.map((item, idx) => (
                    <tr key={idx} className="border-b border-black">
                      <td className="p-1.5 border-r border-black text-center">{idx + 1}</td>
                      <td className="p-1.5 border-r border-black font-medium">{item.name}</td>
                      <td className="p-1.5 border-r border-black text-center">{item.quantity}</td>
                      <td className="p-1.5 border-r border-black text-right">৳{item.price}</td>
                      <td className="p-1.5 text-right font-semibold">৳{item.lineTotal}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Financial Calculations Block */}
            <div className="flex justify-end pt-2">
              <div className="w-64 border border-black p-2.5 space-y-1 text-xs">
                <div className="flex justify-between">
                  <span>Total Amount:</span>
                  <span className="font-bold">৳{officerOrder.totalAmount}</span>
                </div>
                {officerOrder.discountAmount > 0 && (
                  <div className="flex justify-between">
                    <span>Discount:</span>
                    <span>-৳{officerOrder.discountAmount}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Advance:</span>
                  <span>-৳{officerOrder.advance || 0}</span>
                </div>
                {/* Received Later line */}
                {(() => {
                  const later = (officerOrder.payments || []).reduce(
                    (s, p) => s + (Number(p.amount) || 0),
                    0
                  );
                  if (later <= 0) return null;
                  return (
                    <div className="flex justify-between text-emerald-800">
                      <span>Received Later:</span>
                      <span>-৳{later}</span>
                    </div>
                  );
                })()}
                <div className="flex justify-between border-t border-black pt-1 font-extrabold text-sm">
                  <span>Due:</span>
                  <span>৳{officerOrder.due}</span>
                </div>
              </div>
            </div>

            {/* Terms at Bottom */}
            {state.settings.invoiceTerms && (
              <div className="border-t border-black pt-3 mt-6 text-[10px] text-gray-700 whitespace-pre-line">
                <span className="font-bold block uppercase mb-0.5">Terms:</span>
                {state.settings.invoiceTerms}
              </div>
            )}
          </div>
        )}

        {/* ================= TYPE: WORKER STATEMENT ================= */}
        {type === 'worker-statement' && worker && month && (
          <div className="text-black font-sans space-y-4 text-xs">
            <div className="border-b-2 border-black pb-3 text-center">
              <h1 className="text-xl font-extrabold uppercase">
                {state.settings.invoiceShopName || 'BAF Tailor & Outfitters'}
              </h1>
              <div className="text-base font-bold underline mt-1">Staff Monthly Statement</div>
              <div className="text-sm font-semibold mt-1">
                Worker: {worker.name} {worker.banglaName && `(${worker.banglaName})`} · Month: {month}
              </div>
            </div>

            {/* Grid rows */}
            {(() => {
              const rows = state.workerRows.filter((r) => {
                if (r.workerId !== worker.id) return false;
                const rMonth = (r.date || '').slice(0, 7);
                const kMonth = (r.khorochDate || r.date || '').slice(0, 7);
                return rMonth === month || kMonth === month;
              });

              const payments = state.workerPayments.filter(
                (p) => p.workerId === worker.id && p.forMonth === month
              );

              const hishab = calculateWorkerMonthHishab(worker.id, state.workerRows, state.workerPayments, month);

              return (
                <div className="space-y-4">
                  <table className="w-full text-left border border-black text-[11px]">
                    <thead>
                      <tr className="border-b border-black bg-gray-100 font-bold">
                        <th className="p-1 border-r border-black">Date</th>
                        <th className="p-1 border-r border-black">Serial</th>
                        <th className="p-1 border-r border-black">BD</th>
                        <th className="p-1 border-r border-black">Item</th>
                        <th className="p-1 border-r border-black text-center">Qty</th>
                        <th className="p-1 border-r border-black text-right">Rate</th>
                        <th className="p-1 border-r border-black text-right">Total</th>
                        <th className="p-1 text-right">Khoroch</th>
                      </tr>
                    </thead>
                    <tbody>
                      {rows.map((r, i) => (
                        <tr key={i} className="border-b border-gray-300">
                          <td className="p-1 border-r border-black">{r.date}</td>
                          <td className="p-1 border-r border-black font-semibold">#{r.serial}</td>
                          <td className="p-1 border-r border-black">{r.bdNumber}</td>
                          <td className="p-1 border-r border-black">{r.item}</td>
                          <td className="p-1 border-r border-black text-center">{r.quantity}</td>
                          <td className="p-1 border-r border-black text-right">৳{r.unitPrice}</td>
                          <td className="p-1 border-r border-black text-right font-semibold">
                            ৳{r.totalTaka}
                          </td>
                          <td className="p-1 text-right font-semibold text-amber-900">
                            {r.khoroch ? `৳${r.khoroch}` : '—'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>

                  {/* Payments list in statement (Loop 8 Section 3) */}
                  {payments.length > 0 && (
                    <div className="border border-black p-2 rounded">
                      <span className="font-bold underline block mb-1">Settlement Payments Received:</span>
                      <div className="space-y-0.5">
                        {payments.map((p, idx) => (
                          <div key={idx} className="flex justify-between">
                            <span>{p.date} {p.note && `(${p.note})`}</span>
                            <span className="font-bold">৳{p.amount}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Footer Totals */}
                  <div className="border-t-2 border-black pt-2 flex justify-end">
                    <div className="w-56 space-y-1 font-semibold">
                      <div className="flex justify-between">
                        <span>Total Work Earned:</span>
                        <span>৳{hishab.totalAmount}</span>
                      </div>
                      <div className="flex justify-between text-amber-800">
                        <span>Total Khoroch:</span>
                        <span>-৳{hishab.totalKhoroch}</span>
                      </div>
                      <div className="flex justify-between border-t border-black pt-0.5 font-bold">
                        <span>Net Payable:</span>
                        <span>৳{hishab.netPayable}</span>
                      </div>
                      <div className="flex justify-between text-emerald-800">
                        <span>Received Payments:</span>
                        <span>-৳{hishab.received}</span>
                      </div>
                      <div className="flex justify-between border-t-2 border-black pt-1 font-extrabold text-sm">
                        <span>Balance Due:</span>
                        <span>৳{hishab.due}</span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })()}
          </div>
        )}
      </div>
    </div>
  );
};
