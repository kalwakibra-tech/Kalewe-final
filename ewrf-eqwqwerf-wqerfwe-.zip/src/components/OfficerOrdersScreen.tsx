import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useApp } from '../context/AppContext.tsx';
import { OfficerOrder, OrderStatus } from '../types/index.ts';
import { StatusBadge } from './StatusBadge.tsx';
import { PolarisPage } from './polaris/PolarisPage.tsx';
import { formatDate, isOrderUpcoming } from '../utils/logic.ts';
import { EmptyStateCardsIllustration, RulerTickStrip } from './Illustrations.tsx';
import {
  Plus,
  Search,
  ArrowUpDown,
  Printer,
  Edit2,
  Trash2,
  Truck,
  X,
  CreditCard,
  FileText,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Scissors,
} from 'lucide-react';
import { ScreenName } from './Navbar.tsx';

interface OfficerOrdersScreenProps {
  onNavigate: (screen: ScreenName, params?: any) => void;
}

export const OfficerOrdersScreen: React.FC<OfficerOrdersScreenProps> = ({ onNavigate }) => {
  const { state, updateOfficerOrderStatus, deleteOfficerOrder, recordOfficerPayment } = useApp();

  const [activeTab, setActiveTab] = useState<'All' | OrderStatus>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
  const [activeCardFilter, setActiveCardFilter] = useState<'upcoming' | 'dueAfterDelivery' | null>(null);

  // Selected Order for Master-Detail Aside
  const [selectedOrderNumber, setSelectedOrderNumber] = useState<number | null>(() => {
    return state.officerOrders.length > 0 ? state.officerOrders[0].orderNumber : null;
  });

  // Pay Dialog State
  const [payTargetOrder, setPayTargetOrder] = useState<OfficerOrder | null>(null);
  const [payAmountInput, setPayAmountInput] = useState<string>('');

  // Delete Dialog State (Two-step delete)
  const [deleteTargetOrder, setDeleteTargetOrder] = useState<OfficerOrder | null>(null);
  const [deleteStep, setDeleteStep] = useState<1 | 2>(1);

  const todayStr = formatDate();
  const upcomingDays = state.settings.upcomingDeliveryDays || 3;

  // Calculate Summary Cards
  const upcomingOrders = useMemo(() => {
    return state.officerOrders.filter((o) =>
      isOrderUpcoming(o.deliveryDate, o.status === 'Delivered', todayStr, upcomingDays)
    );
  }, [state.officerOrders, todayStr, upcomingDays]);

  const dueAfterDeliveryOrders = useMemo(() => {
    return state.officerOrders.filter((o) => o.status === 'Delivered' && o.due > 0);
  }, [state.officerOrders]);

  const totalDueAfterDelivery = useMemo(() => {
    return dueAfterDeliveryOrders.reduce((sum, o) => sum + (Number(o.due) || 0), 0);
  }, [dueAfterDeliveryOrders]);

  // Tab counts
  const tabCounts = useMemo(() => {
    return {
      All: state.officerOrders.length,
      Pending: state.officerOrders.filter((o) => o.status === 'Pending').length,
      'Cutting Slip – Done': state.officerOrders.filter((o) => o.status === 'Cutting Slip – Done').length,
      Delivered: state.officerOrders.filter((o) => o.status === 'Delivered').length,
    };
  }, [state.officerOrders]);

  // Filtered and Sorted Orders
  const filteredOrders = useMemo(() => {
    let list = [...state.officerOrders];

    if (activeCardFilter === 'upcoming') {
      list = list.filter((o) =>
        isOrderUpcoming(o.deliveryDate, o.status === 'Delivered', todayStr, upcomingDays)
      );
    } else if (activeCardFilter === 'dueAfterDelivery') {
      list = list.filter((o) => o.status === 'Delivered' && o.due > 0);
    }

    if (activeTab !== 'All') {
      list = list.filter((o) => o.status === activeTab);
    }

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter((o) => {
        const orderNumStr = String(o.orderNumber);
        const nameMatch = (o.customerName || '').toLowerCase().includes(q);
        const bdMatch = (o.customerBdNumber || '').toLowerCase().includes(q);
        const phoneMatch = o.customerPhone ? o.customerPhone.includes(q) : false;
        const itemMatch = o.items.some((it) => it.name.toLowerCase().includes(q));
        return orderNumStr.includes(q) || nameMatch || bdMatch || phoneMatch || itemMatch;
      });
    }

    list.sort((a, b) => {
      if (sortOrder === 'newest') {
        return b.orderNumber - a.orderNumber;
      }
      return a.orderNumber - b.orderNumber;
    });

    return list;
  }, [state.officerOrders, activeCardFilter, activeTab, searchQuery, sortOrder, todayStr, upcomingDays]);

  // Keep selected order valid
  const currentSelectedOrder = useMemo(() => {
    if (!filteredOrders.length) return null;
    const found = filteredOrders.find((o) => o.orderNumber === selectedOrderNumber);
    return found || filteredOrders[0];
  }, [filteredOrders, selectedOrderNumber]);

  const handleOpenPayModal = (order: OfficerOrder) => {
    setPayTargetOrder(order);
    setPayAmountInput(String(order.due));
  };

  const handleConfirmPayment = () => {
    if (!payTargetOrder) return;
    const amount = parseFloat(payAmountInput);
    if (isNaN(amount) || amount <= 0) return;
    recordOfficerPayment(payTargetOrder.orderNumber, amount);
    setPayTargetOrder(null);
  };

  const handleDeleteStepOne = (order: OfficerOrder) => {
    setDeleteTargetOrder(order);
    setDeleteStep(1);
  };

  const handleDeleteConfirm = () => {
    if (!deleteTargetOrder) return;
    if (deleteStep === 1) {
      setDeleteStep(2);
    } else {
      deleteOfficerOrder(deleteTargetOrder.orderNumber);
      setDeleteTargetOrder(null);
      setDeleteStep(1);
    }
  };

  return (
    <PolarisPage
      title="Officer Orders"
      subtitle="Every Officer order, from first fitting to final due."
      secondaryActions={[
        {
          label: 'Delivery Queue',
          icon: <Truck className="w-4 h-4" />,
          onClick: () => onNavigate('delivery'),
        },
      ]}
      primaryAction={{
        label: 'New order',
        icon: <Plus className="w-4 h-4 stroke-[2.2]" />,
        onClick: () => onNavigate('new-officer-order'),
      }}
      fullWidth
    >
      {/* =========================================================================
          SUMMARY BAND (Paired Summary: Paper Tile + Graphite Object Card)
          Section 1.4 item 1, 2 & Section 10.2
         ========================================================================= */}
      <div className="bg-white rounded-[24px] p-6 border border-[#e0e0e0] grid grid-cols-1 md:grid-cols-2 gap-5 select-none">
        {/* Left Paper Tile (Shell background, Time/Volume metric, clickable filter) */}
        <div
          onClick={() => {
            setActiveCardFilter(activeCardFilter === 'upcoming' ? null : 'upcoming');
          }}
          className={`p-6 rounded-[20px] bg-[#f5f5f7] cursor-pointer transition-all relative ${
            activeCardFilter === 'upcoming' ? 'ring-2 ring-[#0071e3]' : 'hover:bg-[#efeff2]'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-[15px] font-semibold text-[#333333]">
              Upcoming to deliver
            </span>
            {activeCardFilter === 'upcoming' && (
              <span className="text-[12px] font-semibold text-[#0066cc] bg-white px-2.5 py-0.5 rounded-full border border-[#0066cc]/30">
                Filter: Upcoming ✕
              </span>
            )}
          </div>

          <div className="flex items-baseline gap-2 mb-4">
            <span className="text-[36px] font-semibold text-[#1d1d1f] tracking-[-0.03em] num">
              {upcomingOrders.length}
            </span>
            <span className="text-[15px] text-[#6e6e73] font-normal">
              orders · next {upcomingDays} days
            </span>
          </div>

          {/* Up to 2 nested white rows */}
          <div className="space-y-2">
            {upcomingOrders.slice(0, 2).map((uo) => (
              <div
                key={uo.id}
                className="bg-white rounded-[14px] p-3 flex items-center justify-between text-[13px] border border-[#e0e0e0]/50"
              >
                <div className="truncate min-w-0 mr-2">
                  <span className="font-semibold text-[#1d1d1f]">{uo.customerName}</span>
                  <span className="text-[#6e6e73] ml-2">#{uo.orderNumber}</span>
                </div>
                <div className="text-[12px] font-semibold text-[#c2410c] bg-[#fdeee7] px-2 py-0.5 rounded-full shrink-0">
                  {uo.deliveryDate}
                </div>
              </div>
            ))}
            {upcomingOrders.length === 0 && (
              <div className="text-[13px] text-[#6e6e73] py-2">
                No orders due in the next {upcomingDays} days.
              </div>
            )}
          </div>
        </div>

        {/* Right Signature Graphite Object Tile (Money/Risk, Hero Number, Sheen, Rim) */}
        <div
          onClick={() => {
            setActiveCardFilter(activeCardFilter === 'dueAfterDelivery' ? null : 'dueAfterDelivery');
          }}
          className={`object-card p-6 rounded-[20px] cursor-pointer transition-all relative ${
            activeCardFilter === 'dueAfterDelivery' ? 'ring-2 ring-[#2997ff]' : ''
          }`}
        >
          <div className="relative z-10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[15px] font-semibold text-white/70">
                Due after delivery
              </span>
              {activeCardFilter === 'dueAfterDelivery' && (
                <span className="text-[12px] font-semibold text-[#2997ff] bg-white/10 px-2.5 py-0.5 rounded-full border border-white/20">
                  Filter: Due ✕
                </span>
              )}
            </div>

            <div className="flex items-baseline gap-2 mb-4">
              <span className="hero-num text-white">
                <span className="cur text-white/60">৳</span>
                {totalDueAfterDelivery.toLocaleString()}
              </span>
              <span className="text-[15px] text-white/70 font-normal">
                {dueAfterDeliveryOrders.length} orders
              </span>
            </div>

            {/* Up to 2 nested graphite rows with inline Pay button */}
            <div className="space-y-2">
              {dueAfterDeliveryOrders.slice(0, 2).map((order) => (
                <div
                  key={order.id}
                  className="graphite-row flex items-center justify-between text-[13px]"
                >
                  <div className="truncate min-w-0 mr-2 text-white">
                    <span className="font-semibold">{order.customerName}</span>
                    <span className="text-white/60 ml-2">#{order.orderNumber} · ৳{order.due.toLocaleString()}</span>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleOpenPayModal(order);
                    }}
                    className="h-8 px-3.5 rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[12px] font-semibold transition-all shrink-0 cursor-pointer active:scale-95 shadow-xs"
                  >
                    Pay ৳{order.due.toLocaleString()}
                  </button>
                </div>
              ))}
              {dueAfterDeliveryOrders.length === 0 && (
                <div className="text-[13px] text-white/60 py-2">
                  All delivered orders are fully settled.
                </div>
              )}
            </div>

            {/* Bottom Ruler Tick Strip Motif */}
            <div className="mt-4 pt-2">
              <RulerTickStrip dark={false} className="h-4 opacity-40" />
            </div>
          </div>
        </div>
      </div>

      {/* =========================================================================
          CONTROL BAND (Filter Chips with counts, Search pill, Sort pill)
          Section 1.4 item 7 & Section 10.4
         ========================================================================= */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 select-none">
        {/* Filter Chips: Selected has 2px primary-focus ring */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          {(['All', 'Pending', 'Cutting Slip – Done', 'Delivered'] as const).map((tab) => {
            const isSelected = activeTab === tab && activeCardFilter === null;
            return (
              <button
                key={tab}
                aria-pressed={isSelected}
                onClick={() => {
                  setActiveTab(tab);
                  setActiveCardFilter(null);
                }}
                className={`h-[40px] px-4 rounded-full text-[14px] font-semibold tracking-[-0.224px] flex items-center gap-2 transition-all whitespace-nowrap cursor-pointer ${
                  isSelected
                    ? 'bg-white border-2 border-[#0071e3] text-[#1d1d1f]'
                    : 'bg-white border border-[#e0e0e0] text-[#1d1d1f] hover:bg-[#fafafc]'
                }`}
              >
                <span>{tab}</span>
                <span className="text-[13px] font-normal text-[#6e6e73] num">
                  {tabCounts[tab]}
                </span>
              </button>
            );
          })}
        </div>

        {/* Search & Sort Pills */}
        <div className="flex items-center gap-2.5">
          {/* Search Pill */}
          <div className="relative min-w-[240px] sm:min-w-[280px]">
            <Search className="w-4 h-4 text-[#6e6e73] absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search orders, BD, name..."
              className="w-full h-[40px] pl-10 pr-8 rounded-full bg-white border border-[#e0e0e0] text-[14px] text-[#1d1d1f] placeholder-[#7a7a7a] outline-none focus:border-[#0071e3] focus:ring-1 focus:ring-[#0071e3] transition-all"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6e6e73] hover:text-[#1d1d1f]"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Sort Pill */}
          <button
            onClick={() => setSortOrder(sortOrder === 'newest' ? 'oldest' : 'newest')}
            className="h-[40px] px-4 rounded-full bg-white border border-[#e0e0e0] text-[14px] font-semibold text-[#1d1d1f] flex items-center gap-1.5 hover:bg-[#fafafc] cursor-pointer whitespace-nowrap"
          >
            <span className="text-[#6e6e73] font-normal">Sort:</span>
            <span>{sortOrder === 'newest' ? 'Newest' : 'Oldest'}</span>
            <ArrowUpDown className="w-3.5 h-3.5 text-[#6e6e73]" />
          </button>
        </div>
      </div>

      {/* =========================================================================
          WORK BAND (Master-Detail Archetype: 8 Cols Table + 4 Cols Sticky Aside)
          Section 5.1 & Section 5.2
         ========================================================================= */}
      {filteredOrders.length === 0 ? (
        /* Empty State */
        <div className="bg-[#f5f5f7] rounded-[24px] p-12 text-center border border-[#e0e0e0] flex flex-col items-center justify-center">
          <EmptyStateCardsIllustration size={160} />
          <h3 className="text-[22px] font-semibold text-[#1d1d1f] mt-4">
            No orders match your filter
          </h3>
          <p className="text-[15px] text-[#6e6e73] mt-1.5 max-w-sm">
            {searchQuery || activeCardFilter
              ? 'Try resetting the search or filter chips.'
              : 'Tap New order to create the first commissioned Officer uniform.'}
          </p>
          <button
            onClick={() => {
              setSearchQuery('');
              setActiveCardFilter(null);
              setActiveTab('All');
            }}
            className="btn btn-primary mt-6"
          >
            Reset filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Table Panel (8 Columns) */}
          <div className="lg:col-span-8 bg-white rounded-[24px] border border-[#e0e0e0] p-6 overflow-hidden">
            <div className="flex items-center justify-between pb-4 mb-3 border-b border-[#f0f0f0]">
              <h2 className="text-[22px] font-semibold text-[#1d1d1f] tracking-[-0.02em]">
                All Officer Orders
              </h2>
              <span className="text-[13px] text-[#6e6e73] font-normal">
                Showing {filteredOrders.length} of {state.officerOrders.length} · tap a row for details
              </span>
            </div>

            {/* Dense Desktop Table */}
            <div className="overflow-x-auto no-scrollbar">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="h-10 bg-[#f5f5f7] rounded-[12px] text-[12px] font-semibold text-[#6e6e73] select-none">
                    <th className="px-3.5 rounded-l-[12px]">Order & Officer</th>
                    <th className="px-3">Status</th>
                    <th className="px-3">Delivery Date</th>
                    <th className="px-3">Payment</th>
                    <th className="px-3.5 text-right rounded-r-[12px]">Due</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#f0f0f0]">
                  {filteredOrders.map((order) => {
                    const isSelected = currentSelectedOrder?.orderNumber === order.orderNumber;
                    const paidPercent =
                      order.totalAmount > 0
                        ? Math.min(100, Math.round(((order.totalAmount - order.due) / order.totalAmount) * 100))
                        : 100;

                    return (
                      <tr
                        key={order.id}
                        onClick={() => setSelectedOrderNumber(order.orderNumber)}
                        className={`h-[68px] cursor-pointer transition-colors ${
                          isSelected ? 'bg-[#f0f0f0]' : 'hover:bg-[#fafafc]'
                        }`}
                      >
                        {/* Order & Officer column */}
                        <td className="px-3.5 py-2">
                          <div className="flex items-center gap-3">
                            {/* 40px dark entity chip */}
                            <div className="entity-chip">
                              #{order.orderNumber}
                            </div>
                            <div className="min-w-0">
                              <div className="text-[15px] font-semibold text-[#1d1d1f] leading-snug truncate">
                                {order.customerName}
                              </div>
                              <div className="text-[13px] text-[#6e6e73] font-normal leading-tight">
                                Officer · {order.customerBdNumber}
                              </div>
                            </div>
                          </div>
                        </td>

                        {/* Status Column: Dot plus text with inline chevron dropdown */}
                        <td className="px-3 py-2">
                          <StatusBadge
                            status={order.status}
                            interactive={true}
                            onChange={(newStatus) =>
                              updateOfficerOrderStatus(order.orderNumber, newStatus)
                            }
                          />
                        </td>

                        {/* Delivery Date */}
                        <td className="px-3 py-2 text-[14px] text-[#1d1d1f] font-normal num">
                          {order.deliveryDate || 'Not set'}
                        </td>

                        {/* Payment Progress */}
                        <td className="px-3 py-2">
                          <div className="w-28 space-y-1">
                            <div className="progress-bar">
                              <div
                                className="progress-fill"
                                style={{ width: `${paidPercent}%` }}
                              />
                            </div>
                            <div className="text-[12px] text-[#6e6e73] font-normal num">
                              {order.due === 0 ? (
                                <span className="text-[#1e7b43] font-semibold">Fully paid</span>
                              ) : (
                                `${paidPercent}% paid`
                              )}
                            </div>
                          </div>
                        </td>

                        {/* Due Amount Column: Tabular, red when owed, green ৳0 when cleared */}
                        <td className="px-3.5 py-2 text-right">
                          <span
                            className={`text-[15px] font-semibold num ${
                              order.due > 0 ? 'text-[#c62828]' : 'text-[#1e7b43]'
                            }`}
                          >
                            ৳{order.due.toLocaleString()}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Right Sticky Detail Aside (4 Columns) - Section 10.6 */}
          <div className="lg:col-span-4 sticky top-6">
            {currentSelectedOrder ? (
              <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-6 space-y-6">
                {/* Header Row: Entity Chip + Name + Actions */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="entity-chip w-11 h-11 text-[13px]">
                      #{currentSelectedOrder.orderNumber}
                    </div>
                    <div className="min-w-0">
                      <h3 className="text-[20px] font-semibold text-[#1d1d1f] leading-snug truncate">
                        {currentSelectedOrder.customerName}
                      </h3>
                      <p className="text-[13px] text-[#6e6e73]">
                        Officer · {currentSelectedOrder.customerBdNumber}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() =>
                      onNavigate('order-details', {
                        orderNumber: currentSelectedOrder.orderNumber,
                        category: 'Officer',
                      })
                    }
                    className="text-[13px] font-semibold text-[#0066cc] hover:underline shrink-0"
                  >
                    Open ›
                  </button>
                </div>

                {/* Three-segment workflow status bar */}
                <div className="space-y-1.5 select-none">
                  <div className="grid grid-cols-3 gap-1.5">
                    <div className="h-1 rounded-full bg-[#1d1d1f]" />
                    <div
                      className={`h-1 rounded-full ${
                        currentSelectedOrder.status === 'Cutting Slip – Done' ||
                        currentSelectedOrder.status === 'Delivered'
                          ? 'bg-[#1d1d1f]'
                          : 'bg-[#e0e0e0]'
                      }`}
                    />
                    <div
                      className={`h-1 rounded-full ${
                        currentSelectedOrder.status === 'Delivered'
                          ? 'bg-[#1d1d1f]'
                          : 'bg-[#e0e0e0]'
                      }`}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-[#6e6e73] font-semibold">
                    <span>Order Placed</span>
                    <span>Cutting Done</span>
                    <span>Delivered</span>
                  </div>
                </div>

                {/* Dates Row */}
                <div className="grid grid-cols-2 gap-3 p-3 bg-[#f5f5f7] rounded-[16px]">
                  <div>
                    <span className="text-[12px] text-[#6e6e73] block font-normal">Order Date</span>
                    <span className="text-[14px] font-semibold text-[#1d1d1f] num">
                      {currentSelectedOrder.orderDate || 'Not set'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[12px] text-[#6e6e73] block font-normal">Delivery Date</span>
                    <span className="text-[14px] font-semibold text-[#1d1d1f] num">
                      {currentSelectedOrder.deliveryDate || 'Not set'}
                    </span>
                  </div>
                </div>

                {/* Hero Due Numeral */}
                <div>
                  <span className="text-[12px] font-semibold text-[#6e6e73] uppercase tracking-wider block mb-1">
                    Amount Due
                  </span>
                  <div
                    className={`text-[40px] font-semibold leading-none num ${
                      currentSelectedOrder.due > 0 ? 'text-[#c62828]' : 'text-[#1e7b43]'
                    }`}
                  >
                    <span className="text-[18px] text-[#6e6e73] font-normal mr-1 align-top">৳</span>
                    {currentSelectedOrder.due.toLocaleString()}
                  </div>
                </div>

                {/* Financial Summary Tray */}
                <div className="p-4 bg-[#f5f5f7] rounded-[18px] space-y-3">
                  <div className="flex items-center justify-between text-[13px]">
                    <span className="text-[#6e6e73]">Total Amount:</span>
                    <span className="font-semibold text-[#1d1d1f] num">
                      ৳{currentSelectedOrder.totalAmount.toLocaleString()}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[13px]">
                    <span className="text-[#6e6e73]">Advance Paid:</span>
                    <span className="font-semibold text-[#1d1d1f] num">
                      ৳{currentSelectedOrder.advance.toLocaleString()}
                    </span>
                  </div>
                  {currentSelectedOrder.discountAmount > 0 && (
                    <div className="flex items-center justify-between text-[13px]">
                      <span className="text-[#6e6e73]">Discount:</span>
                      <span className="font-semibold text-[#1e7b43] num">
                        -৳{currentSelectedOrder.discountAmount.toLocaleString()}
                      </span>
                    </div>
                  )}
                  <div className="pt-2 border-t border-[#e0e0e0]/70 flex items-center justify-between">
                    <span className="text-[13px] text-[#6e6e73]">Payment Progress:</span>
                    <span className="text-[13px] font-semibold text-[#1d1d1f] num">
                      {currentSelectedOrder.totalAmount > 0
                        ? Math.min(
                            100,
                            Math.round(
                              ((currentSelectedOrder.totalAmount - currentSelectedOrder.due) /
                                currentSelectedOrder.totalAmount) *
                                100
                            )
                          )
                        : 100}
                      % paid
                    </span>
                  </div>
                </div>

                {/* Primary Action Button: Pay or Full Details */}
                <div className="space-y-2.5">
                  {currentSelectedOrder.due > 0 ? (
                    <button
                      onClick={() => handleOpenPayModal(currentSelectedOrder)}
                      className="w-full h-[44px] rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white text-[15px] font-semibold flex items-center justify-center gap-2 cursor-pointer transition-all active:scale-95 shadow-xs"
                    >
                      <CreditCard className="w-4 h-4" />
                      <span>Pay ৳{currentSelectedOrder.due.toLocaleString()}</span>
                    </button>
                  ) : (
                    <div className="w-full h-[44px] rounded-full bg-[#e3f4e8] text-[#1e7b43] text-[14px] font-semibold flex items-center justify-center gap-2">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Order Fully Paid</span>
                    </div>
                  )}

                  {/* Secondary Record Actions Under Title */}
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() =>
                        onNavigate('edit-officer-order', {
                          orderNumber: currentSelectedOrder.orderNumber,
                        })
                      }
                      className="h-9 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#1d1d1f] text-[13px] font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                      title="Edit order"
                    >
                      <Edit2 className="w-3.5 h-3.5 text-[#6e6e73]" />
                      <span>Edit</span>
                    </button>

                    <button
                      onClick={() =>
                        onNavigate('print-slip', {
                          orderNumber: currentSelectedOrder.orderNumber,
                          category: 'Officer',
                        })
                      }
                      className="h-9 rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#1d1d1f] text-[13px] font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                      title="Print Cutting Slip"
                    >
                      <Scissors className="w-3.5 h-3.5 text-[#6e6e73]" />
                      <span>Slip</span>
                    </button>

                    <button
                      onClick={() => handleDeleteStepOne(currentSelectedOrder)}
                      className="h-9 rounded-full bg-[#fceaea] hover:bg-[#fbdcdc] text-[#c62828] text-[13px] font-semibold flex items-center justify-center gap-1.5 cursor-pointer transition-colors"
                      title="Delete order"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Delete</span>
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-[24px] border border-[#e0e0e0] p-8 text-center text-[#6e6e73]">
                Select an order to inspect details.
              </div>
            )}
          </div>
        </div>
      )}

      {/* =========================================================================
          QUICK PAY MODAL (Money confirmation overlay)
         ========================================================================= */}
      <AnimatePresence>
        {payTargetOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setPayTargetOrder(null)}
              aria-hidden="true"
            />
            <div className="relative z-10 w-full max-w-md bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <div className="w-10 h-10 rounded-full bg-[#e3f4e8] text-[#1e7b43] flex items-center justify-center mb-4">
                <CreditCard className="w-5 h-5" />
              </div>
              <h3 className="text-[22px] font-semibold text-[#1d1d1f]">
                Receive payment for #{payTargetOrder.orderNumber}
              </h3>
              <p className="text-[14px] text-[#6e6e73] mt-1">
                Customer: <strong className="text-[#1d1d1f]">{payTargetOrder.customerName}</strong> ({payTargetOrder.customerBdNumber})
              </p>

              <div className="my-5 p-4 bg-[#f5f5f7] rounded-[18px] space-y-2">
                <div className="flex justify-between text-[13px]">
                  <span className="text-[#6e6e73]">Current Due:</span>
                  <span className="font-semibold text-[#c62828] num">৳{payTargetOrder.due.toLocaleString()}</span>
                </div>
                <div className="mt-3">
                  <label className="text-[12px] font-semibold text-[#6e6e73] block mb-1">
                    Amount Received (৳)
                  </label>
                  <input
                    type="number"
                    value={payAmountInput}
                    onChange={(e) => setPayAmountInput(e.target.value)}
                    max={payTargetOrder.due}
                    className="w-full h-[44px] px-4 rounded-[12px] bg-white border border-[#e0e0e0] text-[18px] font-semibold text-[#1d1d1f] num outline-none focus:border-[#0071e3]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setPayTargetOrder(null)}
                  className="h-[44px] rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#1d1d1f] font-semibold text-[15px]"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmPayment}
                  className="h-[44px] rounded-full bg-[#0066cc] hover:bg-[#0071e3] text-white font-semibold text-[15px] shadow-xs active:scale-95"
                >
                  Confirm Pay
                </button>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>

      {/* =========================================================================
          TWO-STEP DELETE MODAL per Section 10.11
         ========================================================================= */}
      <AnimatePresence>
        {deleteTargetOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div
              className="fixed inset-0 bg-black/35 backdrop-blur-xs"
              onClick={() => setDeleteTargetOrder(null)}
              aria-hidden="true"
            />
            <div className="relative z-10 w-full max-w-[420px] bg-white rounded-[28px] p-6 border border-[#e0e0e0] shadow-2xl">
              <div className="flex items-center justify-between mb-4">
                <div className="w-10 h-10 rounded-full bg-[#fceaea] text-[#c62828] flex items-center justify-center">
                  <Trash2 className="w-5 h-5" />
                </div>
                <div className="flex items-center gap-1.5 text-[12px] font-semibold text-[#6e6e73]">
                  <span>Step {deleteStep} of 2</span>
                  <div className="flex items-center gap-1 ml-1">
                    <span className="w-5 h-1.5 rounded-full bg-[#1d1d1f]" />
                    <span
                      className={`w-5 h-1.5 rounded-full transition-colors ${
                        deleteStep === 2 ? 'bg-[#c62828]' : 'bg-[#e0e0e0]'
                      }`}
                    />
                  </div>
                </div>
              </div>

              <h3 className="text-[22px] font-semibold text-[#1d1d1f] leading-snug">
                {deleteStep === 1
                  ? `Delete order #${deleteTargetOrder.orderNumber}?`
                  : 'This cannot be undone. Delete permanently?'}
              </h3>
              <p className="text-[15px] text-[#6e6e73] mt-2 leading-relaxed">
                {deleteStep === 1
                  ? `Check the order for ${deleteTargetOrder.customerName} before you go on. You will be asked once more.`
                  : 'Later Officer orders will move down by one number. Payment records and cutting slips will be archived.'}
              </p>

              <div className="grid grid-cols-2 gap-3 mt-6">
                <button
                  type="button"
                  onClick={() => setDeleteTargetOrder(null)}
                  className="h-[44px] rounded-full bg-[#f5f5f7] hover:bg-[#e0e0e0] text-[#1d1d1f] font-semibold text-[15px]"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleDeleteConfirm}
                  className={`h-[44px] rounded-full font-semibold text-[15px] text-white active:scale-95 ${
                    deleteStep === 1
                      ? 'bg-[#0066cc] hover:bg-[#0071e3]'
                      : 'bg-[#c62828] hover:bg-[#b02222]'
                  }`}
                >
                  {deleteStep === 1 ? 'Continue' : 'Delete'}
                </button>
              </div>
            </div>
          </div>
        )}
      </AnimatePresence>
    </PolarisPage>
  );
};
